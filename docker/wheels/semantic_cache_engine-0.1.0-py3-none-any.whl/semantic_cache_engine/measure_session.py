"""Run a fixed question set through the engine and report route/token metrics.

This is the engine capability behind the ``Semantic Cache Engine: Run
Measurement`` Command Palette action and the ``measure`` CLI subcommand. It
drives each question through the same resolver/direct-chat path the engine uses
normally, then classifies every turn as a cache **hit** (served from cache, no
generation) or a **generated** turn (full agent handoff), and aggregates the
token tracks the engine already records.

The headline signal for the alpha cross-machine proof is the hit/generated
split: with a reason bundle imported, the fixed questions should land as hits
(zero generation); cold, the same questions are generated. Real per-token
generation counts (``provider_tokens``) populate automatically once a
measurement provider is configured; until then they are ``null`` while the
hit/generated split and projected estimates remain available.
"""

from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from urllib import error, request as urllib_request

from .direct_chat import run_direct_chat_turn
from .settings import load_settings

# Built-in question sets — these MUST stay verbatim-aligned with the fixed
# question sets in docs/alpha-test-protocol.md (Part 2) so an imported producer
# bundle produces cache hits on the consumer machine.
FLASK_QUESTION_SET: list[str] = [
    "How does Flask route a URL to a view function, and where is the URL map built?",
    "What is the application context, and how is it pushed and popped?",
    "What is the request context, and what is request actually bound to?",
    "What does the @app.route decorator do internally?",
    "Where and how are blueprints registered onto an application?",
    "How does Flask.dispatch_request decide which view to call?",
    "How are errors and HTTP exceptions handled during the request cycle?",
    "How does Flask manage configuration via the Config object?",
    "How does url_for build a URL?",
    "How is a response finalized (make_response / finalize_request)?",
]

REQUESTS_QUESTION_SET: list[str] = [
    "How does requests.get flow through to actually sending an HTTP request?",
    "What does a Session object do, and how does it persist state across requests?",
    "How does connection pooling work via the HTTPAdapter?",
    "How are redirects resolved (resolve_redirects)?",
    "How is a request prepared (PreparedRequest)?",
    "How is authentication handled in the auth module?",
    "How are cookies stored and re-sent across requests?",
    "How are retries and timeouts handled?",
    "How is response content decoded (encoding detection)?",
    "How is SSL/TLS verification handled?",
]

_BUILTIN_SETS: dict[str, list[str]] = {
    "flask": FLASK_QUESTION_SET,
    "requests": REQUESTS_QUESTION_SET,
}

# Routes that mean "served from cache without a fresh generation".
_HIT_ROUTES = {"quick_return"}

_PROVIDER_TIMEOUT = 60  # seconds per question


def _make_provider_responder(
    *,
    provider_base_url: str,
    provider_model: str,
    provider_api_key: str,
    provider_api_version: str | None,
) -> Callable[[dict[str, Any]], dict[str, Any]]:
    """Return an agent_responder that makes a real OpenAI-compatible API call.

    The responder is passed to run_direct_chat_turn so cold measurement turns
    generate real answers (and real provider token counts) instead of the
    placeholder text produced by _default_agent_responder.
    """
    from .provider_usage import _build_provider_request, _normalize_payload_for_model  # noqa: PLC0415

    def _responder(packet: dict[str, Any]) -> dict[str, Any]:
        question = str(packet.get("question", "")).strip()
        handoff_ctx = packet.get("handoff_context") or {}
        context_text = str(handoff_ctx.get("context_summary") or handoff_ctx.get("context") or "").strip()
        user_content = f"{question}\n\n{context_text}".strip() if context_text else question

        url, headers = _build_provider_request(
            provider_base_url=provider_base_url,
            provider_model=provider_model,
            provider_api_key=provider_api_key,
            provider_api_version=provider_api_version,
        )
        payload = _normalize_payload_for_model(provider_model, {
            "model": provider_model,
            "messages": [
                {"role": "system", "content": "You are a helpful code assistant. Answer concisely."},
                {"role": "user", "content": user_content},
            ],
            "max_tokens": 512,
            "temperature": 0,
        })
        data = json.dumps(payload).encode("utf-8")
        req = urllib_request.Request(url, data=data, headers=headers, method="POST")
        t0 = time.perf_counter()
        try:
            with urllib_request.urlopen(req, timeout=_PROVIDER_TIMEOUT) as resp:  # noqa: S310
                body = json.loads(resp.read().decode("utf-8"))
        except error.URLError as exc:
            return {"answer": f"[provider error: {exc}]", "source": "provider-error", "provider_tokens": None}
        latency_ms = round((time.perf_counter() - t0) * 1000, 1)
        usage = body.get("usage", {})
        answer_text = ""
        choices = body.get("choices", [])
        if choices:
            answer_text = str(choices[0].get("message", {}).get("content", "")).strip()
        return {
            "answer": answer_text or "[no content returned]",
            "source": "provider",
            "provider_tokens": usage.get("total_tokens"),
            "prompt_tokens": usage.get("prompt_tokens"),
            "completion_tokens": usage.get("completion_tokens"),
            "latency_ms": latency_ms,
        }

    return _responder


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _coerce_int(value: Any) -> int | None:
    try:
        if value is None:
            return None
        return int(value)
    except (TypeError, ValueError):
        return None


def _load_questions(
    question_set: str | None,
    questions_file: str | None,
) -> list[str]:
    if questions_file:
        path = Path(questions_file).resolve()
        if not path.exists():
            raise FileNotFoundError(f"Questions file not found: {path}")
        lines = path.read_text(encoding="utf-8").splitlines()
        return [line.strip() for line in lines if line.strip()]
    if question_set:
        key = question_set.strip().lower()
        if key not in _BUILTIN_SETS:
            raise ValueError(f"Unknown question set: {question_set}")
        return list(_BUILTIN_SETS[key])
    raise ValueError("Provide either --question-set or --questions")


def measure_question_set(
    project_root: str | Path,
    *,
    question_set: str | None = None,
    questions_file: str | None = None,
    against_snapshot_id: str | None = None,
) -> dict[str, Any]:
    """Run each question and aggregate route/hit/token metrics.

    Returns a dict with ``status`` (``ok``/``error``), per-question rows, and an
    aggregate block. A turn is counted as a **hit** when the engine answers from
    cache (route ``quick_return``) and **generated** otherwise (``agent_handoff``).
    """
    root = Path(project_root).resolve()
    settings = load_settings(root)
    agent_model = (getattr(settings, "provider_model", None) or "").strip() or "unconfigured"

    # Wire a real provider responder if a key is available so cold measurement
    # turns produce actual LLM answers (not placeholder text) and real token counts.
    _provider_responder: Callable[[dict[str, Any]], dict[str, Any]] | None = None
    _api_key = getattr(settings, "provider_api_key", None)
    if _api_key:
        _provider_responder = _make_provider_responder(
            provider_base_url=getattr(settings, "provider_base_url", "https://api.openai.com/v1"),
            provider_model=getattr(settings, "provider_model", "gpt-4o-mini"),
            provider_api_key=_api_key,
            provider_api_version=getattr(settings, "provider_api_version", None),
        )
    try:
        questions = _load_questions(question_set, questions_file)
    except Exception as exc:  # noqa: BLE001 -- structured error, never crash the CLI
        return {"status": "error", "error": f"{type(exc).__name__}: {exc}"}

    if not questions:
        return {"status": "error", "error": "No questions to measure."}

    rows: list[dict[str, Any]] = []
    hits = 0
    generated = 0
    cards_committed = 0
    read_only_turns = 0
    projected_total = 0
    provider_total: int | None = None

    for index, question in enumerate(questions, start=1):
        # Wrap provider responder to capture token counts returned by the API.
        _responder_tokens: list[int | None] = [None]
        if _provider_responder is not None:
            _inner = _provider_responder
            def _capturing_responder(packet: dict[str, Any], _inner=_inner, _tok=_responder_tokens) -> dict[str, Any]:
                result = _inner(packet)
                _tok[0] = _coerce_int(result.get("provider_tokens"))
                return result
            _turn_responder: Callable[[dict[str, Any]], dict[str, Any]] | None = _capturing_responder
        else:
            _turn_responder = None

        try:
            turn = run_direct_chat_turn(
                project_root=root,
                question=question,
                against_snapshot_id=against_snapshot_id,
                agent_responder=_turn_responder,
            )
        except Exception as exc:  # noqa: BLE001 -- record the failure, keep measuring
            rows.append(
                {
                    "index": index,
                    "question": question,
                    "status": "error",
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )
            continue

        route = str(turn.get("route", ""))
        is_hit = route in _HIT_ROUTES
        if is_hit:
            hits += 1
        else:
            generated += 1

        commit_block = turn.get("reasoning_commit") or {}
        card_committed = commit_block.get("status") == "committed"
        if card_committed:
            cards_committed += 1
        if turn.get("read_only"):
            read_only_turns += 1

        resolver_block = turn.get("resolver") or {}
        projected = _coerce_int((resolver_block.get("cost_metrics") or {}).get("actual_tokens"))
        provider = _coerce_int(
            (resolver_block.get("provider_cost_metrics") or {}).get("actual_provider_tokens")
        ) or _responder_tokens[0]
        if projected is not None:
            projected_total += projected
        if provider is not None:
            provider_total = (provider_total or 0) + provider

        rows.append(
            {
                "index": index,
                "question": question,
                "status": "ok",
                "route": route,
                "resolver_route": turn.get("resolver_route"),
                "answer_source": turn.get("answer_source"),
                "classification": "hit" if is_hit else "generated",
                "card_committed": card_committed,
                "projected_tokens": projected,
                "provider_tokens": provider,
            }
        )

    aggregate = {
        "question_count": len(questions),
        "hits": hits,
        "generated": generated,
        "hit_rate": round(hits / len(questions), 6) if questions else 0.0,
        "cards_committed": cards_committed,
        "read_only": read_only_turns == len(questions) and len(questions) > 0,
        "projected_tokens_total": projected_total,
        "provider_tokens_total": provider_total,
    }

    notes = [
        "A 'hit' is served from cache with no fresh generation; 'generated' is a full agent handoff.",
        "provider_tokens are real model usage tokens and populate only when a measurement "
        "provider is configured; otherwise they are null.",
        "projected_tokens are an internal estimate, not billed tokens.",
        "agent_model is the configured measurement model; all testers must share an identical "
        "value for cross-machine answer-similarity comparison to be valid.",
        "cards_committed counts reasoning cards written this run; with SEMANTIC_CACHE_READ_ONLY "
        "set (the cold Control), it is 0 and read_only is true — a provable zero-write baseline.",
    ]

    return {
        "status": "ok",
        "generated_utc": _utc_now(),
        "project_root": str(root),
        "question_set": question_set,
        "questions_file": questions_file,
        "agent_model": agent_model,
        "aggregate": aggregate,
        "rows": rows,
        "notes": notes,
    }
