import re
from pathlib import Path

from .limits import MAX_CHUNK_CHAR_COUNT, slugify_anchor_text, split_text_by_char_limit
from .models import ChunkSeed

# Control-flow / non-definition keywords that must never start a chunk boundary
# in brace languages (otherwise ``if (...) {``, ``for (...) {``, ``switch (...)``
# etc. would each be treated as a symbol boundary).
_CONTROL_KW = (
    r"(?:if|for|while|switch|catch|else|do|return|case|goto|using|namespace|"
    r"import|package|new|throw|delete|sizeof|typedef|break|continue|default|"
    r"await|yield|assert|lock|fixed|foreach|in|out|where|select|from)"
)

# Python: def / async def / class.
_PY_BOUNDARY = re.compile(r"^\s*(?:(?:async\s+)?def|class)\s+[A-Za-z_]")

# JS / TS / JSX / TSX: function / class / const|let|var / interface|type|enum|namespace.
_JSTS_BOUNDARY = re.compile(
    r"^\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?function\s*\*?\s+[A-Za-z_]"
    r"|^\s*(?:export\s+)?(?:default\s+)?(?:abstract\s+)?class\s+[A-Za-z_]"
    r"|^\s*(?:export\s+)?(?:const|let|var)\s+[A-Za-z_]"
    r"|^\s*(?:export\s+)?(?:declare\s+)?(?:interface|type|enum|namespace)\s+[A-Za-z_]"
)

# Go: func (including methods with a receiver) / type.
_GO_BOUNDARY = re.compile(
    r"^\s*func\s+(?:\([^)]*\)\s*)?[A-Za-z_]"
    r"|^\s*type\s+[A-Za-z_]"
)

# Rust: fn (with visibility/async/unsafe/const/extern) / struct|enum|trait|union|mod / impl.
_RUST_BOUNDARY = re.compile(
    r"^\s*(?:pub(?:\([^)]*\))?\s+)?(?:default\s+)?(?:async\s+)?(?:unsafe\s+)?"
    r"(?:const\s+)?(?:extern\s+\"[^\"]*\"\s+)?fn\s+[A-Za-z_]"
    r"|^\s*(?:pub(?:\([^)]*\))?\s+)?(?:unsafe\s+)?(?:struct|enum|trait|union|mod)\s+[A-Za-z_]"
    r"|^\s*(?:unsafe\s+)?impl(?:[\s<])"
)

# Java / C#: type declarations (keyword-led) + modifier-led method/ctor signatures.
_JAVA_CS_BOUNDARY = re.compile(
    r"^\s*(?:@[\w.]+(?:\([^)]*\))?\s*)*"
    r"(?:(?:public|private|protected|internal|static|final|abstract|sealed|"
    r"virtual|override|async|partial|synchronized|native|unsafe|extern|new|"
    r"readonly|volatile|transient|default)\s+)*"
    r"(?:class|interface|enum|record|struct)\s+[A-Za-z_]"
    r"|^\s*(?!\s*" + _CONTROL_KW + r"\b)"
    r"(?:(?:public|private|protected|internal|static|final|abstract|virtual|"
    r"override|async|sealed|partial|synchronized|native|unsafe|extern)\s+)+"
    r"[\w<>\[\],.\s\*&]*?[A-Za-z_]\w*\s*\("
)

# C / C++ / headers: type declarations + a conservative function-DEFINITION line
# (signature whose ``)`` is followed by ``{`` on the same line; excludes
# prototypes ending in ``;`` and control-flow statements).
_C_CPP_BOUNDARY = re.compile(
    r"^\s*(?:template\s*<[^>]*>\s*)?(?:class|struct|enum|union|namespace)\s+[A-Za-z_]"
    r"|^\s*(?!\s*" + _CONTROL_KW + r"\b)"
    r"[A-Za-z_][\w:<>,\.\*&\[\] ]*?[\s\*&]+[A-Za-z_]\w*\s*\([^;{]*\)\s*"
    r"(?:const\s*)?(?:noexcept\s*)?(?:override\s*)?(?:final\s*)?\{\s*$"
)

_BOUNDARIES_BY_LANGUAGE = {
    "py": _PY_BOUNDARY,
    "js": _JSTS_BOUNDARY,
    "jsx": _JSTS_BOUNDARY,
    "ts": _JSTS_BOUNDARY,
    "tsx": _JSTS_BOUNDARY,
    "go": _GO_BOUNDARY,
    "rs": _RUST_BOUNDARY,
    "java": _JAVA_CS_BOUNDARY,
    "cs": _JAVA_CS_BOUNDARY,
    "c": _C_CPP_BOUNDARY,
    "cpp": _C_CPP_BOUNDARY,
    "h": _C_CPP_BOUNDARY,
    "hpp": _C_CPP_BOUNDARY,
}

# Fallback for unmapped source languages (json/yaml/toml/ini/sql/sh/ps1, etc.):
# the original Python+JS heuristic, so behavior is unchanged for them.
_DEFAULT_BOUNDARY = re.compile(
    r"^(?:\s*(?:def|class|async\s+def)\s+[A-Za-z_][A-Za-z0-9_]*"
    r"|\s*(?:function|export\s+function|const|let|var)\s+[A-Za-z_][A-Za-z0-9_]*)"
)

# Go method with an explicit receiver: ``func (r *T) Name(...)`` -> name "Name".
_GO_RECEIVER_RE = re.compile(r"^\s*func\s+\([^)]*\)\s*([A-Za-z_]\w*)")

# Leading visibility / kind keywords stripped when deriving a bare symbol name.
_LEADING_KW_RE = re.compile(
    r"^(?:"
    r"async\s+def|def|class|"
    r"export\s+default\s+|export\s+|default\s+|"
    r"public|private|protected|internal|static|final|abstract|sealed|virtual|"
    r"override|partial|synchronized|native|unsafe|extern|new|readonly|volatile|"
    r"transient|async|"
    r"pub(?:\([^)]*\))?|const|let|var|"
    r"func|fn|type|struct|enum|trait|union|impl|mod|interface|record|namespace|"
    r"function"
    r")\b\s*"
)


def _boundary_for(language: str) -> "re.Pattern[str]":
    return _BOUNDARIES_BY_LANGUAGE.get((language or "").lower(), _DEFAULT_BOUNDARY)


def _extract_symbol(first_line: str) -> str:
    """Derive a language-agnostic symbol name from a boundary line."""
    receiver = _GO_RECEIVER_RE.match(first_line)
    if receiver:
        return receiver.group(1)

    stripped = first_line.strip()
    # Drop ``template<...>`` prefixes (C++) before keyword stripping.
    stripped = re.sub(r"^template\s*<[^>]*>\s*", "", stripped)

    previous = None
    while previous != stripped:
        previous = stripped
        stripped = _LEADING_KW_RE.sub("", stripped)

    # Function-like signature: the identifier immediately before the first ``(``.
    if "(" in stripped:
        before = stripped.split("(")[0]
        identifiers = re.findall(r"[A-Za-z_]\w*", before)
        if identifiers:
            return identifiers[-1]

    # Type / variable declaration: the first identifier.
    match = re.match(r"[A-Za-z_]\w*", stripped)
    return match.group(0) if match else ""


def chunk_source(path: str, text: str, language: str) -> list[ChunkSeed]:
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    boundary_re = _boundary_for(language)
    boundary_indices: list[int] = []

    for index, line in enumerate(lines):
        if boundary_re.match(line):
            boundary_indices.append(index)

    module_name = Path(path).stem

    if not boundary_indices:
        return [
            ChunkSeed(
                path=path,
                language=language,
                anchor="file:0",
                content=text,
                module_name=module_name,
                unit_id=module_name,
            )
        ] if text.strip() else []

    chunks: list[ChunkSeed] = []
    boundary_indices.append(len(lines))

    for ordinal, start_index in enumerate(boundary_indices[:-1], start=1):
        end_index = boundary_indices[ordinal]
        segment = "\n".join(lines[start_index:end_index]).strip("\n")
        if not segment.strip():
            continue

        first_line = lines[start_index].strip()
        go_method = _GO_RECEIVER_RE.match(lines[start_index])
        if go_method:
            label = f"func {go_method.group(1)}"
        else:
            label = first_line.split("(")[0].split(":")[0].strip()
        base_anchor = f"{slugify_anchor_text(label, fallback='block')}:{ordinal}"

        # Derive the symbol name in a language-aware way.
        symbol_name = _extract_symbol(first_line) or label
        unit_id = f"{module_name}::{symbol_name}" if symbol_name else module_name

        parts = split_text_by_char_limit(segment, max_char_count=MAX_CHUNK_CHAR_COUNT)

        for part_index, part_content in enumerate(parts, start=1):
            anchor = base_anchor if len(parts) == 1 else f"{base_anchor}#part-{part_index}"
            chunks.append(
                ChunkSeed(
                    path=path,
                    language=language,
                    anchor=anchor,
                    content=part_content,
                    module_name=module_name,
                    symbol_name=symbol_name,
                    unit_id=unit_id,
                )
            )

    return chunks
