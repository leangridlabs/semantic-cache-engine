from dataclasses import dataclass, field


@dataclass(frozen=True)
class ChunkSeed:
    path: str
    language: str
    anchor: str
    content: str
    module_name: str = ""
    symbol_name: str = ""
    unit_id: str = ""


@dataclass(frozen=True)
class Chunk:
    chunk_id: str
    path: str
    language: str
    anchor: str
    hash: str
    char_count: int
    module_name: str = ""
    symbol_name: str = ""
    unit_id: str = ""
