def normalize_text(text: str) -> str:
    """Apply minimal normalization for deterministic hashing and IDs."""
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    normalized_lines = [line.rstrip() for line in normalized.split("\n")]

    collapsed_lines: list[str] = []
    previous_blank = False
    for line in normalized_lines:
        is_blank = line == ""
        if is_blank and previous_blank:
            continue
        collapsed_lines.append(line)
        previous_blank = is_blank

    while collapsed_lines and collapsed_lines[0] == "":
        collapsed_lines.pop(0)
    while collapsed_lines and collapsed_lines[-1] == "":
        collapsed_lines.pop()

    return "\n".join(collapsed_lines)
