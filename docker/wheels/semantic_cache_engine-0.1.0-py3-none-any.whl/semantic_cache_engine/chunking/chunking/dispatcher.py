from pathlib import Path

from .markdown_chunker import chunk_markdown
from .models import ChunkSeed
from .source_chunker import chunk_source

MARKDOWN_EXTENSIONS = {".md", ".markdown", ".mdx"}

SOURCE_EXTENSIONS = {
    ".py",
    ".ts",
    ".tsx",
    ".js",
    ".jsx",
    ".cs",
    ".go",
    ".java",
    ".rs",
    ".c",
    ".cpp",
    ".h",
    ".hpp",
    ".json",
    ".yaml",
    ".yml",
    ".toml",
    ".ini",
    ".sql",
    ".sh",
    ".ps1",
}

SUPPORTED_EXTENSIONS = MARKDOWN_EXTENSIONS | SOURCE_EXTENSIONS


def is_supported_path(path: str) -> bool:
    return Path(path).suffix.lower() in SUPPORTED_EXTENSIONS


def dispatch_chunk(path: str, text: str) -> list[ChunkSeed]:
    suffix = Path(path).suffix.lower()

    if suffix in MARKDOWN_EXTENSIONS:
        return chunk_markdown(path, text)

    if suffix in SOURCE_EXTENSIONS:
        return chunk_source(path, text, language=suffix.lstrip("."))

    return []
