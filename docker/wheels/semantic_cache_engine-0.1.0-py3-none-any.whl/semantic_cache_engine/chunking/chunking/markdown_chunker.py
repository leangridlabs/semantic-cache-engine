from .limits import MAX_CHUNK_CHAR_COUNT, slugify_anchor_text, split_text_by_char_limit
from .models import ChunkSeed


def chunk_markdown(path: str, text: str) -> list[ChunkSeed]:
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    chunks: list[ChunkSeed] = []

    heading_stack: list[str] = []
    current_lines: list[str] = []
    current_anchor = "root:0"
    section_index = 0

    def flush_current() -> None:
        if not current_lines:
            return
        content = "\n".join(current_lines)
        if content.strip() == "":
            return
        parts = split_text_by_char_limit(content, max_char_count=MAX_CHUNK_CHAR_COUNT)
        for part_index, part_content in enumerate(parts, start=1):
            anchor = current_anchor if len(parts) == 1 else f"{current_anchor}#part-{part_index}"
            chunks.append(
                ChunkSeed(
                    path=path,
                    language="markdown",
                    anchor=anchor,
                    content=part_content,
                )
            )

    for line in lines:
        stripped = line.lstrip()
        if stripped.startswith("#"):
            level = 0
            for char in stripped:
                if char == "#":
                    level += 1
                else:
                    break
            if 1 <= level <= 6 and len(stripped) > level and stripped[level] == " ":
                flush_current()
                current_lines = [line]
                section_index += 1

                heading_text = slugify_anchor_text(
                    stripped[level + 1 :],
                    fallback=f"section-{section_index}",
                )
                while len(heading_stack) >= level:
                    heading_stack.pop()
                heading_stack.append(heading_text or f"section-{section_index}")
                current_anchor = f"{'/'.join(heading_stack)}:{section_index}"
                continue

        current_lines.append(line)

    flush_current()

    if not chunks and text.strip():
        for part_index, part_content in enumerate(
            split_text_by_char_limit(text, max_char_count=MAX_CHUNK_CHAR_COUNT),
            start=1,
        ):
            anchor = "doc:0" if part_index == 1 else f"doc:0#part-{part_index}"
            chunks.append(
                ChunkSeed(
                    path=path,
                    language="markdown",
                    anchor=anchor,
                    content=part_content,
                )
            )

    return chunks
