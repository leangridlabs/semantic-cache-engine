from __future__ import annotations

import re

MAX_CHUNK_CHAR_COUNT = 3200


def slugify_anchor_text(text: str, fallback: str = "section") -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", text.strip().lower())
    slug = re.sub(r"-+", "-", slug).strip("-")
    return slug or fallback


def split_text_by_char_limit(text: str, max_char_count: int = MAX_CHUNK_CHAR_COUNT) -> list[str]:
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    if not normalized.strip():
        return []

    if len(normalized) <= max_char_count:
        return [normalized]

    segments: list[str] = []
    current_lines: list[str] = []
    current_length = 0

    for line in normalized.split("\n"):
        line_length = len(line)
        added_length = line_length if not current_lines else line_length + 1
        if current_lines and current_length + added_length > max_char_count:
            segment = "\n".join(current_lines).strip("\n")
            if segment.strip():
                segments.append(segment)
            current_lines = [line]
            current_length = line_length
            continue

        current_lines.append(line)
        current_length += added_length

    if current_lines:
        segment = "\n".join(current_lines).strip("\n")
        if segment.strip():
            segments.append(segment)

    expanded: list[str] = []
    for segment in segments:
        if len(segment) <= max_char_count:
            expanded.append(segment)
            continue

        for start in range(0, len(segment), max_char_count):
            window = segment[start : start + max_char_count].strip("\n")
            if window.strip():
                expanded.append(window)

    return expanded