from dataclasses import dataclass


@dataclass(frozen=True)
class ChunkSeed:
    path: str
    language: str
    anchor: str
    content: str


@dataclass(frozen=True)
class Chunk:
    chunk_id: str
    path: str
    language: str
    anchor: str
    hash: str
    char_count: int
