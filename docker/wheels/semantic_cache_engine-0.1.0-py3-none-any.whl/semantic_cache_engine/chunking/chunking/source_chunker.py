import re

from .limits import MAX_CHUNK_CHAR_COUNT, slugify_anchor_text, split_text_by_char_limit
from .models import ChunkSeed

BOUNDARY_RE = re.compile(
    r"^(?:\s*(?:def|class|async\s+def)\s+[A-Za-z_][A-Za-z0-9_]*"
    r"|\s*(?:function|export\s+function|const|let|var)\s+[A-Za-z_][A-Za-z0-9_]*)"
)


def chunk_source(path: str, text: str, language: str) -> list[ChunkSeed]:
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    boundary_indices: list[int] = []

    for index, line in enumerate(lines):
        if BOUNDARY_RE.match(line):
            boundary_indices.append(index)

    if not boundary_indices:
        return [ChunkSeed(path=path, language=language, anchor="file:0", content=text)] if text.strip() else []

    chunks: list[ChunkSeed] = []
    boundary_indices.append(len(lines))

    for ordinal, start_index in enumerate(boundary_indices[:-1], start=1):
        end_index = boundary_indices[ordinal]
        segment = "\n".join(lines[start_index:end_index]).strip("\n")
        if not segment.strip():
            continue

        first_line = lines[start_index].strip()
        label = first_line.split("(")[0].split(":")[0].strip()
        base_anchor = f"{slugify_anchor_text(label, fallback='block')}:{ordinal}"
        parts = split_text_by_char_limit(segment, max_char_count=MAX_CHUNK_CHAR_COUNT)

        for part_index, part_content in enumerate(parts, start=1):
            anchor = base_anchor if len(parts) == 1 else f"{base_anchor}#part-{part_index}"
            chunks.append(
                ChunkSeed(
                    path=path,
                    language=language,
                    anchor=anchor,
                    content=part_content,
                )
            )

    return chunks
