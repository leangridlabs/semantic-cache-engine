from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess

from .hashing.sha256 import sha256_hex

from .ingest import IngestResult

BASELINE_DIR = Path(os.environ.get("SEMANTIC_CACHE_BASE_DIR", ".reason")) / "baselines"


@dataclass(frozen=True)
class SnapshotChunkRecord:
    chunk_id: str
    path: str
    anchor: str
    hash: str


@dataclass(frozen=True)
class SnapshotManifest:
    snapshot_id: str
    baseline_snapshot_id: str | None
    project_root: str
    source_commit: str | None
    created_utc: str
    chunk_count: int
    chunk_hash_index: dict[str, str]
    chunk_key_index: dict[str, str]
    dependency_graph_version: str
    reasoning_artifact_index: list[str]
    token_usage_summary: dict[str, int]
    chunks: list[SnapshotChunkRecord]

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["chunks"] = [asdict(chunk) for chunk in self.chunks]
        return payload


def _now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _snapshot_id() -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"snapshot-{stamp}"


def _derived_snapshot_id(ingest: IngestResult) -> str:
    payload = {
        "project_root": ingest.project_root,
        "chunks": [
            {
                "chunk_id": chunk.chunk_id,
                "path": chunk.path,
                "anchor": chunk.anchor,
                "hash": chunk.hash,
            }
            for chunk in sorted(ingest.chunks, key=lambda item: (item.path, item.anchor, item.chunk_id))
        ],
    }
    material = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return f"snapshot-{sha256_hex(material)[:20]}"


def _try_source_commit(project_root: Path) -> str | None:
    try:
        result = subprocess.run(
            ["git", "-C", str(project_root), "rev-parse", "HEAD"],
            check=True,
            capture_output=True,
            text=True,
        )
        value = result.stdout.strip()
        return value if value else None
    except (Exception, KeyboardInterrupt):
        return None


def build_snapshot_manifest(
    ingest: IngestResult,
    snapshot_id: str | None = None,
    baseline_snapshot_id: str | None = None,
) -> SnapshotManifest:
    records = [
        SnapshotChunkRecord(
            chunk_id=chunk.chunk_id,
            path=chunk.path,
            anchor=chunk.anchor,
            hash=chunk.hash,
        )
        for chunk in ingest.chunks
    ]

    chunk_hash_index = {record.chunk_id: record.hash for record in records}
    chunk_key_index = {f"{record.path}::{record.anchor}": record.hash for record in records}

    return SnapshotManifest(
        snapshot_id=snapshot_id or _derived_snapshot_id(ingest),
        baseline_snapshot_id=baseline_snapshot_id,
        project_root=ingest.project_root,
        source_commit=_try_source_commit(Path(ingest.project_root)),
        created_utc=_now_utc(),
        chunk_count=ingest.chunk_count,
        chunk_hash_index=chunk_hash_index,
        chunk_key_index=chunk_key_index,
        dependency_graph_version="phase-4-static-import-links",
        reasoning_artifact_index=[],
        token_usage_summary={
            "ingestion_tokens": 0,
            "retrieval_tokens": 0,
            "regeneration_tokens": 0,
            "total_tokens": 0,
        },
        chunks=records,
    )


def save_snapshot_manifest(snapshot: SnapshotManifest, baseline_dir: Path = BASELINE_DIR) -> Path:
    baseline_dir.mkdir(parents=True, exist_ok=True)
    output_path = baseline_dir / f"{snapshot.snapshot_id}.json"
    output_path.write_text(json.dumps(snapshot.to_dict(), indent=2), encoding="utf-8")
    return output_path


def load_snapshot_manifest(snapshot_id: str, baseline_dir: Path = BASELINE_DIR) -> SnapshotManifest:
    path = baseline_dir / f"{snapshot_id}.json"
    if not path.exists():
        raise FileNotFoundError(f"Snapshot not found: {path}")

    payload = json.loads(path.read_text(encoding="utf-8"))
    chunks = [SnapshotChunkRecord(**item) for item in payload.get("chunks", [])]
    return SnapshotManifest(
        snapshot_id=payload["snapshot_id"],
        baseline_snapshot_id=payload.get("baseline_snapshot_id"),
        project_root=payload["project_root"],
        source_commit=payload.get("source_commit"),
        created_utc=payload["created_utc"],
        chunk_count=payload["chunk_count"],
        chunk_hash_index=payload.get("chunk_hash_index", {}),
        chunk_key_index=payload.get("chunk_key_index", {}),
        dependency_graph_version=payload.get("dependency_graph_version", "unknown"),
        reasoning_artifact_index=payload.get("reasoning_artifact_index", []),
        token_usage_summary=payload.get("token_usage_summary", {}),
        chunks=chunks,
    )


def _is_snapshot_manifest_file(path: Path) -> bool:
    """Return True only if ``path`` parses as a snapshot manifest.

    The baseline directory may also contain unrelated JSON (measurement
    results, malformed files, etc.).  Snapshot discovery must ignore those
    rather than treating the newest arbitrary ``*.json`` as a snapshot.
    """
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError, ValueError):
        return False
    return isinstance(payload, dict) and "snapshot_id" in payload and "chunk_count" in payload


def latest_snapshot_id(baseline_dir: Path = BASELINE_DIR) -> str:
    candidates = sorted(
        (
            path
            for path in baseline_dir.glob("*.json")
            if path.is_file() and _is_snapshot_manifest_file(path)
        ),
        key=lambda item: item.stat().st_mtime,
        reverse=True,
    )
    if not candidates:
        raise FileNotFoundError(f"No snapshots found under {baseline_dir}")

    return candidates[0].stem
