"""Claim 11 — Local-first / no phone-home (alpha test Check A).

Arm A: monkeypatches the Python socket layer and runs representative local
engine operations (ingest → snapshot → scout pack → resolver routing) to prove
zero outbound connections are made during normal local use.

Telemetry schema: inline validation that forbidden payload keys (prompt,
source_code, etc.) are rejected by the schema layer.

No provider credentials are required — this is a purely local check.
"""
from __future__ import annotations

import json
import socket
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse


# ---------------------------------------------------------------------------
# Generic routing questions — work on any indexed repo (zero LLM either way).
# The point is that local routing makes no outbound calls, regardless of
# whether a card is found (recall) or not (agent_handoff).
# ---------------------------------------------------------------------------
_PROBE_QUESTIONS = [
    "What does this codebase do overall?",
    "How is the main entry point structured?",
    "How is error handling implemented here?",
    "What are the primary data structures used?",
    "How does configuration work in this project?",
]

_LOOPBACK_HOSTS = {"127.0.0.1", "::1", "localhost", "0.0.0.0", ""}


def _utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _is_loopback(host: str) -> bool:
    h = (host or "").strip().lower()
    return h in _LOOPBACK_HOSTS or h.startswith("127.")


class _EgressMonitor:
    """Records every DNS lookup and outbound TCP connect, by phase."""

    def __init__(self) -> None:
        self.events: list[dict] = []
        self.phase = "init"
        self.resolved_ips: dict[str, str] = {}
        self._orig_getaddrinfo = socket.getaddrinfo
        self._orig_connect = socket.socket.connect
        self._orig_connect_ex = socket.socket.connect_ex

    def _host_port(self, address: object) -> tuple[str, int | None]:
        if isinstance(address, tuple) and address:
            host = str(address[0])
            port = address[1] if len(address) > 1 else None
            try:
                port = int(port) if port is not None else None
            except (TypeError, ValueError):
                port = None
            return host, port
        return str(address), None

    def _record(self, kind: str, host: str, port: int | None) -> None:
        resolved_from = None
        if kind in ("connect", "connect_ex"):
            resolved_from = self.resolved_ips.get(host)
        self.events.append({
            "phase": self.phase,
            "kind": kind,
            "host": host,
            "port": port,
            "loopback": _is_loopback(host),
            "resolved_from": resolved_from,
        })

    def __enter__(self) -> "_EgressMonitor":
        monitor = self

        def patched_getaddrinfo(host, *args, **kwargs):
            result = monitor._orig_getaddrinfo(host, *args, **kwargs)
            for info in result:
                try:
                    ip = str(info[4][0])
                except (IndexError, TypeError):
                    continue
                if ip and not _is_loopback(ip):
                    monitor.resolved_ips[ip] = str(host)
            monitor._record("getaddrinfo", str(host), None)
            return result

        def patched_connect(self_sock, address):
            host, port = monitor._host_port(address)
            monitor._record("connect", host, port)
            return monitor._orig_connect(self_sock, address)

        def patched_connect_ex(self_sock, address):
            host, port = monitor._host_port(address)
            monitor._record("connect_ex", host, port)
            return monitor._orig_connect_ex(self_sock, address)

        socket.getaddrinfo = patched_getaddrinfo
        socket.socket.connect = patched_connect
        socket.socket.connect_ex = patched_connect_ex
        return self

    def __exit__(self, *exc: object) -> None:
        socket.getaddrinfo = self._orig_getaddrinfo
        socket.socket.connect = self._orig_connect
        socket.socket.connect_ex = self._orig_connect_ex

    def remote_hosts(self) -> set[str]:
        return {
            (e["resolved_from"] or e["host"]).lower()
            for e in self.events
            if not e["loopback"] and e["kind"] in ("connect", "connect_ex")
        }


def _run_telemetry_schema_check() -> dict:
    """Inline equivalent of test_telemetry_schema.py — no pytest required."""
    from .telemetry_schema import (
        TelemetryIdentity,
        build_telemetry_event,
        validate_telemetry_event,
    )

    identity = TelemetryIdentity(
        tenant_id="check-a",
        install_id="check-a",
        session_id="check-a",
        run_id="check-a",
        app_version="0.1.0",
        sidecar_version="check-a/0.1.0",
        policy_bundle_version="check-a",
    )

    # Test 1: normal event validates cleanly
    event_ok = build_telemetry_event(
        event_name="resolver.turn.completed",
        identity=identity,
        metrics={"route": "recall", "saved_tokens": 1200},
    )
    valid_ok, errors_ok = validate_telemetry_event(event_ok)

    # Test 2: forbidden key is rejected
    event_bad = build_telemetry_event(
        event_name="resolver.turn.completed",
        identity=identity,
        metrics={"nested": {"prompt": "leak"}},
    )
    valid_bad, errors_bad = validate_telemetry_event(event_bad)

    test1_pass = valid_ok and not errors_ok
    test2_pass = not valid_bad and any("forbidden" in e for e in errors_bad)

    return {
        "test_build_and_validate": {"pass": test1_pass, "errors": errors_ok},
        "test_rejects_forbidden_keys": {"pass": test2_pass, "errors": errors_bad},
        "overall_pass": test1_pass and test2_pass,
    }


def run_no_phone_home_check(
    project_path: Path,
    json_out: Path | None = None,
    progress: object = None,
) -> dict:
    """Run Check A: socket egress trace (Arm A) + telemetry schema validation.

    Args:
        project_path: The repo root to ingest and probe (the open workspace).
        json_out: Optional path to write the JSON result.
        progress: Optional callable(str) for progress messages.

    Returns:
        Result dict with arm_a_pass, telemetry_schema_pass, overall_pass.
    """
    def _prog(msg: str) -> None:
        if callable(progress):
            progress(msg)

    from .ingest import ingest_project
    from .snapshot import build_snapshot_manifest
    from .familiarization_packs import build_familiarization_pack
    from . import resolver
    from .resolver import resolve_developer_question

    _prog("check-a: starting socket egress monitor (Arm A)")
    monitor = _EgressMonitor()
    arm_a_ops: list[dict] = []

    with monitor:
        monitor.phase = "arm_a:ingest"
        _prog("check-a: ingesting project (local, zero LLM)")
        ingest = ingest_project(project_path)
        arm_a_ops.append({"op": "ingest_project", "chunks": len(ingest.chunks)})

        monitor.phase = "arm_a:snapshot"
        _prog("check-a: building snapshot manifest")
        manifest = build_snapshot_manifest(ingest, snapshot_id="check-a-egress-probe")
        arm_a_ops.append({"op": "build_snapshot_manifest", "chunk_count": manifest.chunk_count})

        monitor.phase = "arm_a:scout_pack"
        _prog("check-a: building scout familiarization pack")
        pack = build_familiarization_pack(project_path, mode="scout")
        arm_a_ops.append({"op": "build_familiarization_pack", "keys": sorted(pack.keys())[:4]})

        monitor.phase = "arm_a:resolve"
        _prog(f"check-a: routing {len(_PROBE_QUESTIONS)} probe questions (local, zero LLM)")
        routes: list[str] = []
        for q in _PROBE_QUESTIONS:
            resolver._FAST_LANE_LRU.clear()
            result = resolve_developer_question(project_path, q)
            routes.append(result.get("route", "?"))
        arm_a_ops.append({
            "op": "resolve_developer_question",
            "count": len(_PROBE_QUESTIONS),
            "routes": routes,
        })

    remote_hosts = sorted(monitor.remote_hosts())
    arm_a_pass = len(remote_hosts) == 0
    _prog(f"check-a: arm_a remote_hosts={remote_hosts!r} pass={arm_a_pass}")

    _prog("check-a: running telemetry schema validation")
    schema_result = _run_telemetry_schema_check()
    schema_pass = schema_result["overall_pass"]
    _prog(f"check-a: telemetry_schema_pass={schema_pass}")

    overall_pass = arm_a_pass and schema_pass

    report = {
        "status": "ok" if overall_pass else "fail",
        "generated_at": _utc_now(),
        "overall_pass": overall_pass,
        "arm_a": {
            "pass": arm_a_pass,
            "remote_hosts_detected": remote_hosts,
            "expected_remote_hosts": [],
            "operations": arm_a_ops,
            "total_socket_events": len(monitor.events),
        },
        "telemetry_schema": schema_result,
        "caveats": [
            "in-process Python socket-layer trace — catches all egress from this process's "
            "Python sockets; not a kernel packet capture.",
            "arm_b (intentional provider call) is omitted here — provider credentials are "
            "not required for Check A.",
        ],
    }

    if json_out is not None:
        out_path = Path(json_out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
        _prog(f"check-a: report written to {out_path}")

    return report
