from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from pathlib import Path
import re
from typing import Callable

from .snapshot import SnapshotManifest


@dataclass(frozen=True)
class DependencyGraph:
    version: str
    adjacency: dict[str, list[str]]
    reverse_adjacency: dict[str, list[str]]
    artifact_links: dict[str, list[str]]

    @property
    def edge_count(self) -> int:
        return sum(len(targets) for targets in self.adjacency.values())

    def impacted_chunks(self, changed_chunks: list[str]) -> list[str]:
        impacted: set[str] = set()
        queue: deque[str] = deque(sorted(set(changed_chunks)))

        while queue:
            key = queue.popleft()
            if key in impacted:
                continue

            impacted.add(key)
            for dependent in self.reverse_adjacency.get(key, []):
                if dependent not in impacted:
                    queue.append(dependent)

        return sorted(impacted)

    def artifacts_for_chunks(self, chunk_keys: list[str]) -> list[str]:
        artifacts: set[str] = set()
        for key in sorted(set(chunk_keys)):
            for artifact in self.artifact_links.get(key, []):
                artifacts.add(artifact)
        return sorted(artifacts)


_PY_IMPORT_RE = re.compile(r"^\s*import\s+([a-zA-Z0-9_\.,\s]+)", re.MULTILINE)
_PY_FROM_RE = re.compile(r"^\s*from\s+([\.a-zA-Z0-9_]+)\s+import\s+", re.MULTILINE)
_JS_IMPORT_RE = re.compile(r"import\s+[^;]*?from\s+[\"']([^\"']+)[\"']")
_JS_REQUIRE_RE = re.compile(r"require\([\"']([^\"']+)[\"']\)")
_MD_LINK_RE = re.compile(r"\[[^\]]+\]\(([^)]+)\)")


def build_dependency_graph(
    project_root: Path,
    snapshot: SnapshotManifest,
    progress: Callable[[str], None] | None = None,
    heartbeat_every: int = 100,
) -> DependencyGraph:
    chunk_keys_by_path: dict[str, list[str]] = {}
    chunk_id_by_key: dict[str, str] = {}

    for record in snapshot.chunks:
        key = _chunk_key(record.path, record.anchor)
        chunk_keys_by_path.setdefault(record.path, []).append(key)
        chunk_id_by_key[key] = record.chunk_id

    for path in chunk_keys_by_path:
        chunk_keys_by_path[path].sort()

    # Use one stable representative chunk per file to avoid quadratic cross-file
    # edge expansion in large repositories while preserving dependency reachability.
    primary_chunk_by_path = {
        path: keys[0]
        for path, keys in chunk_keys_by_path.items()
        if keys
    }

    artifact_links = {
        key: [f"reasoning::{chunk_id_by_key[key]}"]
        for key in sorted(chunk_id_by_key.keys())
    }

    adjacency: dict[str, set[str]] = {key: set() for key in chunk_id_by_key}
    source_paths = sorted(chunk_keys_by_path.keys())
    if progress:
        progress(f"dependency-graph: scanning {len(source_paths)} source path(s)")

    for index, source_path in enumerate(source_paths, start=1):
        source_file = project_root / source_path
        if not source_file.exists() or not source_file.is_file():
            continue

        try:
            text = source_file.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            text = source_file.read_text(encoding="utf-8", errors="ignore")

        target_paths = _extract_target_paths(source_path, text, set(chunk_keys_by_path.keys()))
        if not target_paths:
            continue

        source_key = primary_chunk_by_path.get(source_path)
        if source_key is None:
            continue

        for target_path in sorted(target_paths):
            target_key = primary_chunk_by_path.get(target_path)
            if target_key and source_key != target_key:
                adjacency[source_key].add(target_key)

        if progress and heartbeat_every > 0 and index % heartbeat_every == 0:
            current_edges = sum(len(values) for values in adjacency.values())
            progress(
                f"dependency-graph: processed {index}/{len(source_paths)} path(s); "
                f"edge_count~{current_edges}"
            )

    adjacency_lists = {
        key: sorted(values)
        for key, values in sorted(adjacency.items(), key=lambda item: item[0])
    }

    reverse: dict[str, set[str]] = {key: set() for key in adjacency_lists}
    for source_key, targets in adjacency_lists.items():
        for target_key in targets:
            reverse.setdefault(target_key, set()).add(source_key)

    reverse_lists = {
        key: sorted(values)
        for key, values in sorted(reverse.items(), key=lambda item: item[0])
    }

    graph = DependencyGraph(
        version="phase-4-static-import-links",
        adjacency=adjacency_lists,
        reverse_adjacency=reverse_lists,
        artifact_links=artifact_links,
    )
    if progress:
        progress(f"dependency-graph: complete edge_count={graph.edge_count}")
    return graph


def _chunk_key(path: str, anchor: str) -> str:
    return f"{path}::{anchor}"


def _extract_target_paths(source_path: str, text: str, known_paths: set[str]) -> set[str]:
    source_suffix = Path(source_path).suffix.lower()
    raw_targets: set[str] = set()

    if source_suffix == ".py":
        raw_targets |= _extract_python_targets(source_path, text)
    elif source_suffix in {".ts", ".tsx", ".js", ".jsx"}:
        raw_targets |= _extract_js_targets(text)
    elif source_suffix in {".md", ".markdown"}:
        raw_targets |= _extract_markdown_targets(text)

    resolved: set[str] = set()
    for target in raw_targets:
        resolved_path = _resolve_target_path(source_path, target, known_paths)
        if resolved_path:
            resolved.add(resolved_path)

    return resolved


def _extract_python_targets(source_path: str, text: str) -> set[str]:
    modules: set[str] = set()

    for match in _PY_IMPORT_RE.findall(text):
        parts = [part.strip() for part in match.split(",") if part.strip()]
        for part in parts:
            module = part.split(" as ", 1)[0].strip()
            if module:
                modules.add(module)

    for module in _PY_FROM_RE.findall(text):
        modules.add(module.strip())

    targets: set[str] = set()
    for module in modules:
        if not module:
            continue

        if module.startswith("."):
            targets.add(_resolve_relative_python_module(source_path, module))
        else:
            targets.add(module.replace(".", "/"))

    return targets


def _resolve_relative_python_module(source_path: str, module: str) -> str:
    leading_dots = len(module) - len(module.lstrip("."))
    module_tail = module.lstrip(".")

    base = Path(source_path).parent
    for _ in range(max(leading_dots - 1, 0)):
        base = base.parent

    if module_tail:
        base = base / module_tail.replace(".", "/")

    return base.as_posix()


def _extract_js_targets(text: str) -> set[str]:
    return set(_JS_IMPORT_RE.findall(text)) | set(_JS_REQUIRE_RE.findall(text))


def _extract_markdown_targets(text: str) -> set[str]:
    targets: set[str] = set()
    for link in _MD_LINK_RE.findall(text):
        if link.startswith(("http://", "https://", "mailto:", "#")):
            continue

        clean = link.split("#", 1)[0].strip()
        if clean:
            targets.add(clean)

    return targets


def _resolve_target_path(source_path: str, target: str, known_paths: set[str]) -> str | None:
    normalized = target.replace("\\", "/")

    if normalized.startswith(("./", "../")):
        base = (Path(source_path).parent / normalized).as_posix()
        return _resolve_with_candidates(base, known_paths)

    if "/" in normalized or normalized.isidentifier() or "." in normalized:
        return _resolve_with_candidates(normalized, known_paths)

    return None


def _resolve_with_candidates(base: str, known_paths: set[str]) -> str | None:
    candidate_path = Path(base)

    candidates = [candidate_path.as_posix()]
    if candidate_path.suffix:
        candidates.append(candidate_path.with_suffix("").as_posix())
    else:
        candidates.extend(
            [
                candidate_path.with_suffix(".py").as_posix(),
                candidate_path.with_suffix(".ts").as_posix(),
                candidate_path.with_suffix(".tsx").as_posix(),
                candidate_path.with_suffix(".js").as_posix(),
                candidate_path.with_suffix(".jsx").as_posix(),
                candidate_path.with_suffix(".md").as_posix(),
                (candidate_path / "__init__.py").as_posix(),
                (candidate_path / "index.ts").as_posix(),
                (candidate_path / "index.tsx").as_posix(),
                (candidate_path / "index.js").as_posix(),
                (candidate_path / "index.jsx").as_posix(),
                (candidate_path / "README.md").as_posix(),
            ]
        )

    for candidate in candidates:
        if candidate in known_paths:
            return candidate

    return None
