from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from time import perf_counter
from typing import Any
from typing import Callable
from typing import Iterator
from urllib import error, request


@dataclass(frozen=True)
class ProviderUsage:
    mode: str
    provider: str | None
    model: str | None
    captured: bool
    prompt_tokens: int | None
    completion_tokens: int | None
    total_tokens: int | None
    latency_ms: float | None
    error: str | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _emit_progress(progress: Callable[[str], None] | None, message: str) -> None:
    if progress:
        progress(message)


def capture_provider_usage(
    *,
    run_id: str,
    live_provider: str,
    provider_base_url: str,
    provider_model: str,
    provider_api_key: str | None,
    provider_api_version: str | None = None,
    generated_artifact_count: int,
    reused_artifact_count: int,
    hydration_mode: str = "probe",
    hydration_documents: list[str] | None = None,
    progress: Callable[[str], None] | None = None,
) -> ProviderUsage:
    mode = (live_provider or "none").strip().lower()
    _emit_progress(progress, f"provider-usage: start mode={mode} hydration={hydration_mode or 'probe'}")

    if mode == "none":
        _emit_progress(progress, "provider-usage: skipped mode=none")
        return ProviderUsage(
            mode="none",
            provider=None,
            model=None,
            captured=False,
            prompt_tokens=None,
            completion_tokens=None,
            total_tokens=None,
            latency_ms=None,
            error=None,
        )

    if mode == "mock":
        prompt_tokens = (generated_artifact_count * 24) + (reused_artifact_count * 4) + 16
        completion_tokens = max(generated_artifact_count * 8, 8)
        total_tokens = prompt_tokens + completion_tokens
        _emit_progress(progress, f"provider-usage: mock complete total_tokens={total_tokens}")
        return ProviderUsage(
            mode="mock",
            provider="mock",
            model="mock-phase9",
            captured=True,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            latency_ms=1.0,
            error=None,
        )

    if mode != "openai-compatible":
        _emit_progress(progress, f"provider-usage: unsupported mode={mode}")
        return ProviderUsage(
            mode=mode,
            provider=None,
            model=provider_model,
            captured=False,
            prompt_tokens=None,
            completion_tokens=None,
            total_tokens=None,
            latency_ms=None,
            error=f"Unsupported live provider mode: {mode}",
        )

    if not provider_api_key:
        _emit_progress(progress, "provider-usage: skipped missing_api_key")
        return ProviderUsage(
            mode=mode,
            provider="openai-compatible",
            model=provider_model,
            captured=False,
            prompt_tokens=None,
            completion_tokens=None,
            total_tokens=None,
            latency_ms=None,
            error="SEMANTIC_CACHE_PROVIDER_API_KEY is required for openai-compatible mode",
        )

    hydration_key = (hydration_mode or "probe").strip().lower()

    if hydration_key == "probe":
        _emit_progress(progress, f"provider-usage: probe request start model={provider_model}")
        payload = {
            "model": provider_model,
            "messages": [
                {
                    "role": "system",
                    "content": "You are a concise summarizer.",
                },
                {
                    "role": "user",
                    "content": (
                        "Return a short acknowledgment for token telemetry capture. "
                        f"run_id={run_id}; generated={generated_artifact_count}; reused={reused_artifact_count}."
                    ),
                },
            ],
            "max_tokens": 16,
            "temperature": 0,
        }
        usage = _send_openai_compatible_request(
            provider_base_url=provider_base_url,
            provider_model=provider_model,
            provider_api_key=provider_api_key,
            payload=payload,
            mode=mode,
            provider_api_version=provider_api_version,
        )
        _emit_progress(
            progress,
            "provider-usage: probe request complete "
            f"latency_ms={usage.latency_ms} captured={int(usage.captured)} error={usage.error or 'none'}",
        )
        return usage

    if hydration_key != "full-repo":
        _emit_progress(progress, f"provider-usage: unsupported hydration={hydration_key}")
        return ProviderUsage(
            mode=mode,
            provider="openai-compatible",
            model=provider_model,
            captured=False,
            prompt_tokens=None,
            completion_tokens=None,
            total_tokens=None,
            latency_ms=None,
            error=f"Unsupported provider hydration mode: {hydration_key}",
        )

    documents = hydration_documents or []
    if not documents:
        _emit_progress(progress, "provider-usage: full-repo skipped empty_documents")
        return ProviderUsage(
            mode=mode,
            provider="openai-compatible",
            model=provider_model,
            captured=False,
            prompt_tokens=None,
            completion_tokens=None,
            total_tokens=None,
            latency_ms=None,
            error="Full-repo hydration requested but no documents were provided",
        )

    batches = list(_iter_hydration_batches(documents))
    aggregate_prompt = 0
    aggregate_completion = 0
    aggregate_total = 0
    aggregate_latency = 0.0

    for index, batch in enumerate(batches, start=1):
        if progress:
            progress(f"provider-hydration: sending batch {index}")
            progress(f"provider-hydration: request start batch {index} model={provider_model}")
        payload = {
            "model": provider_model,
            "messages": [
                {
                    "role": "system",
                    "content": "Hydration telemetry mode.",
                },
                {
                    "role": "user",
                    "content": (
                        f"Hydration batch {index} for run {run_id}. Reply with one token.\n\n"
                        f"{batch}"
                    ),
                },
            ],
            "max_tokens": 1,
            "temperature": 0,
        }
        usage = _send_openai_compatible_request(
            provider_base_url=provider_base_url,
            provider_model=provider_model,
            provider_api_key=provider_api_key,
            payload=payload,
            mode=mode,
            provider_api_version=provider_api_version,
        )
        _emit_progress(
            progress,
            "provider-hydration: request complete "
            f"batch {index} latency_ms={usage.latency_ms} captured={int(usage.captured)} "
            f"error={usage.error or 'none'}",
        )
        if not usage.captured or usage.total_tokens is None:
            return ProviderUsage(
                mode=mode,
                provider="openai-compatible",
                model=provider_model,
                captured=False,
                prompt_tokens=None,
                completion_tokens=None,
                total_tokens=None,
                latency_ms=None,
                error=(
                    f"Hydration batch {index} failed: "
                    f"{usage.error or 'missing usage data'}"
                ),
            )

        aggregate_prompt += int(usage.prompt_tokens or 0)
        aggregate_completion += int(usage.completion_tokens or 0)
        aggregate_total += int(usage.total_tokens or 0)
        aggregate_latency += float(usage.latency_ms or 0.0)
        if progress:
            progress(
                "provider-hydration: completed batch "
                f"{index}/{len(batches)} total_tokens={aggregate_total}"
            )

    return ProviderUsage(
        mode=mode,
        provider="openai-compatible",
        model=provider_model,
        captured=True,
        prompt_tokens=aggregate_prompt,
        completion_tokens=aggregate_completion,
        total_tokens=aggregate_total,
        latency_ms=round(aggregate_latency, 3),
        error=None,
    )


def _build_hydration_batches(documents: list[str], max_chars_per_batch: int = 6000) -> list[str]:
    return list(_iter_hydration_batches(documents, max_chars_per_batch=max_chars_per_batch))


def _iter_hydration_batches(documents: list[str], max_chars_per_batch: int = 6000) -> Iterator[str]:
    current_docs: list[str] = []
    current_chars = 0

    for doc in documents:
        parts = _split_document(doc, max_chars_per_batch)
        for part in parts:
            doc_chars = len(part)
            if current_docs and current_chars + doc_chars > max_chars_per_batch:
                yield "\n\n".join(current_docs)
                current_docs = [part]
                current_chars = doc_chars
                continue

            current_docs.append(part)
            current_chars += doc_chars

    if current_docs:
        yield "\n\n".join(current_docs)


def _split_document(document: str, max_chars: int) -> list[str]:
    if len(document) <= max_chars:
        return [document]

    parts: list[str] = []
    start = 0
    length = len(document)
    while start < length:
        end = min(start + max_chars, length)
        parts.append(document[start:end])
        start = end
    return parts


def _build_provider_request(
    *,
    provider_base_url: str,
    provider_model: str,
    provider_api_key: str,
    provider_api_version: str | None,
) -> tuple[str, dict[str, str]]:
    """Return (endpoint, headers) for the target provider.

    Azure OpenAI is detected when an api-version is supplied or the base URL
    points at an Azure endpoint. Azure uses the
    `/openai/deployments/{deployment}/chat/completions?api-version=...` route
    with an `api-key` header. All other OpenAI-compatible providers use the
    standard `/chat/completions` route with `Authorization: Bearer`.
    """
    base = provider_base_url.rstrip("/")
    is_azure = bool(provider_api_version) or "azure.com" in base.lower()

    if is_azure:
        api_version = provider_api_version or "2024-10-21"
        endpoint = (
            f"{base}/openai/deployments/{provider_model}"
            f"/chat/completions?api-version={api_version}"
        )
        headers = {
            "api-key": provider_api_key,
            "Content-Type": "application/json",
        }
        return endpoint, headers

    endpoint = f"{base}/chat/completions"
    headers = {
        "Authorization": f"Bearer {provider_api_key}",
        "Content-Type": "application/json",
    }
    return endpoint, headers


def _is_reasoning_model(provider_model: str) -> bool:
    """Detect OpenAI/Azure reasoning-class models (gpt-5.x, o1/o3/o4 series).

    These models reject `max_tokens` (require `max_completion_tokens`) and only
    accept the default `temperature`.
    """
    name = (provider_model or "").strip().lower()
    if name.startswith(("o1", "o3", "o4")):
        return True
    return "gpt-5" in name or "gpt5" in name


def _normalize_payload_for_model(provider_model: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Adapt a chat payload to the target model's parameter constraints."""
    if not _is_reasoning_model(provider_model):
        return payload

    normalized = dict(payload)
    if "max_tokens" in normalized:
        normalized["max_completion_tokens"] = normalized.pop("max_tokens")
    # Reasoning models only accept the default temperature; drop overrides.
    if normalized.get("temperature") not in (None, 1):
        normalized.pop("temperature", None)
    return normalized


def _send_openai_compatible_request(
    *,
    provider_base_url: str,
    provider_model: str,
    provider_api_key: str,
    payload: dict[str, Any],
    mode: str,
    provider_api_version: str | None = None,
) -> ProviderUsage:
    endpoint, headers = _build_provider_request(
        provider_base_url=provider_base_url,
        provider_model=provider_model,
        provider_api_key=provider_api_key,
        provider_api_version=provider_api_version,
    )
    payload = _normalize_payload_for_model(provider_model, payload)
    data = json.dumps(payload).encode("utf-8")
    req = request.Request(
        endpoint,
        data=data,
        headers=headers,
        method="POST",
    )

    try:
        started = perf_counter()
        with request.urlopen(req, timeout=180) as response:
            raw = response.read().decode("utf-8")
        latency_ms = round((perf_counter() - started) * 1000.0, 3)
        parsed = json.loads(raw)
        usage = parsed.get("usage", {})

        prompt_tokens = _to_int(usage.get("prompt_tokens"))
        completion_tokens = _to_int(usage.get("completion_tokens"))
        total_tokens = _to_int(usage.get("total_tokens"))
        if total_tokens is None and prompt_tokens is not None and completion_tokens is not None:
            total_tokens = prompt_tokens + completion_tokens

        captured = total_tokens is not None
        error_text = None if captured else "Provider response missing usage token fields"

        return ProviderUsage(
            mode=mode,
            provider="openai-compatible",
            model=provider_model,
            captured=captured,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            latency_ms=latency_ms,
            error=error_text,
        )
    except error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="ignore")
        return ProviderUsage(
            mode=mode,
            provider="openai-compatible",
            model=provider_model,
            captured=False,
            prompt_tokens=None,
            completion_tokens=None,
            total_tokens=None,
            latency_ms=None,
            error=f"HTTP {exc.code}: {detail}",
        )
    except Exception as exc:  # pragma: no cover - safety net
        return ProviderUsage(
            mode=mode,
            provider="openai-compatible",
            model=provider_model,
            captured=False,
            prompt_tokens=None,
            completion_tokens=None,
            total_tokens=None,
            latency_ms=None,
            error=str(exc),
        )


def compute_provider_cost_metrics(
    provider_usage: ProviderUsage,
    baseline_equivalent_tokens: int,
) -> dict[str, int | float | None]:
    total_tokens = provider_usage.total_tokens
    if total_tokens is None:
        return {
            "captured": 0,
            "actual_provider_tokens": None,
            "saved_tokens_vs_baseline": None,
            "saved_ratio_vs_baseline": None,
        }

    saved_tokens = max(baseline_equivalent_tokens - total_tokens, 0)
    saved_ratio = (saved_tokens / baseline_equivalent_tokens) if baseline_equivalent_tokens else 0.0
    return {
        "captured": 1,
        "actual_provider_tokens": total_tokens,
        "saved_tokens_vs_baseline": saved_tokens,
        "saved_ratio_vs_baseline": round(saved_ratio, 6),
    }


def _to_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None
