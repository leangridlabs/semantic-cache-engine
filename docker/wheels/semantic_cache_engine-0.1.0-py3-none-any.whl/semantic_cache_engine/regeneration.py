from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path

from .delta import compute_delta_report
from .ingest import ingest_project
from .snapshot import build_snapshot_manifest, save_snapshot_manifest


@dataclass(frozen=True)
class InvalidationPlan:
    baseline_snapshot_id: str
    current_snapshot_id: str
    changed_chunks: list[str]
    affected_chunks: list[str]
    invalidated_artifacts: list[str]

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class RegenerationResult:
    run_id: str
    plan: InvalidationPlan
    regenerated_artifacts: list[str]
    reused_artifacts: list[str]
    snapshot_written: str
    snapshot_path: str

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["plan"] = self.plan.to_dict()
        return payload


def build_invalidation_plan(project_path: Path, against_snapshot_id: str) -> InvalidationPlan:
    report = compute_delta_report(project_path.resolve(), against_snapshot_id)
    return InvalidationPlan(
        baseline_snapshot_id=report.baseline_snapshot_id,
        current_snapshot_id=report.current_snapshot_id,
        changed_chunks=report.changed_chunks,
        affected_chunks=report.affected_chunks,
        invalidated_artifacts=report.invalidated_artifacts,
    )


def execute_regeneration(project_path: Path, against_snapshot_id: str) -> RegenerationResult:
    report = compute_delta_report(project_path.resolve(), against_snapshot_id)
    plan = InvalidationPlan(
        baseline_snapshot_id=report.baseline_snapshot_id,
        current_snapshot_id=report.current_snapshot_id,
        changed_chunks=report.changed_chunks,
        affected_chunks=report.affected_chunks,
        invalidated_artifacts=report.invalidated_artifacts,
    )

    regenerated = sorted(set(report.regenerated_artifacts))
    reused = sorted(set(plan.invalidated_artifacts) - set(regenerated))

    ingest_result = ingest_project(project_path.resolve())
    next_snapshot = build_snapshot_manifest(
        ingest=ingest_result,
        baseline_snapshot_id=against_snapshot_id,
    )
    snapshot_path = save_snapshot_manifest(next_snapshot)

    return RegenerationResult(
        run_id=report.run_id,
        plan=plan,
        regenerated_artifacts=regenerated,
        reused_artifacts=reused,
        snapshot_written=next_snapshot.snapshot_id,
        snapshot_path=str(snapshot_path),
    )


def regeneration_to_json(project_path: Path, against_snapshot_id: str) -> str:
    result = execute_regeneration(project_path.resolve(), against_snapshot_id)
    return json.dumps(result.to_dict(), indent=2)
