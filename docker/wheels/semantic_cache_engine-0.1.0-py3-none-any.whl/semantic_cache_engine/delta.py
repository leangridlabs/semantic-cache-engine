from __future__ import annotations

from dataclasses import asdict, dataclass, replace as _dataclass_replace
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import subprocess
from time import perf_counter
from typing import Callable

from .chunking.dispatcher import dispatch_chunk
from .chunking.normalization import normalize_text

from .cache import build_cache_entry, create_cache_backend
from .churn_guard import (
    ChurnGuardMode,
    ChurnGuardDecision,
    ChurnGuardPolicy,
    compute_active_churn_rate,
    compute_modified_only_rate,
    compute_churn_rate,
    evaluate_churn_guard,
)
from .dependency_graph import build_dependency_graph
from .ingest import collect_hydration_documents, ingest_project
from .local_embeddings import build_local_embedding
from .playbooks import load_playbook
from .provider_usage import capture_provider_usage, compute_provider_cost_metrics
from .reasoning import hydrate_reasoning_artifacts
from .reasoning_memory import purge_stale_cards_for_paths
from .settings import load_settings
from .hashing.sha256 import sha256_hex
from .snapshot import SnapshotChunkRecord, SnapshotManifest, build_snapshot_manifest, load_snapshot_manifest
from .telemetry import build_usage_events, compute_cost_metrics
from .vector_store import CacheBackedVectorStore


@dataclass(frozen=True)
class DeltaStatusCounts:
    UNCHANGED: int
    MODIFIED: int
    NEW: int
    DELETED: int


@dataclass(frozen=True)
class DeltaRunReport:
    run_id: str
    baseline_snapshot_id: str
    current_snapshot_id: str
    created_utc: str
    chunk_status_counts: DeltaStatusCounts
    changed_chunks: list[str]
    affected_chunks: list[str]
    invalidated_artifacts: list[str]
    regenerated_artifacts: list[str]
    cache_metrics: dict[str, float | int]
    dependency_metrics: dict[str, int]
    reasoning_metrics: dict[str, int]
    usage_events: list[dict[str, int | str]]
    cost_metrics: dict[str, int]
    semantic_similarity_metrics: dict[str, int | float | str | None]
    provider_usage: dict[str, str | int | float | bool | None]
    provider_cost_metrics: dict[str, int | float | None]
    execution_profile: dict[str, str | int | None]
    churn_guard: dict[str, object]
    runtime_seconds: float

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["chunk_status_counts"] = asdict(self.chunk_status_counts)
        return payload


def _now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _run_id() -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"delta-{stamp}"


def _get_git_dirty_files(project_path: Path) -> list[str]:
    """Return workspace-relative posix paths of files with uncommitted changes.

    Uses ``git diff HEAD --name-only`` which covers both staged and unstaged
    modifications vs the last commit.  Returns an empty list if the project is
    not a git repo or git is unavailable.
    """
    try:
        result = subprocess.run(
            ["git", "-C", str(project_path), "diff", "HEAD", "--name-only"],
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
        if result.returncode != 0:
            return []
        return [f.strip() for f in result.stdout.splitlines() if f.strip()]
    except Exception:
        return []


def _augment_snapshot_with_git_dirty(
    project_path: Path,
    baseline: SnapshotManifest,
    current_snapshot: SnapshotManifest,
    progress: Callable[[str], None] | None = None,
) -> SnapshotManifest:
    """Merge re-hashed git-dirty files into current_snapshot's chunk_key_index.

    The playbook token budget stops the current ingest before reaching deep
    source files in large repos.  Those files then appear DELETED in the
    delta (present in baseline, absent from current) even when only a comment
    was added.  This function detects files that git considers modified and
    re-hashes them outside the token budget so the delta can classify them
    correctly as MODIFIED / NEW rather than DELETED.

    Silently skips any file that cannot be read or chunked.  Returns
    current_snapshot unchanged when no relevant dirty files are found.
    """
    dirty_files = _get_git_dirty_files(project_path)
    if not dirty_files:
        return current_snapshot

    # Only augment files that the baseline already knows about; brand-new files
    # are already NEW-classified by the normal ingest path if within budget, and
    # out-of-budget NEW files are not referenced by any existing reasoning cards
    # so there is nothing to invalidate.
    baseline_paths = {key.split("::")[0] for key in baseline.chunk_key_index}
    relevant = [f for f in dirty_files if f in baseline_paths]
    if not relevant:
        return current_snapshot

    if progress:
        progress(
            f"delta: git-dirty augmentation — re-hashing {len(relevant)} modified file(s) "
            "outside playbook scope"
        )

    augmented_keys = dict(current_snapshot.chunk_key_index)
    for rel_path in relevant:
        abs_path = project_path / rel_path
        if not abs_path.exists():
            # Deleted file — leave it absent from current so it classifies as DELETED.
            continue
        try:
            text = abs_path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        seeds = dispatch_chunk(rel_path, text)
        for seed in seeds:
            normalized = normalize_text(seed.content)
            if not normalized:
                continue
            key = f"{seed.path}::{seed.anchor}"
            augmented_keys[key] = sha256_hex(normalized)

    if augmented_keys == current_snapshot.chunk_key_index:
        return current_snapshot

    return _dataclass_replace(current_snapshot, chunk_key_index=augmented_keys)


def _classify(
    previous: SnapshotManifest,
    current: SnapshotManifest,
) -> tuple[DeltaStatusCounts, list[str]]:
    previous_keys = previous.chunk_key_index
    current_keys = current.chunk_key_index

    unchanged = 0
    modified = 0
    new = 0
    deleted = 0
    changed: list[str] = []

    all_keys = sorted(set(previous_keys.keys()) | set(current_keys.keys()))
    for key in all_keys:
        in_previous = key in previous_keys
        in_current = key in current_keys

        if in_previous and in_current:
            if previous_keys[key] == current_keys[key]:
                unchanged += 1
            else:
                modified += 1
                changed.append(key)
            continue

        if in_current:
            new += 1
            changed.append(key)
        else:
            deleted += 1
            changed.append(key)

    return (
        DeltaStatusCounts(
            UNCHANGED=unchanged,
            MODIFIED=modified,
            NEW=new,
            DELETED=deleted,
        ),
        changed,
    )


def _cache_metrics_for_current_snapshot(
    current: SnapshotManifest,
    project_root: Path,
    backend,
    progress: Callable[[str], None] | None = None,
    heartbeat_every: int = 200,
) -> dict[str, float | int]:
    vector_store = CacheBackedVectorStore(backend)
    backend.ensure_schema()

    hit_count = 0
    miss_count = 0
    total_chunks = len(current.chunks)
    if progress:
        progress(f"cache: evaluating {total_chunks} chunk embedding(s)")

    seed_cache_by_path: dict[str, dict[str, str]] = {}

    def _resolve_chunk_content(chunk_path: str, chunk_anchor: str) -> str:
        by_anchor = seed_cache_by_path.get(chunk_path)
        if by_anchor is None:
            by_anchor = {}
            absolute_path = project_root / chunk_path
            if absolute_path.exists() and absolute_path.is_file():
                try:
                    text = absolute_path.read_text(encoding="utf-8")
                except UnicodeDecodeError:
                    text = absolute_path.read_text(encoding="utf-8", errors="ignore")

                for seed in dispatch_chunk(chunk_path, text):
                    normalized = normalize_text(seed.content)
                    if normalized:
                        by_anchor[seed.anchor] = normalized

            seed_cache_by_path[chunk_path] = by_anchor

        return by_anchor.get(chunk_anchor, "")

    lookup_batch_size = 400
    index = 0
    miss_entries: list = []
    miss_chunks_for_vectors: list = []
    for start in range(0, total_chunks, lookup_batch_size):
        batch = current.chunks[start : start + lookup_batch_size]
        key_pairs = [(chunk.chunk_id, chunk.hash) for chunk in batch]
        existing_entries = backend.get_cache_entries_map(key_pairs, entry_type="embedding")

        for chunk in batch:
            index += 1
            if (chunk.chunk_id, chunk.hash) in existing_entries:
                hit_count += 1
            else:
                miss_count += 1
                miss_entries.append(
                    build_cache_entry(
                        chunk_id=chunk.chunk_id,
                        chunk_hash=chunk.hash,
                        entry_type="embedding",
                        version="phase-3",
                        metadata={
                            "path": chunk.path,
                            "anchor": chunk.anchor,
                        },
                    )
                )
                miss_chunks_for_vectors.append(chunk)

        # Batch-write all miss cache entries for this lookup batch in one transaction.
        if hasattr(backend, "batch_upsert_cache_entries"):
            backend.batch_upsert_cache_entries(miss_entries)
        else:
            for entry in miss_entries:
                backend.upsert_cache_entry(entry)
        miss_entries.clear()

        for chunk in miss_chunks_for_vectors:
            vector_store.upsert_reference(
                chunk_id=chunk.chunk_id,
                chunk_hash=chunk.hash,
                provider="none",
                model="none",
                vector_ref="pending",
            )
            chunk_content = _resolve_chunk_content(chunk.path, chunk.anchor)
            embedding_input = chunk_content or f"{chunk.path}\n{chunk.anchor}"
            vector_store.upsert_embedding(
                chunk_id=chunk.chunk_id,
                chunk_hash=chunk.hash,
                values=build_local_embedding(embedding_input),
                provider="local",
                model="local-hash-v1",
            )
            vector_store.upsert_reference(
                chunk_id=chunk.chunk_id,
                chunk_hash=chunk.hash,
                provider="local",
                model="local-hash-v1",
                vector_ref="local://vector_embeddings/local-hash-v1",
            )
        miss_chunks_for_vectors.clear()
        if progress and heartbeat_every > 0 and index % heartbeat_every == 0:
            progress(
                f"cache: processed {index}/{total_chunks} chunk embedding(s); "
                f"hits={hit_count}, misses={miss_count}"
            )

    total = hit_count + miss_count
    hit_ratio = (hit_count / total) if total else 0.0
    return {
        "hit_count": hit_count,
        "miss_count": miss_count,
        "hit_ratio": hit_ratio,
    }


def _artifact_to_semantic_text(payload: dict[str, object]) -> str:
    lines: list[str] = []
    explanation = payload.get("explanation")
    if isinstance(explanation, str) and explanation.strip():
        lines.append(explanation.strip())

    for key in ("architectural_insights", "rules_extracted", "dependency_notes"):
        value = payload.get(key)
        if not isinstance(value, list):
            continue
        for item in value:
            if isinstance(item, str) and item.strip():
                lines.append(item.strip())

    return "\n".join(lines)


def _cosine_similarity(vector_a: list[float], vector_b: list[float]) -> float:
    if len(vector_a) != len(vector_b) or not vector_a:
        return 0.0

    dot = 0.0
    norm_a = 0.0
    norm_b = 0.0
    for a, b in zip(vector_a, vector_b):
        dot += a * b
        norm_a += a * a
        norm_b += b * b

    if norm_a <= 0.0 or norm_b <= 0.0:
        return 0.0

    return dot / (math.sqrt(norm_a) * math.sqrt(norm_b))


def _record_lookup_by_chunk_key(snapshot: SnapshotManifest) -> dict[str, SnapshotChunkRecord]:
    return {f"{record.path}::{record.anchor}": record for record in snapshot.chunks}


def _compute_semantic_similarity_metrics(
    baseline: SnapshotManifest,
    current_snapshot: SnapshotManifest,
    changed_keys: list[str],
    backend,
    similarity_threshold: float = 0.8,
) -> dict[str, int | float | str | None]:
    baseline_records = _record_lookup_by_chunk_key(baseline)
    current_records = _record_lookup_by_chunk_key(current_snapshot)
    modified_keys = [
        key
        for key in changed_keys
        if key in baseline.chunk_key_index
        and key in current_snapshot.chunk_key_index
        and baseline.chunk_key_index.get(key) != current_snapshot.chunk_key_index.get(key)
    ]

    scores: list[float] = []
    pass_count = 0
    reasoning_pair_count = 0
    embedding_fallback_pair_count = 0
    for key in modified_keys:
        baseline_record = baseline_records.get(key)
        current_record = current_records.get(key)
        if baseline_record is None or current_record is None:
            continue

        previous_lookup = backend.get_cache_entry(
            baseline_record.chunk_id,
            baseline_record.hash,
            entry_type="reasoning",
        )
        current_lookup = backend.get_cache_entry(
            current_record.chunk_id,
            current_record.hash,
            entry_type="reasoning",
        )
        scored = False
        if previous_lookup.hit and previous_lookup.entry and current_lookup.hit and current_lookup.entry:
            previous_artifact = previous_lookup.entry.metadata.get("artifact")
            current_artifact = current_lookup.entry.metadata.get("artifact")
            if isinstance(previous_artifact, dict) and isinstance(current_artifact, dict):
                previous_text = _artifact_to_semantic_text(previous_artifact)
                current_text = _artifact_to_semantic_text(current_artifact)
                if previous_text and current_text:
                    score = _cosine_similarity(build_local_embedding(previous_text), build_local_embedding(current_text))
                    bounded = max(0.0, min(1.0, float(score)))
                    scores.append(bounded)
                    reasoning_pair_count += 1
                    if bounded >= similarity_threshold:
                        pass_count += 1
                    scored = True

        if scored:
            continue

        previous_embedding = backend.get_vector_embedding(
            baseline_record.chunk_id,
            baseline_record.hash,
            provider="local",
            model="local-hash-v1",
        )
        current_embedding = backend.get_vector_embedding(
            current_record.chunk_id,
            current_record.hash,
            provider="local",
            model="local-hash-v1",
        )
        if previous_embedding is None or current_embedding is None:
            continue

        score = _cosine_similarity(previous_embedding.values, current_embedding.values)
        bounded = max(0.0, min(1.0, float(score)))
        scores.append(bounded)
        embedding_fallback_pair_count += 1
        if bounded >= similarity_threshold:
            pass_count += 1

    average_similarity = (sum(scores) / len(scores)) if scores else None
    min_similarity = min(scores) if scores else None
    max_similarity = max(scores) if scores else None
    pass_rate = (pass_count / len(scores)) if scores else None

    return {
        "method": "reasoning_cosine_v1_with_chunk_embedding_fallback_v1",
        "threshold": round(similarity_threshold, 6),
        "compared_modified_chunk_count": len(modified_keys),
        "scored_pair_count": len(scores),
        "reasoning_pair_count": reasoning_pair_count,
        "embedding_fallback_pair_count": embedding_fallback_pair_count,
        "pass_count": pass_count,
        "pass_rate": round(pass_rate, 6) if pass_rate is not None else None,
        "average_similarity": round(average_similarity, 6) if average_similarity is not None else None,
        "min_similarity": round(min_similarity, 6) if min_similarity is not None else None,
        "max_similarity": round(max_similarity, 6) if max_similarity is not None else None,
        "semantic_drift": round((1.0 - average_similarity), 6) if average_similarity is not None else None,
    }


def compute_delta_report(
    project_path: Path,
    against_snapshot_id: str,
    live_provider: str | None = None,
    playbook: str | None = None,
    provider_hydration: str = "probe",
    include_reasoning: bool = True,
    progress: Callable[[str], None] | None = None,
) -> DeltaRunReport:
    def emit(message: str) -> None:
        if not progress:
            return
        elapsed = perf_counter() - started
        progress(f"+{elapsed:0.1f}s {message}")

    started = perf_counter()
    emit("delta: start")
    run_id = _run_id()
    emit(f"delta: loading baseline snapshot {against_snapshot_id}")
    baseline = load_snapshot_manifest(against_snapshot_id)
    resolved_project_path = project_path.resolve()
    settings = load_settings(resolved_project_path)
    playbook_profile = load_playbook(playbook)
    provider_mode = (live_provider or settings.live_provider).strip().lower()

    emit(
        "delta: ingesting current project state "
        f"(playbook={playbook_profile.name}, max_file_bytes={playbook_profile.max_file_bytes})"
    )
    current_ingest = ingest_project(
        resolved_project_path,
        progress=lambda message: emit(message),
        include_patterns=playbook_profile.include_patterns,
        exclude_patterns=playbook_profile.exclude_patterns,
        max_file_bytes=playbook_profile.max_file_bytes,
        token_budget=playbook_profile.token_budget,
    )
    current_snapshot = build_snapshot_manifest(current_ingest, baseline_snapshot_id=against_snapshot_id)
    current_snapshot = _augment_snapshot_with_git_dirty(
        resolved_project_path,
        baseline,
        current_snapshot,
        progress=lambda message: emit(message),
    )

    emit("delta: classifying chunk status changes")
    status_counts, changed = _classify(baseline, current_snapshot)
    emit("delta: building dependency graph")
    graph = build_dependency_graph(
        resolved_project_path,
        current_snapshot,
        progress=lambda message: emit(message),
    )
    affected_chunks = graph.impacted_chunks(changed)

    # Proactively purge agent-committed reasoning cards whose scope module
    # overlaps with any changed file.  These cards have evidence_anchors: []
    # and are invisible to the artifact-index staleness check — without this
    # step they would survive delta runs indefinitely even after source edits.
    if changed:
        emit("delta: purging stale reasoning cards for modified paths")
        purge_result = purge_stale_cards_for_paths(resolved_project_path, changed)
        if purge_result["purged"] > 0:
            emit(f"delta: purged {purge_result['purged']} stale reasoning card(s)")

    backend = create_cache_backend()
    if playbook_profile.use_embedding_cache:
        emit("delta: resolving embedding cache metrics")
        cache_metrics = _cache_metrics_for_current_snapshot(
            current_snapshot,
            resolved_project_path,
            backend,
            progress=lambda message: emit(message),
        )
    else:
        emit("delta: embedding cache disabled by playbook")
        cache_metrics = {
            "hit_count": 0,
            "miss_count": 0,
            "hit_ratio": 0.0,
            "skipped": 1,
        }

    # ── Churn Guard ────────────────────────────────────────────────────────────
    # Evaluate whether we're in heavy-churn / cold-cache territory.  When both
    # conditions hold the engine enters passive dry-run mode: chunking and local
    # embedding storage continue so the cache keeps warming, but reasoning
    # hydration and the LLM provider call are skipped entirely.  The guard is
    # stateless — it re-evaluates every run and auto-resumes the moment either
    # condition improves.
    churn_rate = compute_churn_rate(
        unchanged=status_counts.UNCHANGED,
        modified=status_counts.MODIFIED,
        new=status_counts.NEW,
        deleted=status_counts.DELETED,
    )
    # When the token budget was exhausted and the baseline had more chunks than
    # the current ingest selected, NEW chunks are playbook-selection artifacts,
    # not real additions.  Use modified_only_rate so only genuine hash-mismatch
    # invalidations drive the guard decision.
    budget_limited_hint = bool(
        current_ingest.token_budget_exhausted and status_counts.DELETED > 0
    )
    active_churn_rate = (
        compute_modified_only_rate(
            unchanged=status_counts.UNCHANGED,
            modified=status_counts.MODIFIED,
            new=status_counts.NEW,
        )
        if budget_limited_hint
        else compute_active_churn_rate(
            unchanged=status_counts.UNCHANGED,
            modified=status_counts.MODIFIED,
            new=status_counts.NEW,
        )
    )
    churn_guard_policy = ChurnGuardPolicy(
        enabled=settings.churn_guard_enabled,
        min_hit_rate=settings.churn_guard_min_hit_rate,
        max_churn_rate=settings.churn_guard_max_churn_rate,
        min_total_chunks=settings.churn_guard_min_total_chunks,
        ema_alpha=settings.churn_guard_ema_alpha,
        cooldown_seconds=settings.churn_guard_cooldown_seconds,
        full_confidence_threshold=settings.churn_guard_full_confidence_threshold,
        passive_confidence_threshold=settings.churn_guard_passive_confidence_threshold,
        self_edit_ratio=settings.churn_guard_self_edit_ratio,
        self_edit_paths=settings.churn_guard_self_edit_paths,
    )
    total_chunks_universe = (
        status_counts.UNCHANGED + status_counts.MODIFIED
        + status_counts.NEW + status_counts.DELETED
    )
    state_path = resolved_project_path / "data" / "runs" / "churn-guard-state.json"
    guard_decision = evaluate_churn_guard(
        hit_rate=float(cache_metrics.get("hit_ratio", 0.0)),
        churn_rate=churn_rate,
        policy=churn_guard_policy,
        total_chunks=total_chunks_universe,
        changed_chunk_keys=changed,
        state_path=state_path,
        active_churn_rate=active_churn_rate,
        budget_limited=budget_limited_hint,
    )
    if guard_decision.paused:
        emit(f"delta: churn-guard {guard_decision.mode.value} — {guard_decision.reason}")
    # ── End Churn Guard ────────────────────────────────────────────────────────

    skip_reasoning = guard_decision.mode == ChurnGuardMode.PASSIVE
    skip_provider = guard_decision.mode in (ChurnGuardMode.PASSIVE, ChurnGuardMode.DRY_RUN)
    if include_reasoning and not skip_reasoning:
        emit("delta: hydrating reasoning artifacts")
        reasoning_result = hydrate_reasoning_artifacts(
            snapshot=current_snapshot,
            dependency_adjacency=graph.adjacency,
            backend=backend,
            progress=lambda message: emit(message),
        )
        invalidated_artifacts = sorted(
            {
                reasoning_result.artifact_ids_by_chunk_key[key]
                for key in affected_chunks
                if key in reasoning_result.artifact_ids_by_chunk_key
            }
        )
        regenerated_artifacts = sorted(
            set(invalidated_artifacts) & set(reasoning_result.generated_artifacts)
        )
    else:
        if skip_reasoning:
            emit(f"delta: reasoning hydration skipped (churn-guard {guard_decision.mode.value})")
        else:
            emit("delta: reasoning hydration skipped")
        reasoning_result = None
        invalidated_artifacts = []
        regenerated_artifacts = []
    emit("delta: computing projected and provider cost metrics")
    usage_events = build_usage_events(
        run_id=run_id,
        chunk_count=current_snapshot.chunk_count,
        cache_hit_count=int(cache_metrics["hit_count"]),
        cache_miss_count=int(cache_metrics["miss_count"]),
        regenerated_artifact_count=len(regenerated_artifacts),
    )
    cost_metrics = compute_cost_metrics(usage_events)
    generated_reasoning_count = len(reasoning_result.generated_artifacts) if reasoning_result else 0
    reused_reasoning_count = len(reasoning_result.reused_artifacts) if reasoning_result else 0

    hydration_mode = (provider_hydration or "probe").strip().lower()
    hydration_documents: list[str] | None = None

    if skip_provider:
        # DRY_RUN or PASSIVE: skip any network/LLM call
        emit(f"delta: provider call skipped (churn-guard {guard_decision.mode.value})")
        from .provider_usage import ProviderUsage  # local import avoids circular risk
        provider_usage = ProviderUsage(
            mode=guard_decision.mode.value,
            provider=None,
            model=None,
            captured=False,
            prompt_tokens=None,
            completion_tokens=None,
            total_tokens=None,
            latency_ms=None,
            error=None,
        )
    else:
        if provider_mode == "openai-compatible" and hydration_mode == "full-repo":
            emit("delta: collecting full-repo hydration corpus for provider usage")
            hydration_documents = collect_hydration_documents(
                resolved_project_path,
                include_patterns=playbook_profile.include_patterns,
                exclude_patterns=playbook_profile.exclude_patterns,
                max_file_bytes=playbook_profile.max_file_bytes,
            )
            emit(f"delta: hydration corpus collected document_count={len(hydration_documents)}")

        provider_usage = capture_provider_usage(
            run_id=run_id,
            live_provider=provider_mode,
            provider_base_url=settings.provider_base_url,
            provider_model=settings.provider_model,
            provider_api_key=settings.provider_api_key,
            provider_api_version=settings.provider_api_version,
            generated_artifact_count=generated_reasoning_count,
            reused_artifact_count=reused_reasoning_count,
            hydration_mode=hydration_mode,
            hydration_documents=hydration_documents,
            progress=lambda message: emit(message),
        )

    provider_cost_metrics = compute_provider_cost_metrics(
        provider_usage=provider_usage,
        baseline_equivalent_tokens=int(cost_metrics.get("baseline_equivalent_tokens", 0)),
    )
    if include_reasoning and not skip_reasoning:
        semantic_similarity_metrics = _compute_semantic_similarity_metrics(
            baseline=baseline,
            current_snapshot=current_snapshot,
            changed_keys=changed,
            backend=backend,
        )
    else:
        semantic_similarity_metrics = {
            "method": "local_embedding_cosine_v1",
            "threshold": 0.8,
            "compared_modified_chunk_count": 0,
            "scored_pair_count": 0,
            "pass_count": 0,
            "pass_rate": None,
            "average_similarity": None,
            "min_similarity": None,
            "max_similarity": None,
            "semantic_drift": None,
            "skipped": 1,
        }
    runtime_seconds = round(perf_counter() - started, 6)
    emit(f"delta: complete runtime_seconds={runtime_seconds}")

    usage_event_payload = [event.to_dict() for event in usage_events]

    current_chunk_count = current_snapshot.chunk_count
    baseline_chunk_count = baseline.chunk_count
    changed_chunk_count = len(changed)
    deleted_chunk_count = status_counts.DELETED
    deleted_chunk_ratio = round((deleted_chunk_count / changed_chunk_count), 5) if changed_chunk_count else 0.0
    budget_limited_deleted_hint = int(budget_limited_hint)

    return DeltaRunReport(
        run_id=run_id,
        baseline_snapshot_id=baseline.snapshot_id,
        current_snapshot_id=current_snapshot.snapshot_id,
        created_utc=_now_utc(),
        chunk_status_counts=status_counts,
        changed_chunks=changed,
        affected_chunks=affected_chunks,
        invalidated_artifacts=invalidated_artifacts,
        regenerated_artifacts=regenerated_artifacts,
        cache_metrics=cache_metrics,
        dependency_metrics={
            "edge_count": graph.edge_count,
            "changed_chunk_count": len(changed),
            "affected_chunk_count": len(affected_chunks),
        },
        reasoning_metrics={
            "generated_count": len(reasoning_result.generated_artifacts) if reasoning_result else 0,
            "reused_count": len(reasoning_result.reused_artifacts) if reasoning_result else 0,
            "total_count": len(reasoning_result.artifact_ids_by_chunk_key) if reasoning_result else 0,
            "skipped": 0 if (include_reasoning and not skip_reasoning) else 1,
        },
        usage_events=usage_event_payload,
        cost_metrics=cost_metrics,
        semantic_similarity_metrics=semantic_similarity_metrics,
        provider_usage=provider_usage.to_dict(),
        provider_cost_metrics=provider_cost_metrics,
        execution_profile={
            "playbook": playbook_profile.name,
            "max_file_bytes": playbook_profile.max_file_bytes,
            "token_budget": playbook_profile.token_budget,
            "estimated_ingest_tokens": current_ingest.estimated_tokens,
            "token_budget_exhausted": int(current_ingest.token_budget_exhausted),
            "embedding_cache_enabled": int(playbook_profile.use_embedding_cache),
            "provider_hydration_mode": hydration_mode,
            "baseline_chunk_count": baseline_chunk_count,
            "current_chunk_count": current_chunk_count,
            "changed_chunk_count": changed_chunk_count,
            "deleted_chunk_count": deleted_chunk_count,
            "deleted_chunk_ratio": deleted_chunk_ratio,
            "budget_limited_deleted_hint": budget_limited_deleted_hint,
        },
        churn_guard=guard_decision.to_dict(),
        runtime_seconds=runtime_seconds,
    )


def delta_to_json(project_path: Path, against_snapshot_id: str) -> str:
    report = compute_delta_report(project_path, against_snapshot_id)
    return json.dumps(report.to_dict(), indent=2)
