"""Session-start A/B measurement (engine-on scout pack vs engine-off full repo).

Path-parameterized, productized version of
``scripts/run_scout_pack_token_measure.py`` so an independent tester can
reproduce the session-start savings number on *any* repository rather than only
the engine's own repo.

Reproduction flow for an arbitrary repo:

    1. Build a baseline snapshot for the target repo (run from the repo root)::

           python -m semantic_cache_engine ingest --path . --write-snapshot --snapshot-id <id>

    2. Measure scout pack vs full-repo session-start cost::

           python -m semantic_cache_engine session-start-ab --path . --against <id>

Engine-on  = ``build_familiarization_pack(mode="scout")`` — the exact payload the
             MCP server returns to the agent at session start — serialized to
             JSON and sent to the configured provider with ``max_tokens=1`` to
             capture real ``prompt_tokens``.

Engine-off = the full-repo corpus, measured live via full-repo hydration. The
             baseline is measured per-repo (no hardcoded number) so the result
             is valid for whatever repository ``--path`` points at. Pass
             ``engine_off_tokens`` to reuse a previously measured number and skip
             the (potentially expensive) live full-repo run.

Snapshots resolve from ``data/baselines`` relative to the current working
directory, so run these commands from the target repo root.
"""
from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from urllib import error, request

from .settings import EngineSettings, load_settings


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _post_chat_request(*, url: str, headers: dict[str, str], settings: EngineSettings, content: str, token_limit_field: str, token_limit_value: int) -> dict[str, Any]:
    payload = json.dumps(
        {
            "model": settings.provider_model,
            "messages": [
                {"role": "system", "content": "Token telemetry measurement mode."},
                {"role": "user", "content": content},
            ],
            token_limit_field: token_limit_value,
            "temperature": 0,
        }
    ).encode("utf-8")
    req = request.Request(url, data=payload, headers=headers, method="POST")
    with request.urlopen(req, timeout=60) as resp:  # noqa: S310 — configured provider URL
        return json.loads(resp.read().decode("utf-8"))


# Escalating attempts so the measurement works across provider/model families:
#   legacy models accept max_tokens=1; newer models require max_completion_tokens;
#   reasoning models additionally need room to finish before usage is returned.
_TOKEN_LIMIT_ATTEMPTS: tuple[tuple[str, int], ...] = (
    ("max_tokens", 1),
    ("max_completion_tokens", 1),
    ("max_completion_tokens", 256),
)


def _send_single_request(
    *, settings: EngineSettings, content: str, prefer: tuple[str, int] | None = None
) -> dict[str, Any]:
    """Send one OpenAI-compatible request and return the usage/latency dict.

    Only ``prompt_tokens`` (input cost) is needed, so the output budget is kept
    minimal and escalated only when the provider rejects the parameter or needs
    room to finish. The successful ``(field, value)`` is returned as
    ``limit_used`` so callers issuing many requests can pin it and avoid
    re-escalating on every call.
    """
    from .provider_usage import _build_provider_request  # noqa: PLC0415 — lazy import

    url, headers = _build_provider_request(
        provider_base_url=settings.provider_base_url,
        provider_model=settings.provider_model,
        provider_api_key=settings.provider_api_key,
        provider_api_version=settings.provider_api_version,
    )

    attempts: list[tuple[str, int]] = list(_TOKEN_LIMIT_ATTEMPTS)
    if prefer and prefer in attempts:
        attempts.remove(prefer)
        attempts.insert(0, prefer)

    t0 = time.perf_counter()
    last_error: error.HTTPError | None = None
    used: tuple[str, int] = attempts[0]
    for index, (field, value) in enumerate(attempts):
        try:
            body = _post_chat_request(
                url=url, headers=headers, settings=settings, content=content,
                token_limit_field=field, token_limit_value=value,
            )
            used = (field, value)
            break
        except error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            last_error = error.HTTPError(exc.url, exc.code, detail, exc.headers, None)
            retryable = exc.code == 400 and ("max_completion_tokens" in detail or "max_tokens" in detail or "output limit" in detail)
            if retryable and index < len(attempts) - 1:
                continue
            raise last_error from exc
    latency_ms = round((time.perf_counter() - t0) * 1000, 2)

    usage = body.get("usage", {})
    return {
        "prompt_tokens": usage.get("prompt_tokens"),
        "latency_ms": latency_ms,
        "limit_used": used,
    }


# Fixed familiarization query used for the top-K retrieval arm (claim 1b).
# Matches the query used in the Jun 22 2026 evidence artifact
# (session-start-measure-20260622T050258Z.json) so results are comparable.
_TOPK_QUERY = (
    "Give me an overview of this codebase: its architecture, the main modules, "
    "and how the core pieces fit together so I can start working in it."
)
_TOPK_K_DEFAULT = 12
_TOPK_MAX_DOC_CHARS = 1600  # truncation applied before embedding, matching the evidence artifact


def _cosine_dot(a: list[float], b: list[float]) -> float:
    """Dot product of two already-normalised vectors == cosine similarity."""
    return sum(x * y for x, y in zip(a, b))


def _retrieve_topk_docs(documents: list[str], k: int) -> list[str]:
    """Return the *k* documents most similar to ``_TOPK_QUERY`` by local-embedding cosine."""
    from .local_embeddings import build_local_embedding  # noqa: PLC0415 — lazy import

    query_vec = build_local_embedding(_TOPK_QUERY)
    scored: list[tuple[float, str]] = []
    for doc in documents:
        truncated = doc[:_TOPK_MAX_DOC_CHARS]
        score = _cosine_dot(query_vec, build_local_embedding(truncated))
        scored.append((score, truncated))
    scored.sort(key=lambda item: item[0], reverse=True)
    return [doc for _, doc in scored[:k]]


def measure_session_start_ab(
    project_root: str | Path,
    *,
    snapshot_id: str | None = None,
    engine_off_tokens: int | None = None,
    topk_k: int = _TOPK_K_DEFAULT,
    progress: Callable[[str], None] | None = None,
) -> dict[str, Any]:
    """Measure scout-pack (engine-on) vs full-repo (engine-off) session-start tokens.

    Returns a result dict with ``status`` ``"ok"`` or ``"error"``. All failure
    paths return a structured ``error`` string instead of raising so the CLI can
    surface a clean message and exit code.
    """

    def emit(message: str) -> None:
        if progress:
            progress(message)

    root = Path(project_root).resolve()
    settings = load_settings(root)

    if not settings.provider_api_key:
        return {
            "status": "error",
            "error": "SEMANTIC_CACHE_PROVIDER_API_KEY is not set; a live provider key "
            "is required to measure real session-start token cost.",
        }

    # Resolve the baseline snapshot (cwd-relative data/baselines), matching the
    # familiarization-pack and delta pipelines.
    from .snapshot import latest_snapshot_id  # noqa: PLC0415 — lazy import

    try:
        resolved_snapshot = snapshot_id or latest_snapshot_id()
    except Exception as exc:  # noqa: BLE001 — surface as structured error
        return {
            "status": "error",
            "error": f"could not resolve a baseline snapshot ({type(exc).__name__}: {exc}). "
            "Build one first with: ingest --path . --write-snapshot --snapshot-id <id>",
        }

    # --- Engine on: scout pack prompt_tokens ---
    from .familiarization_packs import build_familiarization_pack  # noqa: PLC0415 — lazy import

    emit("session-start-ab: building scout pack (engine on)")
    try:
        pack = build_familiarization_pack(
            project_path=root,
            mode="scout",
            against_snapshot_id=resolved_snapshot,
        )
    except Exception as exc:  # noqa: BLE001 — surface as structured error
        return {
            "status": "error",
            "error": f"scout pack build failed ({type(exc).__name__}: {exc}). "
            f"Confirm snapshot '{resolved_snapshot}' exists in data/baselines.",
        }
    scout_json = json.dumps(pack, indent=2)

    emit("session-start-ab: sending scout pack to provider for token count")
    try:
        on = _send_single_request(settings=settings, content=scout_json)
    except error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:300]
        return {"status": "error", "error": f"engine-on request HTTP {exc.code}: {detail}"}
    except Exception as exc:  # noqa: BLE001 — surface as structured error
        return {"status": "error", "error": f"engine-on request failed ({type(exc).__name__}: {exc})"}

    engine_on_tokens = on["prompt_tokens"]
    if not engine_on_tokens:
        return {"status": "error", "error": "engine-on request did not return prompt_tokens."}
    prefer_limit = on.get("limit_used")

    # --- Collect hydration documents (shared by engine-off and top-K arms) ---
    # Always collected here so both downstream arms can use the same set without
    # a second filesystem scan. This also ensures top-K runs even when
    # engine_off_tokens override is supplied.
    from .ingest import collect_hydration_documents  # noqa: PLC0415 — lazy import
    from .playbooks import load_playbook  # noqa: PLC0415 — lazy import

    emit("session-start-ab: collecting full-repo documents")
    playbook = load_playbook("session-readiness")
    documents = collect_hydration_documents(
        root,
        include_patterns=playbook.include_patterns,
        exclude_patterns=playbook.exclude_patterns,
        max_file_bytes=playbook.max_file_bytes,
    )
    if not documents:
        return {"status": "error", "error": "no hydration documents found (check include/exclude patterns)."}

    # --- Engine off: naive full-repo baseline (claim 1) ---
    # Batched and summed directly — bypasses compute_delta_report's churn-guard
    # which goes passive when the snapshot matches the current repo state.
    engine_off_documents: int | None = None
    engine_off_batches: int | None = None
    if engine_off_tokens is not None:
        engine_off = int(engine_off_tokens)
        baseline_source = "override"
    else:
        from .provider_usage import _iter_hydration_batches  # noqa: PLC0415 — lazy import

        batches = list(_iter_hydration_batches(documents))
        emit(f"session-start-ab: sending {len(batches)} full-repo batch(es) to provider (live API calls)")
        engine_off = 0
        for idx, batch in enumerate(batches, start=1):
            try:
                res = _send_single_request(settings=settings, content=batch, prefer=prefer_limit)
            except error.HTTPError as exc:
                detail = exc.read().decode("utf-8", errors="replace")[:300]
                return {"status": "error", "error": f"engine-off batch {idx}/{len(batches)} HTTP {exc.code}: {detail}"}
            except Exception as exc:  # noqa: BLE001 — surface as structured error
                return {"status": "error", "error": f"engine-off batch {idx} failed ({type(exc).__name__}: {exc})"}
            batch_tokens = res["prompt_tokens"]
            if not batch_tokens:
                return {"status": "error", "error": f"engine-off batch {idx} returned no prompt_tokens."}
            engine_off += batch_tokens
            if progress and idx % 10 == 0:
                emit(f"session-start-ab: {idx}/{len(batches)} batches, {engine_off:,} tokens so far")
        baseline_source = "live-fullrepo-hydration"
        engine_off_documents = len(documents)
        engine_off_batches = len(batches)

    # --- Top-K retrieval baseline (claim 1b) ---
    # Reproduces the methodology from session-start-measure-20260622T050258Z.json:
    # local-embedding cosine similarity over hydration documents, fixed
    # familiarization query, top-K truncated to _TOPK_MAX_DOC_CHARS each.
    # One small live provider call captures real prompt_tokens for the retrieved set.
    topk_tokens: int | None = None
    topk_error: str | None = None
    topk_chars: int | None = None
    topk_latency_ms: float | None = None
    emit(f"session-start-ab: computing top-{topk_k} retrieval baseline (local embeddings)")
    topk_doc_list = _retrieve_topk_docs(documents, k=topk_k)
    topk_content = "\n\n---\n\n".join(topk_doc_list)
    topk_chars = len(topk_content)
    emit(f"session-start-ab: sending top-{topk_k} retrieved documents to provider for token count")
    try:
        topk_res = _send_single_request(settings=settings, content=topk_content, prefer=prefer_limit)
        topk_tokens = topk_res["prompt_tokens"]
        topk_latency_ms = topk_res["latency_ms"]
        if not topk_tokens:
            topk_error = "top-K request did not return prompt_tokens"
    except error.HTTPError as exc:
        topk_error = f"HTTP {exc.code}: {exc.read().decode('utf-8', errors='replace')[:200]}"
    except Exception as exc:  # noqa: BLE001 — surface as structured error
        topk_error = f"{type(exc).__name__}: {exc}"

    # --- Compute savings ratios ---
    saved_vs_fullrepo = engine_off - engine_on_tokens
    ratio_vs_fullrepo = round((1 - engine_on_tokens / engine_off) * 100, 2) if engine_off > 0 else 0.0

    if topk_tokens:
        saved_vs_topk = topk_tokens - engine_on_tokens
        ratio_vs_topk = round((1 - engine_on_tokens / topk_tokens) * 100, 2)
    else:
        saved_vs_topk = None
        ratio_vs_topk = None

    return {
        "status": "ok",
        "generated_utc": _utc_now(),
        "project_root": str(root),
        "snapshot_id": resolved_snapshot,
        "model": settings.provider_model,
        "arms": {
            "scout_pack_engine_on": {
                "prompt_tokens": engine_on_tokens,
                "chars": len(scout_json),
                "latency_ms": on["latency_ms"],
            },
            "fullrepo_naive_engine_off": {
                "prompt_tokens": engine_off,
                "documents": engine_off_documents,
                "batches": engine_off_batches,
                "baseline_source": baseline_source,
            },
            "topk_retrieval_engine_off": {
                "prompt_tokens": topk_tokens,
                "k": topk_k,
                "max_doc_chars": _TOPK_MAX_DOC_CHARS,
                "retriever": "local_embedding cosine top-K over hydration documents",
                "query": _TOPK_QUERY,
                "context_chars": topk_chars,
                "latency_ms": topk_latency_ms,
                "error": topk_error,
            },
        },
        "claim_1_vs_fullrepo": {
            "scout_tokens": engine_on_tokens,
            "baseline_tokens": engine_off,
            "tokens_saved": saved_vs_fullrepo,
            "savings_ratio_pct": ratio_vs_fullrepo,
            "note": "strawman baseline: naive full-repo dump. Not a realistic agent workflow; pair with claim_1b for the defensible number.",
        },
        "claim_1b_vs_topk": {
            "scout_tokens": engine_on_tokens,
            "baseline_tokens": topk_tokens,
            "tokens_saved": saved_vs_topk,
            "savings_ratio_pct": ratio_vs_topk,
            "note": "realistic baseline: one top-K familiarization query retrieval. Conservative — real familiarization often needs several retrieval rounds, which would raise the baseline and the savings.",
            "error": topk_error,
        },
        "caveats": [
            "engine_off (full-repo) dumps the entire corpus to the provider — run on PUBLIC repositories only.",
            "claim_1 (full-repo) is a strawman; claim_1b (top-K) is the defensible session-start savings number.",
            "top-K retriever uses local hash-based embeddings (build_local_embedding), not a neural model; results are consistent but less semantically precise than a production embedding API.",
            "single-query top-K is a conservative realistic baseline; multi-round retrieval would raise the baseline cost and the measured savings ratio.",
        ],
    }
