from __future__ import annotations

from collections.abc import Callable
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import uuid
from typing import Any

from .cache import build_cache_entry, create_operation_cache_backend
from .direct_chat_contract import (
    DIRECT_CHAT_CONTRACT_VERSION,
    DIRECT_CHAT_HANDOFF_SCHEMA,
    build_handoff_packet,
)
from .resolver import resolve_developer_question
from .reasoning_memory import commit_reasoning_card
from .sidecar_adapter import MockSidecarAdapter
from .sidecar_contract import (
    build_resolve_request,
    validate_resolve_response,
)
from .settings import load_settings

_BASE = Path(os.environ.get("SEMANTIC_CACHE_BASE_DIR", ".reason"))
CHAT_TRACE_PATH = _BASE / "runs/chat/chat-trace.jsonl"
CHAT_RESPONSE_CHUNK_ENTRY_TYPE = "agent-response-chunk"
CHAT_RESPONSE_INDEX_ENTRY_TYPE = "agent-response-index"
CHAT_RESPONSE_VERSION = "phase-14"


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _normalize_text(value: str) -> str:
    return re.sub(r"\s+", " ", value.strip().lower())


def _tokenize(value: str) -> set[str]:
    return {token for token in re.findall(r"[a-z0-9_\-]+", _normalize_text(value)) if token}


def _bounded_float(value: Any, default: float = 0.0) -> float:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        parsed = default
    return max(0.0, min(parsed, 1.0))


def _append_chat_trace(project_root: Path, payload: dict[str, Any]) -> str:
    path = project_root.resolve() / CHAT_TRACE_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    record = dict(payload)
    record.setdefault("generated_utc", _utc_now())
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, separators=(",", ":")) + "\n")
    return str(path)


def _derive_resolver_confidence(resolver_result: dict[str, Any]) -> float:
    route = str(resolver_result.get("route", ""))
    classification = resolver_result.get("classification", {})
    route_payload = resolver_result.get("route_payload", {})
    recall = resolver_result.get("recall", {})

    if route == "recall":
        top = recall.get("candidates", [{}])[0] if isinstance(recall.get("candidates"), list) else {}
        return _bounded_float(top.get("score", classification.get("confidence", 0.0)))

    if route in {"scout", "drill"}:
        pack_confidence = route_payload.get("pack_confidence", {}) if isinstance(route_payload, dict) else {}
        return _bounded_float(pack_confidence.get("overall", classification.get("confidence", 0.0)))

    if route == "fresh_delta":
        return _bounded_float(classification.get("confidence", 0.0) * 0.75)

    if route == "generic_chat":
        return _bounded_float(classification.get("confidence", 0.0) * 0.5)

    if route == "agent_handoff":
        return 0.0

    return _bounded_float(classification.get("confidence", 0.0))


def _build_quick_answer(resolver_result: dict[str, Any]) -> str:
    route = str(resolver_result.get("route", ""))
    route_payload = resolver_result.get("route_payload", {}) if isinstance(resolver_result.get("route_payload"), dict) else {}
    recall = resolver_result.get("recall", {}) if isinstance(resolver_result.get("recall"), dict) else {}

    if route == "recall":
        candidates = recall.get("candidates", []) if isinstance(recall.get("candidates"), list) else []
        if candidates:
            candidate = candidates[0]
            summary = str(candidate.get("outcome_summary", "")).strip()
            if summary:
                return summary
            chosen_plan = candidate.get("chosen_plan")
            if isinstance(chosen_plan, list) and chosen_plan:
                return " ".join(str(item).strip() for item in chosen_plan if str(item).strip())
        return "Resolver reused prior reasoning and produced a high-confidence direct answer."

    if route == "scout":
        read_order = route_payload.get("suggested_read_order", [])
        if isinstance(read_order, list) and read_order:
            preview = ", ".join(str(item) for item in read_order[:5])
            return f"Resolver produced a high-confidence scout plan. Suggested read order: {preview}."
        return "Resolver produced a high-confidence scout plan."

    if route == "drill":
        evidence_cards = route_payload.get("evidence_cards", [])
        if isinstance(evidence_cards, list) and evidence_cards:
            preview = ", ".join(str(item) for item in evidence_cards[:5])
            return f"Resolver completed a high-confidence drill with targeted evidence: {preview}."
        return "Resolver completed a high-confidence drill with targeted evidence."

    if route == "fresh_delta":
        summary = route_payload.get("summary", {}) if isinstance(route_payload, dict) else {}
        saved_tokens = summary.get("saved_tokens")
        runtime_seconds = route_payload.get("runtime_seconds")
        return (
            "Resolver completed a fresh delta run"
            f" (saved_tokens={saved_tokens}, runtime_seconds={runtime_seconds})."
        )

    return "Resolver returned a direct answer."


def _chunk_answer(answer: str, max_chars: int = 320) -> list[str]:
    cleaned = answer.strip()
    if not cleaned:
        return [""]

    chunks: list[str] = []
    cursor = 0
    while cursor < len(cleaned):
        segment = cleaned[cursor : cursor + max_chars]
        if len(segment) == max_chars:
            split_idx = segment.rfind(" ")
            if split_idx > 80:
                segment = segment[:split_idx]
        chunk = segment.strip()
        if chunk:
            chunks.append(chunk)
        cursor += max(len(segment), 1)
    return chunks or [cleaned]


def _persist_response_chunks(
    project_root: Path,
    *,
    trace_id: str,
    question: str,
    answer: str,
    answer_source: str,
) -> dict[str, Any]:
    settings = load_settings(project_root.resolve())
    backend = create_operation_cache_backend(settings)
    backend.ensure_schema()

    chunks = _chunk_answer(answer)
    chunk_ids: list[str] = []

    for idx, chunk in enumerate(chunks):
        chunk_id = f"chat-response::{trace_id}::{idx:04d}"
        chunk_hash = hashlib.sha256(chunk.encode("utf-8")).hexdigest()
        metadata = {
            "trace_id": trace_id,
            "question": question,
            "answer_source": answer_source,
            "chunk_index": idx,
            "chunk_count": len(chunks),
            "text": chunk,
            "tokens": sorted(_tokenize(chunk))[:64],
        }
        backend.upsert_cache_entry(
            build_cache_entry(
                chunk_id=chunk_id,
                chunk_hash=chunk_hash,
                entry_type=CHAT_RESPONSE_CHUNK_ENTRY_TYPE,
                version=CHAT_RESPONSE_VERSION,
                metadata=metadata,
            )
        )
        chunk_ids.append(chunk_id)

    index_chunk_id = f"chat-response-index::{trace_id}"
    index_hash = hashlib.sha256(("|".join(chunk_ids) + "::" + _normalize_text(question)).encode("utf-8")).hexdigest()
    index_metadata = {
        "trace_id": trace_id,
        "question": question,
        "question_norm": _normalize_text(question),
        "question_tokens": sorted(_tokenize(question))[:64],
        "answer_source": answer_source,
        "chunk_ids": chunk_ids,
        "chunk_count": len(chunk_ids),
    }
    backend.upsert_cache_entry(
        build_cache_entry(
            chunk_id=index_chunk_id,
            chunk_hash=index_hash,
            entry_type=CHAT_RESPONSE_INDEX_ENTRY_TYPE,
            version=CHAT_RESPONSE_VERSION,
            metadata=index_metadata,
        )
    )

    return {
        "entry_type": CHAT_RESPONSE_CHUNK_ENTRY_TYPE,
        "index_entry_type": CHAT_RESPONSE_INDEX_ENTRY_TYPE,
        "chunk_count": len(chunk_ids),
        "chunk_ids": chunk_ids,
        "index_chunk_id": index_chunk_id,
    }


def query_indexed_chat_responses(project_root: Path, query: str, limit: int = 5) -> dict[str, Any]:
    settings = load_settings(project_root.resolve())
    backend = create_operation_cache_backend(settings)
    backend.ensure_schema()

    indexes = backend.list_cache_entries(entry_type=CHAT_RESPONSE_INDEX_ENTRY_TYPE)
    query_tokens = _tokenize(query)

    scored: list[tuple[float, dict[str, Any]]] = []
    for entry in indexes:
        question_tokens = set(entry.metadata.get("question_tokens", []))
        if not question_tokens:
            continue
        overlap = len(query_tokens & question_tokens)
        score = overlap / max(len(query_tokens | question_tokens), 1)
        if score <= 0:
            continue
        scored.append((round(score, 6), entry.metadata))

    scored.sort(key=lambda item: item[0], reverse=True)
    top = scored[: max(1, int(limit))]

    results: list[dict[str, Any]] = []
    for score, metadata in top:
        chunk_texts: list[str] = []
        for chunk_id in metadata.get("chunk_ids", []):
            for candidate in backend.get_entries_by_chunk_id(str(chunk_id)):
                if candidate.type != CHAT_RESPONSE_CHUNK_ENTRY_TYPE:
                    continue
                if str(candidate.metadata.get("trace_id")) != str(metadata.get("trace_id")):
                    continue
                chunk_texts.append(str(candidate.metadata.get("text", "")))
                break

        results.append(
            {
                "score": score,
                "trace_id": metadata.get("trace_id"),
                "question": metadata.get("question"),
                "answer_source": metadata.get("answer_source"),
                "chunk_count": metadata.get("chunk_count"),
                "answer": " ".join(text for text in chunk_texts if text).strip(),
            }
        )

    return {
        "query": query,
        "candidate_count": len(scored),
        "results": results,
    }


def _build_agent_packet(
    *,
    trace_id: str,
    question: str,
    resolver_result: dict[str, Any],
    resolver_confidence: float,
    confidence_threshold: float,
) -> dict[str, Any]:
    return build_handoff_packet(
        trace_id=trace_id,
        question=question,
        resolver_confidence=resolver_confidence,
        confidence_threshold=confidence_threshold,
        resolver_result=resolver_result,
    )


def _default_agent_responder(packet: dict[str, Any]) -> dict[str, Any]:
    handoff_context = packet.get("handoff_context", {}) if isinstance(packet.get("handoff_context"), dict) else {}
    reason = handoff_context.get("reason") or "low_confidence"
    route = packet.get("route")
    question = packet.get("question")

    answer = (
        "Resolver confidence was below threshold, so this response was escalated with context. "
        f"(route={route}, reason={reason}). "
        f"Question: {question}"
    )
    return {
        "answer": answer,
        "source": "default-agent",
    }


def _normalize_agent_answer(agent_response: Any) -> str:
    if isinstance(agent_response, dict):
        text = str(agent_response.get("answer", "")).strip()
        if text:
            return text
    text = str(agent_response or "").strip()
    return text or "No response generated."


def _run_return_hooks(
    hooks: list[Callable[[str, dict[str, Any]], None]] | None,
    event: str,
    payload: dict[str, Any],
) -> list[str]:
    if not hooks:
        return []

    errors: list[str] = []
    for hook in hooks:
        try:
            hook(event, payload)
        except Exception as exc:
            errors.append(str(exc))
    return errors


def _is_sidecar_mock_enabled() -> bool:
    raw = (os.getenv("SEMANTIC_SIDECAR_MOCK_ENABLED") or "").strip().lower()
    return raw in {"1", "true", "yes", "on"}


def _is_read_only_mode() -> bool:
    """When set, the turn answers normally but persists nothing to cache.

    Used by the alpha Control (User 3) so a cold measurement run provably
    commits zero reasoning cards and zero response chunks. The resolver, the
    answer, and all token accounting still run unchanged.
    """
    raw = (os.getenv("SEMANTIC_CACHE_READ_ONLY") or "").strip().lower()
    return raw in {"1", "true", "yes", "on"}



def _resolve_with_sidecar_mock(
    *,
    question: str,
    project_root: Path,
    trace_id: str,
    selection: str | None,
    file_path: str | None,
    symbol: str | None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    adapter = MockSidecarAdapter()
    handshake = adapter.handshake(
        client_name="semantic-cache-engine",
        client_version=CHAT_RESPONSE_VERSION,
        requested_capabilities=["resolve_question"],
    )

    request_packet = build_resolve_request(
        trace_id=trace_id,
        question=question,
        workspace_root=str(project_root),
        editor_context={
            "selection": selection,
            "file_path": file_path,
            "symbol": symbol,
        },
    )
    response_packet = adapter.resolve(
        trace_id=trace_id,
        question=question,
        workspace_root=str(project_root),
        editor_context=request_packet.get("editor_context", {}),
    )
    valid, errors = validate_resolve_response(response_packet)
    if not valid:
        raise ValueError(f"sidecar mock response invalid: {errors}")

    route = str(response_packet.get("route", "generic_chat"))
    confidence = _bounded_float(response_packet.get("confidence", 0.0))
    route_payload = dict(response_packet.get("route_payload", {}))

    if route in {"scout", "drill"}:
        route_payload.setdefault("pack_confidence", {"overall": confidence})

    recall_payload = {"candidate_count": 0, "match_mode": "none", "candidates": []}
    if route == "recall":
        recall_payload = {
            "candidate_count": 1,
            "match_mode": "mock",
            "candidates": [
                {
                    "score": confidence,
                    "match_type": "mock",
                    "outcome_summary": "Sidecar mock returned a cached-style direct answer.",
                }
            ],
        }

    resolver_result = {
        "route": route,
        "classification": {
            "category": "repo_question",
            "confidence": confidence,
        },
        "scope_fingerprint": f"sidecar-mock::{trace_id}",
        "decision_trace": list(response_packet.get("decision_trace", [])),
        "route_payload": route_payload,
        "handoff_context": {},
        "recall": recall_payload,
    }
    sidecar_meta = {
        "enabled": True,
        "mode": "mock",
        "handshake": handshake,
    }
    return resolver_result, sidecar_meta


def run_direct_chat_turn(
    project_root: Path,
    *,
    question: str,
    file_path: str | None = None,
    symbol: str | None = None,
    selection: str | None = None,
    against_snapshot_id: str | None = None,
    confidence_threshold: float = 0.8,
    sidecar_mock_mode: bool | None = None,
    agent_responder: Callable[[dict[str, Any]], Any] | None = None,
    return_hooks: list[Callable[[str, dict[str, Any]], None]] | None = None,
) -> dict[str, Any]:
    resolved_root = project_root.resolve()
    bounded_threshold = _bounded_float(confidence_threshold, default=0.8)
    trace_id = f"chat-{uuid.uuid4().hex[:12]}"

    sidecar_meta = {
        "enabled": False,
        "mode": "none",
    }
    use_sidecar_mock = sidecar_mock_mode if sidecar_mock_mode is not None else _is_sidecar_mock_enabled()
    if use_sidecar_mock:
        resolver_result, sidecar_meta = _resolve_with_sidecar_mock(
            question=question,
            project_root=resolved_root,
            trace_id=trace_id,
            selection=selection,
            file_path=file_path,
            symbol=symbol,
        )
    else:
        resolver_result = resolve_developer_question(
            project_root=resolved_root,
            question=question,
            file_path=file_path,
            symbol=symbol,
            selection=selection,
            against_snapshot_id=against_snapshot_id,
            trace_id=trace_id,
        )
    resolver_confidence = _derive_resolver_confidence(resolver_result)

    hook_errors: list[str] = []
    hook_errors.extend(
        _run_return_hooks(
            return_hooks,
            "resolver_complete",
            {
                "trace_id": trace_id,
                "question": question,
                "route": resolver_result.get("route"),
                "resolver_confidence": resolver_confidence,
            },
        )
    )

    resolver_route = str(resolver_result.get("route", ""))
    quick_supported = resolver_route in {"recall", "scout", "drill", "fresh_delta"}
    use_quick_return = quick_supported and resolver_confidence >= bounded_threshold

    handoff_packet: dict[str, Any] | None = None
    if use_quick_return:
        answer_source = "resolver"
        answer = _build_quick_answer(resolver_result)
        route = "quick_return"
    else:
        answer_source = "agent"
        route = "agent_handoff"
        handoff_packet = _build_agent_packet(
            trace_id=trace_id,
            question=question,
            resolver_result=resolver_result,
            resolver_confidence=resolver_confidence,
            confidence_threshold=bounded_threshold,
        )
        responder = agent_responder or _default_agent_responder
        answer = _normalize_agent_answer(responder(handoff_packet))

    read_only = _is_read_only_mode()
    if read_only:
        chunk_commit = {"status": "skipped", "reason": "read_only_mode", "chunk_count": 0}
        reasoning_commit = {"status": "skipped", "reason": "read_only_mode"}
    else:
        chunk_commit = _persist_response_chunks(
            resolved_root,
            trace_id=trace_id,
            question=question,
            answer=answer,
            answer_source=answer_source,
        )

        reasoning_commit = commit_reasoning_card(
            project_root=resolved_root,
            source="direct-chat",
            card_payload={
                "schema_version": "reason-v2",
                "task_intent": question,
                "scope_fingerprint": resolver_result.get("scope_fingerprint") or f"scope-{trace_id}",
                "dependency_fingerprint": (
                    f"direct-chat:{resolver_result.get('scope_fingerprint') or f'scope-{trace_id}'}:"
                    f"resolver_route={resolver_route}:answer_source={answer_source}:policy=standard"
                ),
                "chosen_plan": [
                    f"resolver_route={resolver_route}",
                    f"answer_source={answer_source}",
                    f"confidence_threshold={bounded_threshold}",
                ],
                "assumptions": ["No MCP transport layer was used for this turn."],
                "constraints": {
                    "route": route,
                    "resolver_route": resolver_route,
                    "policy_mode": "standard",
                    "local_only": True,
                },
                "validation_evidence": [
                    f"trace_id={trace_id}",
                    f"resolver_confidence={round(resolver_confidence, 6)}",
                    f"chunk_count={chunk_commit.get('chunk_count', 0)}",
                ],
                "outcome_summary": answer[:500],
                "confidence": resolver_confidence if answer_source == "resolver" else bounded_threshold,
                "evidence_anchors": [
                    {
                        "anchor_type": "direct_chat_turn",
                        "trace_id": trace_id,
                        "route": route,
                        "resolver_route": resolver_route,
                    }
                ],
                "validation": {
                    "status": "captured",
                    "method": "direct-chat-capture",
                    "validated_at": _utc_now(),
                },
                "reuse_guardrails": [
                    "Reuse only when task intent and scope are both aligned.",
                    "Do not sync local-only reasoning-card entries.",
                ],
                "source_run_id": trace_id,
            },
        )

    turn_payload = {
        "generated_utc": _utc_now(),
        "contract": {
            "version": DIRECT_CHAT_CONTRACT_VERSION,
            "handoff_schema": DIRECT_CHAT_HANDOFF_SCHEMA,
        },
        "trace_id": trace_id,
        "question": question,
        "route": route,
        "resolver_route": resolver_route,
        "resolver_confidence": round(resolver_confidence, 6),
        "confidence_threshold": round(bounded_threshold, 6),
        "answer_source": answer_source,
        "answer": answer,
        "sidecar": sidecar_meta,
        "read_only": read_only,
        "resolver": resolver_result,
        "handoff_packet": handoff_packet,
        "chunk_commit": chunk_commit,
        "reasoning_commit": {
            "status": reasoning_commit.get("status"),
            "entry_type": reasoning_commit.get("entry_type"),
            "chunk_id": reasoning_commit.get("chunk_id"),
            "reason": reasoning_commit.get("reason"),
        },
    }

    hook_errors.extend(
        _run_return_hooks(
            return_hooks,
            "turn_complete",
            {
                "trace_id": trace_id,
                "route": route,
                "resolver_confidence": resolver_confidence,
                "answer_source": answer_source,
                "chunk_count": chunk_commit.get("chunk_count", 0),
            },
        )
    )
    if hook_errors:
        turn_payload["hook_errors"] = hook_errors

    turn_payload["trace_log_path"] = _append_chat_trace(
        resolved_root,
        {
            "trace_id": trace_id,
            "question": question,
            "route": route,
            "resolver_route": resolver_route,
            "resolver_confidence": round(resolver_confidence, 6),
            "confidence_threshold": round(bounded_threshold, 6),
            "answer_source": answer_source,
            "chunk_count": chunk_commit.get("chunk_count", 0),
            "reasoning_entry_type": reasoning_commit.get("entry_type"),
            "hook_error_count": len(hook_errors),
        },
    )

    return turn_payload
