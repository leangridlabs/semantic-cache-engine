from __future__ import annotations

from collections.abc import Callable
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import re
from typing import Any

from .delta import compute_delta_report
from .familiarization_packs import build_familiarization_pack
from .reasoning_memory import commit_reasoning_card, derive_canonical_intent, recall_reasoning_cards
from .scope_identity import canonical_scope
from .run_report import save_delta_run_report, summarize_run_report
from .settings import load_settings
from .snapshot import latest_snapshot_id

_BASE = Path(os.environ.get("SEMANTIC_CACHE_BASE_DIR", ".reason"))
SHADOW_REPORT_PATH = _BASE / "runs/shadow/session-shadow-latest.json"
RESOLVER_LOG_PATH = _BASE / "runs/resolver/resolver-decisions.jsonl"
SCOUT_PACK_PATH = _BASE / "runs/shadow/scout-pack-latest.json"

# Workspace-derived signal terms loaded lazily from the scout pack.
# Maps project_root (str) -> frozenset of lowercase tokens.
_WORKSPACE_SYMBOL_CACHE: dict[str, frozenset[str]] = {}

# Suggested read order loaded lazily from the scout pack for cold-cache handoffs.
# Maps project_root (str) -> list of read-order entries.
_SCOUT_READ_ORDER_CACHE: dict[str, list] = {}

# Full project_map loaded lazily from the scout pack for question-aware filtering.
# Maps project_root (str) -> list of all project paths.
_SCOUT_PROJECT_MAP_CACHE: dict[str, list] = {}

# ---------------------------------------------------------------------------
# Fast-lane: in-process LRU cache for strong recall hits.
# Keyed by (project_root_str, normalized_question).  Value is the compact
# fast-lane response dict.  Capped at _FAST_LANE_LRU_MAX entries; oldest
# evicted first (insertion-ordered dict trick).
# Sources that wrote placeholder/skeleton cards are never cached here.
# ---------------------------------------------------------------------------
_FAST_LANE_LRU: dict[tuple[str, str], dict[str, Any]] = {}
_FAST_LANE_LRU_MAX = 256
_FAST_LANE_SCORE_THRESHOLD = 0.80
_FAST_LANE_REJECTED_SOURCES = frozenset({
    "resolver-agent-handoff",
    "resolver",
    "mcp-resolver",
    "bundle-import",
    "",
})

# Common question words that carry no path-relevance signal.
_HANDOFF_STOPWORDS = frozenset({
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "shall", "can", "need", "dare", "ought",
    "to", "of", "in", "for", "on", "with", "at", "by", "from", "up",
    "about", "into", "through", "during", "and", "but", "or", "nor",
    "so", "yet", "both", "either", "not", "no", "just", "than", "too",
    "very", "that", "this", "these", "those", "it", "its", "which",
    "who", "whom", "what", "where", "when", "why", "how",
    "i", "me", "my", "we", "our", "you", "your", "he", "she", "they",
    "tell", "show", "list", "give", "find", "get", "describe",
    "available", "current", "existing", "any", "all", "some", "there",
})

# Path prefixes that are noise for question-scoped guidance (temp, vendored, hidden).
_HANDOFF_NOISE_PREFIXES = (".local-hold", ".tmp-", ".venv", "node_modules", "__pycache__")


def _extract_scope_tokens(scope: str) -> list[str]:
    """Extract lowercase identifier tokens from a scope_fingerprint string.

    Handles formats like:
        "chunking::chunk_source"  -> ["chunking", "chunk", "source", "chunksource"]
        "reasoning_memory"        -> ["reasoning", "memory", "reasoningmemory"]
        "resolver::derive_scope_fingerprint" -> ["resolver", "derive", "scope", ...]
    """
    tokens: list[str] = []
    # Split on :: to separate module from symbol
    parts = [p.strip() for p in scope.split("::") if p.strip()]
    for part in parts:
        # Split on _ and - to get individual words
        words = [w for w in re.split(r"[_\-]", part) if len(w) >= 3]
        tokens.extend(w.lower() for w in words)
        # Also add the whole part lowercased (e.g. "chunksource")
        joined = "".join(words).lower()
        if len(joined) >= 3 and joined not in tokens:
            tokens.append(joined)
        # And the raw part itself (e.g. "chunk_source")
        raw = part.lower()
        if raw not in tokens and len(raw) >= 3:
            tokens.append(raw)
    return tokens


def _load_workspace_symbols(project_root: Path) -> frozenset[str]:
    """Extract identifier tokens from the scout pack dependency_context entries
    and from committed reasoning card scope_fingerprints.

    Scout pack entries look like:
        depends_on::src/foo/bar.py::def-my-function-name:3
    Reasoning card scope_fingerprints look like:
        chunking::chunk_source
        resolver::derive_scope_fingerprint

    Tokens from both sources are merged so that any symbol with a committed
    reasoning card is automatically recognised as a repo signal term —
    no manual REPO_SIGNAL_TERMS maintenance required.

    Cached per project_root for the lifetime of the process.
    """
    key = str(project_root.resolve())
    if key in _WORKSPACE_SYMBOL_CACHE:
        cached = _WORKSPACE_SYMBOL_CACHE[key]
        # Don't serve a cached empty set — scout pack may not have existed yet
        # when the cache was populated. Re-run if the cache entry is empty.
        if cached:
            return cached

    scout_path = project_root.resolve() / SCOUT_PACK_PATH
    tokens: set[str] = set()

    # --- Source 1: scout pack dependency_context + project_map ---
    try:
        if scout_path.exists():
            data = json.loads(scout_path.read_text(encoding="utf-8", errors="ignore"))
            dep_ctx = data.get("dependency_context") or []
            for entry in dep_ctx:
                # entry format: "depends_on::path/to/file.py::def-symbol-name:N"
                parts = str(entry).split("::")
                if len(parts) >= 3:
                    symbol_slug = parts[2].split(":")[0]  # strip ":N" count suffix
                    # strip leading "def-", "class-" prefix
                    for prefix in ("def-", "class-"):
                        if symbol_slug.startswith(prefix):
                            symbol_slug = symbol_slug[len(prefix):]
                            break
                    # split on hyphens and add each word + the whole slug
                    words = [w for w in symbol_slug.split("-") if len(w) >= 3]
                    tokens.update(w.lower() for w in words)
                    joined = "".join(words).lower()
                    if len(joined) >= 3:
                        tokens.add(joined)
                # also extract file stems from path part
                if len(parts) >= 2:
                    stem = Path(parts[1]).stem
                    for w in re.split(r"[_\-]", stem):
                        if len(w) >= 3:
                            tokens.add(w.lower())
            # Source 1b: project_map file stems (covers scout packs with empty
            # dependency_context, which is the common case for "scout" mode)
            for file_path in (data.get("project_map") or []):
                stem = Path(str(file_path)).stem
                for w in re.split(r"[_\-]", stem):
                    if len(w) >= 3:
                        tokens.add(w.lower())
    except Exception:
        pass

    # --- Source 2: committed reasoning card scope_fingerprints ---
    # Every card committed for a repo symbol auto-registers that symbol's tokens
    # as workspace signals — no manual REPO_SIGNAL_TERMS maintenance needed.
    try:
        from .settings import load_settings
        from .cache import create_operation_cache_backend
        settings = load_settings(project_root.resolve())
        backend = create_operation_cache_backend(settings)
        backend.ensure_schema()
        for entry in backend.list_cache_entries(entry_type="reasoning-card"):
            meta = entry.metadata if isinstance(entry.metadata, dict) else {}
            card = meta.get("card") if isinstance(meta.get("card"), dict) else {}
            scope = str(card.get("scope_fingerprint") or "").strip()
            if scope:
                tokens.update(_extract_scope_tokens(scope))
    except Exception:
        pass

    result = frozenset(tokens)
    _WORKSPACE_SYMBOL_CACHE[key] = result
    return result


def _load_scout_read_order(project_root: Path) -> list:
    """Return suggested_read_order from the latest scout pack, cached per project root.

    Returns an empty list if the scout pack does not exist or has no read order.
    """
    key = str(project_root.resolve())
    if key in _SCOUT_READ_ORDER_CACHE:
        return _SCOUT_READ_ORDER_CACHE[key]
    scout_path = project_root.resolve() / SCOUT_PACK_PATH
    result: list = []
    try:
        if scout_path.exists():
            data = json.loads(scout_path.read_text(encoding="utf-8", errors="ignore"))
            raw = data.get("suggested_read_order", []) or []
            result = raw if isinstance(raw, list) else []
    except Exception:
        pass
    _SCOUT_READ_ORDER_CACHE[key] = result
    return result


def _load_scout_project_map(project_root: Path) -> list:
    """Return project_map from the latest scout pack, cached per project root."""
    key = str(project_root.resolve())
    if key in _SCOUT_PROJECT_MAP_CACHE:
        return _SCOUT_PROJECT_MAP_CACHE[key]
    scout_path = project_root.resolve() / SCOUT_PACK_PATH
    result: list = []
    try:
        if scout_path.exists():
            data = json.loads(scout_path.read_text(encoding="utf-8", errors="ignore"))
            raw = data.get("project_map", []) or []
            result = raw if isinstance(raw, list) else []
    except Exception:
        pass
    _SCOUT_PROJECT_MAP_CACHE[key] = result
    return result


def _score_path_for_question(path: str, question_tokens: frozenset) -> int:
    """Count how many question tokens appear in the path's segments and stem."""
    normalized = path.lower().replace("\\", "/")
    path_tokens = frozenset(p for p in re.split(r"[/._\-]", normalized) if len(p) >= 3)
    return len(question_tokens & path_tokens)


def _filter_paths_by_question(
    question: str,
    project_map: list,
    read_order: list,
    max_results: int = 8,
) -> list:
    """Return up to max_results paths most relevant to the question.

    Scores non-noise paths from project_map by keyword overlap with the
    question, then fills any remaining slots from scout read_order so the
    agent always receives a useful starting set even when there are no matches.
    """
    q_tokens = frozenset(
        w.lower()
        for w in re.split(r"\W+", question)
        if len(w) >= 3 and w.lower() not in _HANDOFF_STOPWORDS
    )

    candidate_pool = [
        p for p in project_map
        if not any(p.startswith(prefix) for prefix in _HANDOFF_NOISE_PREFIXES)
    ]

    matched: list = []
    if q_tokens:
        scored = [
            (p, _score_path_for_question(p, q_tokens))
            for p in candidate_pool
        ]
        scored.sort(key=lambda x: x[1], reverse=True)
        matched = [p for p, s in scored if s > 0]

    already: set = set(matched)
    fallback = [p for p in read_order if p not in already]
    return (matched + fallback)[:max_results]


REPO_SIGNAL_TERMS = {
    "repo",
    "repository",
    "workspace",
    "codebase",
    "module",
    "function",
    "class",
    "method",
    "symbol",
    "file",
    "files",
    "path",
    "mcp",
    "cache",
    "delta",
    "snapshot",
    "reasoning",
    "scout",
    "drill",
    "route",
    "commit",
    "branch",
    "test",
    "tests",
    "cli",
    "bug",
    "error",
    "failing",
    "failure",
    "refactor",
    "regression",
    "runtime",
    "token",
    "latency",
    "performance",
    "implementation",
    "architecture",
    "bootstrap",
    "resolver",
    "ingest",
    "baseline",
    "embedding",
    "embeddings",
    "chunk",
    "chunks",
    "familiarization",
    "playbook",
    "provider",
    "telemetry",
    "pipeline",
    "component",
    "service",
    "handler",
    "middleware",
    # Verb synonyms — "how does X work?" is as common as "how does X function?"
    "work",
    "works",
    "working",
    # Structural / graph terms
    "graph",
    "store",
    "edges",
    "nodes",
    "recall",
    "hydration",
    # Domain-specific terms for this engine
    "drqs",
    "turncontext",
    "scoring",
    "fingerprint",
    "threshold",
    "band",
    "warm",
    "cold",
}

TOKEN_ALIASES = {
    "functions": "function",
    "methods": "method",
    "classes": "class",
    "repositories": "repository",
    "modules": "module",
    "symbols": "symbol",
    "paths": "path",
    "bootstrapping": "bootstrap",
}

REPO_INTENT_PATTERNS = [
    re.compile(r"\bwhy\s+is\s+this\s+(failing|broken|slow)\b", re.IGNORECASE),
    re.compile(r"\bhow\s+do\s+i\s+(fix|debug|refactor|optimize)\b", re.IGNORECASE),
    re.compile(r"\b(can\s+you\s+)?review\s+this\s+(implementation|change|approach)\b", re.IGNORECASE),
    re.compile(r"\bwhat\s+changed\b", re.IGNORECASE),
    re.compile(r"\bwhere\s+is\s+the\s+(bug|issue|failure)\b", re.IGNORECASE),
    re.compile(r"\bwhat\s+(functions?|classes?|methods?)\b", re.IGNORECASE),
    re.compile(r"\bwhere\s+is\s+.+\s+defined\b", re.IGNORECASE),
    # Concept-level questions that are almost always repo-scoped.
    # \S+(?:\s+\S+){0,2} allows 1-3 word subjects (e.g. "card-card edges",
    # "the resolver pipeline") instead of single-token only.
    re.compile(r"\bhow\s+does\s+\S+(?:\s+\S+){0,2}\s+(work|function|run|operate)\b", re.IGNORECASE),
    re.compile(r"\bhow\s+do\s+\S+(?:\s+\S+){0,2}\s+(work|function|run|operate)\b", re.IGNORECASE),
    re.compile(r"\bhow\s+is\s+\S+(?:\s+\S+){0,2}\s+(used|called|invoked|triggered|implemented)\b", re.IGNORECASE),
    re.compile(r"\bwhen\s+is\s+\S+(?:\s+\S+){0,2}\s+called\b", re.IGNORECASE),
    re.compile(r"\bwhat\s+does\s+\S+(?:\s+\S+){0,2}\s+do\b", re.IGNORECASE),
    re.compile(r"\bwhere\s+does\s+\S+(?:\s+\S+){0,2}\s+(come\s+from|get\s+called|run)\b", re.IGNORECASE),
    re.compile(r"\bwhy\s+does\s+\S+\s+", re.IGNORECASE),
]

GENERIC_PATTERNS = [
    re.compile(r"^\s*what\s+is\s+[a-z\s]+\??\s*$", re.IGNORECASE),
    re.compile(r"^\s*tell\s+me\s+a\s+joke", re.IGNORECASE),
    re.compile(r"^\s*how\s+are\s+you", re.IGNORECASE),
    re.compile(r"^\s*who\s+are\s+you", re.IGNORECASE),
]

# Question-shape patterns that imply a named entity in the codebase.
# Matches questions like "What does RBAC do?", "How does Dana's handler work?",
# "Explain the AuthService", "Tell me about UserManager",
# "Explain duplicate detection in the QA Analyzer".
# Keywords are matched case-insensitively via inline (?i:...) groups;
# the trailing \S*[A-Z]\S* is intentionally case-SENSITIVE so it only fires
# when the subject contains an uppercase letter (acronym or PascalCase),
# avoiding false positives on "How are you?" or "What is the weather?".
# The .{0,80} lookahead in explain/tell-me-about branches allows the
# capitalized entity to appear anywhere within the phrase (e.g. after
# lowercase descriptors like "duplicate detection in the QA Analyzer").
_NAMED_ENTITY_SHAPE = re.compile(
    r"(?:"
    r"(?i:what\s+does|how\s+does)\s+\S*[A-Z]\S*"
    r"|(?i:explain)\b.{0,80}\S*[A-Z]\S*"
    r"|(?i:tell\s+me\s+about)\b.{0,80}\S*[A-Z]\S*"
    r"|(?i:what\s+(?:is|are)|how\s+(?:is|are))(?:\s+(?i:the))?\s+\S*[A-Z]\S*"
    r")",
)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _fresh_delta_debug_enabled() -> bool:
    return (os.getenv("SEMANTIC_MCP_RESOLVE_TRACE") or "").strip().lower() in {"1", "true", "yes", "on"}


def _resolver_provider_hydration_mode() -> str:
    mode = (os.getenv("SEMANTIC_RESOLVER_PROVIDER_HYDRATION") or "probe").strip().lower()
    if mode in {"probe", "full-repo"}:
        return mode
    return "probe"


def _force_true_agent_session_enabled() -> bool:
    return (os.getenv("SEMANTIC_RESOLVER_FORCE_TRUE_AGENT_SESSION") or "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def _resolve_timeout_budget_seconds() -> int:
    raw = (os.getenv("SEMANTIC_MCP_RESOLVE_TIMEOUT_SECONDS") or "").strip()
    try:
        value = int(raw) if raw else 30
    except ValueError:
        value = 30
    return max(3, min(120, value))


def _normalize_text(value: str) -> str:
    return re.sub(r"\s+", " ", value.strip().lower())


def _tokenize(value: str) -> set[str]:
    return {token for token in re.findall(r"[a-z0-9_\-\.\/]+", _normalize_text(value)) if token}


def _normalize_tokens(tokens: set[str]) -> set[str]:
    normalized: set[str] = set()
    for token in tokens:
        normalized.add(token)
        alias = TOKEN_ALIASES.get(token)
        if alias:
            normalized.add(alias)
        if token.endswith("s") and len(token) > 3:
            normalized.add(token[:-1])
    return normalized


def classify_question(question: str, project_root: Path | None = None) -> dict[str, Any]:
    text = question.strip()
    if not text:
        return {
            "category": "generic_chat",
            "confidence": 1.0,
            "reasons": ["empty_question"],
        }

    reasons: list[str] = []
    generic_pattern_hit = any(pattern.match(text) for pattern in GENERIC_PATTERNS)
    if generic_pattern_hit:
        reasons.append("generic_pattern_match")

    tokens = _normalize_tokens(_tokenize(text))
    repo_signal_hits = sorted(token for token in tokens if token in REPO_SIGNAL_TERMS)

    # Option A: workspace symbol injection — check question tokens against
    # identifiers extracted from the scout pack (zero per-question LLM cost).
    workspace_symbol_hits: list[str] = []
    if project_root is not None:
        ws_symbols = _load_workspace_symbols(project_root)
        workspace_symbol_hits = sorted(token for token in tokens if token in ws_symbols)
    all_signal_hits = sorted(set(repo_signal_hits) | set(workspace_symbol_hits))

    if repo_signal_hits:
        reasons.append("repo_signal_terms")
    if workspace_symbol_hits:
        reasons.append("workspace_symbol_match")

    code_shape = bool(re.search(r"[/\\]|::|\.[a-z]{1,6}\b|`[^`]+`", text))
    if code_shape:
        reasons.append("code_shape_detected")

    repo_intent_hit = any(pattern.search(text) for pattern in REPO_INTENT_PATTERNS)
    if repo_intent_hit:
        reasons.append("repo_intent_phrase")

    # Named entity shape: question references a capitalized token in a
    # "what does X do" / "explain X" / "tell me about X" structure.
    named_entity_hit = bool(_NAMED_ENTITY_SHAPE.search(text))
    if named_entity_hit:
        reasons.append("named_entity_shape")

    repo_score = 0.0
    repo_score += min(len(all_signal_hits) * 0.15, 0.6)
    if all_signal_hits:
        repo_score += 0.12
    if code_shape:
        repo_score += 0.3
    if repo_intent_hit:
        repo_score += 0.28
    if named_entity_hit:
        repo_score += 0.26
    if generic_pattern_hit and not all_signal_hits and not code_shape and not named_entity_hit:
        repo_score -= 0.4

    repo_score = max(0.0, min(repo_score, 1.0))
    category = "repo_question" if repo_score >= 0.25 else "generic_chat"

    if category == "generic_chat" and not reasons:
        reasons.append("no_repo_signals")

    return {
        "category": category,
        "confidence": round(repo_score if category == "repo_question" else 1.0 - repo_score, 5),
        "reasons": reasons,
        "repo_signal_terms": repo_signal_hits,
    }


_TITLE_STOP_WORDS = frozenset({
    "what", "does", "how", "does", "the", "this", "that", "with", "from",
    "into", "when", "where", "which", "will", "does", "have", "been", "your",
    "their", "there", "here", "then", "than", "also", "some", "each", "about",
    "after", "before", "using", "show", "tell", "give", "make", "find", "list",
    "work", "call", "used", "gets", "sets", "runs", "look", "like", "take",
    "being", "should", "could", "would", "might", "those", "these", "more",
    "only", "just", "very", "over", "under", "during", "through",
})


def _extract_code_entities(text: str) -> list[str]:
    """Extract code-entity tokens from natural language text.

    Priority order:
    1. Backtick-quoted names — explicit code reference.
    2. *.py file stems — source file references.
    3. snake_case identifiers — function/variable names.
    4. PascalCase class names — single camel-cased token.
    5. Title-case noun phrases — two or more consecutive capitalised words
       (≥4 chars each, not stop-words), e.g. "Cluster Defects by Pattern"
       → "cluster defects pattern".  Covers UI feature names and menu items
       that are written in natural-language title case rather than code style.

    Returns unique entities in order of discovery, filtered to length >= 4.
    """
    seen: set[str] = set()
    entities: list[str] = []

    def _add(tok: str) -> None:
        if tok and tok not in seen and len(tok) >= 4:
            seen.add(tok)
            entities.append(tok)

    # 1. Backtick-quoted — explicit code reference, highest confidence.
    for m in re.findall(r"`([a-zA-Z_][a-zA-Z0-9_.]*)`", text):
        _add(m.split(".")[0])

    # 2. *.py file references — use stem only (strip extension).
    for m in re.findall(r"\b([a-z][a-z0-9_]+)\.[pP][yY]\b", text):
        _add(m)

    # 3. snake_case identifiers with at least one underscore (function/variable names).
    for m in re.findall(r"\b([a-z][a-z0-9]*(?:_[a-z0-9]+)+)\b", text):
        _add(m)

    # 4. PascalCase class names (two or more capitalised runs in one token).
    for m in re.findall(r"\b([A-Z][a-z0-9]+(?:[A-Z][a-z0-9]+)+)\b", text):
        # Convert CamelCase to snake_case to match module-level scope conventions.
        # e.g. HydrationCache -> hydration_cache, GraphNavigator -> graph_navigator.
        # This ensures canonical_scope() receives a form it can work with rather
        # than a flattened string where word boundaries are unrecoverable.
        _add(re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", m).lower())

    # 5. Title-case noun phrases — run of ≥2 capitalised words (≥4 chars, non-stop).
    # Collect all capitalised words that are content words, then form contiguous runs.
    words = re.findall(r"\b([A-Za-z][a-z]{2,})\b", text)
    run: list[str] = []
    for w in words:
        if w[0].isupper() and w.lower() not in _TITLE_STOP_WORDS and len(w) >= 4:
            run.append(w.lower())
        else:
            if len(run) >= 2:
                _add(" ".join(run))
            run = []
    if len(run) >= 2:
        _add(" ".join(run))

    return entities


def _is_non_code_file(path: str) -> bool:
    """Return True for config, docs, and env files that carry no useful scope signal."""
    NON_CODE_SUFFIXES = {
        ".env", ".md", ".txt", ".json", ".yaml", ".yml",
        ".toml", ".cfg", ".ini", ".lock", ".csv", ".log",
    }
    p = Path(path)
    name_lower = p.name.lower()
    if name_lower.startswith(".env") or name_lower in {
        "readme.md", "changelog.md", "copilot-instructions.md",
        "requirements.txt", "pyproject.toml", "package.json", "package-lock.json",
    }:
        return True
    return p.suffix.lower() in NON_CODE_SUFFIXES


def derive_scope_fingerprint(
    project_root: Path,
    question: str,
    file_path: str | None = None,
    symbol: str | None = None,
    selection: str | None = None,
) -> str:
    """
    Derive a stable, human-readable scope identity.

    New rules:
    - Always return <module>[::<symbol>] when possible.
    - Never return file paths.
    - Never return scope-<hash> unless absolutely unavoidable.
    - Fallback is "repo", not a digest.
    """

    # Priority 1 — explicit symbol from IDE context
    clean_symbol = (symbol or "").strip()
    if clean_symbol:
        module = _extract_module_from_path(file_path)
        raw = f"{module}::{_normalize_text(clean_symbol)}" if module else _normalize_text(clean_symbol)
        return canonical_scope(raw)

    # Priority 2 — code entities extracted from the question
    entities = _extract_code_entities(question)
    if entities:
        # Pick the most specific entity
        ent = sorted(entities, key=len, reverse=True)[0]
        module = _extract_module_from_path(file_path)
        raw = f"{module}::{ent}" if module else ent
        return canonical_scope(raw)

    # Priority 3 — module name from file stem
    module = _extract_module_from_path(file_path)
    if module:
        return canonical_scope(module)

    # Priority 4 — fallback: repo-level scope.
    # TODO (Phase 3b): check workspace symbol tokens against the question here
    # so that questions like "How does graph store work?" resolve to "graph_store"
    # instead of "repo".  This would allow the primary recall to find module-scoped
    # cards, reducing reliance on the tertiary (scope_fallback) path.  Requires
    # loading card scope_fingerprints from cache and finding the best token overlap.
    return "repo"


def _extract_module_from_path(path: str | None) -> str | None:
    """Return a clean module name from a file path, or None."""
    if not path:
        return None
    p = Path(path)
    stem = p.stem
    # Skip non-code files
    if stem in ("README", "readme", "config", "settings"):
        return None
    return _normalize_text(stem)



def _load_shadow_metadata(project_root: Path) -> dict[str, Any] | None:
    path = project_root.resolve() / SHADOW_REPORT_PATH
    if not path.exists():
        return None

    payload = json.loads(path.read_text(encoding="utf-8"))
    created_text = str(payload.get("created_utc", "")).strip()
    created = None
    if created_text:
        normalized = created_text[:-1] + "+00:00" if created_text.endswith("Z") else created_text
        try:
            created = datetime.fromisoformat(normalized)
        except ValueError:
            created = None

    age_hours = None
    if created is not None:
        if created.tzinfo is None:
            created = created.replace(tzinfo=timezone.utc)
        age_hours = (datetime.now(timezone.utc) - created.astimezone(timezone.utc)).total_seconds() / 3600.0

    status_counts = payload.get("chunk_status_counts", {})
    changed_total = int(status_counts.get("MODIFIED", 0)) + int(status_counts.get("NEW", 0)) + int(
        status_counts.get("DELETED", 0)
    )

    return {
        "exists": True,
        "age_hours": age_hours,
        "changed_total": changed_total,
        "run_id": payload.get("run_id"),
    }


def _run_fresh_delta(project_root: Path, against_snapshot_id: str | None = None) -> dict[str, Any]:
    resolved_root = project_root.resolve()
    baseline = against_snapshot_id or latest_snapshot_id(resolved_root / "data" / "baselines")
    progress_events: list[str] = []
    progress = progress_events.append if _fresh_delta_debug_enabled() else None
    hydration_mode = _resolver_provider_hydration_mode()
    report = compute_delta_report(
        resolved_root,
        baseline,
        live_provider="openai-compatible",
        playbook="session-readiness",
        provider_hydration=hydration_mode,
        progress=progress,
    )
    save_delta_run_report(report, resolved_root / "data" / "runs")
    payload = report.to_dict()

    shadow_path = resolved_root / SHADOW_REPORT_PATH
    shadow_path.parent.mkdir(parents=True, exist_ok=True)
    shadow_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    summary = summarize_run_report(payload)
    result = {
        "run_id": report.run_id,
        "baseline_snapshot_id": report.baseline_snapshot_id,
        "summary": summary.to_dict(),
        "chunk_status_counts": payload.get("chunk_status_counts", {}),
        "runtime_seconds": report.runtime_seconds,
    }

    if _fresh_delta_debug_enabled():
        settings = load_settings(resolved_root)
        result["debug"] = {
            "operation_cache_backend": settings.operation_cache_backend,
            "provider_hydration_mode": hydration_mode,
            "execution_profile": payload.get("execution_profile", {}),
            "provider_usage": payload.get("provider_usage", {}),
            "progress_event_count": len(progress_events),
            "progress_tail": progress_events[-25:],
        }

    return result


def _append_resolver_log(project_root: Path, payload: dict[str, Any]) -> str:
    path = project_root.resolve() / RESOLVER_LOG_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    sanitized_payload = _sanitize_resolver_log_payload(payload)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(sanitized_payload, separators=(",", ":")) + "\n")
    _prune_resolver_log(path)
    return str(path)


def _sanitize_resolver_log_payload(payload: dict[str, Any]) -> dict[str, Any]:
    classification = payload.get("classification", {}) if isinstance(payload.get("classification"), dict) else {}
    decision_trace = payload.get("decision_trace", []) if isinstance(payload.get("decision_trace"), list) else []

    safe_classification = {
        "category": str(classification.get("category", "unknown"))[:32],
        "confidence": float(classification.get("confidence", 0.0)),
        "reasons": [str(reason)[:40] for reason in classification.get("reasons", [])[:8]],
        "repo_signal_terms": [
            _redact_text(str(term)[:32]) for term in classification.get("repo_signal_terms", [])[:16]
        ],
    }

    safe_trace: list[dict[str, Any]] = []
    for item in decision_trace[:12]:
        if not isinstance(item, dict):
            continue
        step = str(item.get("step", "unknown"))[:40]
        entry: dict[str, Any] = {"step": step}
        for key in (
            "route",
            "category",
            "confidence",
            "candidate_count",
            "top_score",
            "top_match",
        ):
            if key in item:
                value = item[key]
                entry[key] = _redact_text(str(value)[:120]) if isinstance(value, str) else value

        if "shadow" in item and isinstance(item["shadow"], dict):
            shadow = item["shadow"]
            entry["shadow"] = {
                "exists": bool(shadow.get("exists", False)),
                "age_hours": shadow.get("age_hours"),
                "changed_total": int(shadow.get("changed_total", 0)),
                "run_id": _redact_text(str(shadow.get("run_id", ""))[:80]),
            }
        safe_trace.append(entry)

    return {
        "trace_id": str(payload.get("trace_id", ""))[:32],
        "generated_utc": str(payload.get("generated_utc", ""))[:64],
        "scope_fingerprint": str(payload.get("scope_fingerprint", ""))[:64],
        "route": str(payload.get("route", ""))[:32],
        "classification": safe_classification,
        "decision_trace": safe_trace,
        "privacy": {
            "sanitized": True,
            "retention_days": _resolver_log_retention_days(),
            "max_lines": _resolver_log_max_lines(),
        },
    }


def _redact_text(value: str) -> str:
    redacted = value
    redacted = re.sub(r"[A-Za-z0-9_\-]{24,}", "[REDACTED]", redacted)
    redacted = re.sub(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}", "[REDACTED_EMAIL]", redacted)
    return redacted


def _resolver_log_retention_days() -> int:
    raw = (os.getenv("SEMANTIC_RESOLVER_LOG_RETENTION_DAYS") or "14").strip()
    try:
        return max(1, min(int(raw), 90))
    except ValueError:
        return 14


def _resolver_log_max_lines() -> int:
    raw = (os.getenv("SEMANTIC_RESOLVER_LOG_MAX_LINES") or "5000").strip()
    try:
        return max(200, min(int(raw), 50000))
    except ValueError:
        return 5000


def _resolver_verbose_trace_enabled() -> bool:
    return (os.getenv("SEMANTIC_RESOLVER_VERBOSE_TRACE") or "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def _emit_trace_event(
    trace_hook: Callable[[str, dict[str, Any]], None] | None,
    event: str,
    **payload: Any,
) -> None:
    if trace_hook is None:
        return
    trace_hook(event, payload)


def _allow_heavy_expansion(
    question: str,
    file_path: str | None,
    symbol: str | None,
    selection: str | None,
) -> tuple[bool, str]:
    # Editor context (file/symbol/selection) confirms the question is repo-scoped
    # but does NOT by itself justify a heavy fresh_delta expansion.  Only an
    # explicit drill/delta intent should trigger that.  Without this guard every
    # question asked with an open file was running a full delta and timing out.
    has_editor_context = bool(
        (file_path and file_path.strip())
        or (symbol and symbol.strip())
        or (selection and selection.strip())
    )

    if _explicit_fresh_delta_requested(question):
        return True, "explicit_fresh_delta_intent"

    if _explicit_drill_requested(question) and has_editor_context:
        return True, "explicit_drill_with_editor_context"

    explicit_pack_intent = bool(
        re.search(
            r"\b(scout|route|drill|familiarization|read\s+order|project\s+map|architecture\s+context)\b",
            question,
            re.IGNORECASE,
        )
    )
    if explicit_pack_intent:
        return True, "explicit_pack_intent"

    return False, "broad_no_editor_context"


def _explicit_drill_requested(question: str) -> bool:
    return bool(
        re.search(
            r"\b(drill|deep\s+analysis|thorough\s+analysis|full\s+analysis|investigate\s+deeply)\b",
            question,
            re.IGNORECASE,
        )
    )


def _explicit_fresh_delta_requested(question: str) -> bool:
    return bool(
        re.search(
            r"\b(fresh\s+delta|full\s+delta|run\s+(the\s+)?delta|rerun\s+(the\s+)?delta|shadow\s+delta|recompute\s+(the\s+)?delta)\b",
            question,
            re.IGNORECASE,
        )
    )


def _build_agent_handoff_payload(
    question: str,
    recall_payload: dict[str, Any],
    top_candidate: dict[str, Any],
    skip_reason: str,
    project_root: "Path | None" = None,
) -> dict[str, Any]:
    candidates = recall_payload.get("candidates", []) if isinstance(recall_payload, dict) else []
    safe_candidates = candidates[:3] if isinstance(candidates, list) else []
    selected = top_candidate if top_candidate else None
    candidate_count = int(recall_payload.get("candidate_count", 0))
    top_score = float(top_candidate.get("score", 0.0)) if top_candidate else 0.0

    # Adaptive task description based on how warm the cache is.
    if candidate_count == 0 or top_score == 0.0:
        task = (
            "Cache empty for this question — read from the codebase directly. "
            "Start with files in `suggested_read_order` if present."
        )
    elif top_score < 0.8:
        task = (
            f"Partial cache match (score={top_score:.2f}) — treat as a hypothesis "
            "and verify with targeted code lookup before citing."
        )
    else:
        task = (
            f"Strong partial match (score={top_score:.2f}) — likely correct; "
            "add a brief code citation to confirm."
        )

    # Inject question-filtered paths on cold cache so Copilot has a focused
    # starting point rather than the generic top-8 docs/README list.
    suggested: list = []
    scout_pack_warning: str | None = None
    if project_root is not None:
        scout_path = project_root.resolve() / SCOUT_PACK_PATH
        if scout_path.exists():
            try:
                import os
                mtime = scout_path.stat().st_mtime
                age_hours = (datetime.now(timezone.utc).timestamp() - mtime) / 3600.0
                _SCOUT_PACK_STALE_HOURS = 48.0
                if age_hours > _SCOUT_PACK_STALE_HOURS:
                    scout_pack_warning = (
                        f"Scout pack is {age_hours:.0f}h old (threshold {_SCOUT_PACK_STALE_HOURS:.0f}h). "
                        "Workspace symbols may be stale — consider running `semantic-cache scout` "
                        "or the 'Semantic Scout Pack Start' task to refresh."
                    )
            except Exception:
                pass
        if candidate_count == 0:
            scout_order = _load_scout_read_order(project_root)
            project_map_paths = _load_scout_project_map(project_root)
            suggested = _filter_paths_by_question(question, project_map_paths, scout_order)

    handoff_context: dict[str, Any] = {
        "question": question,
        "reason": skip_reason,
        "task": task,
        "prioritized_inputs": [
            "recall.selected_candidate",
            "recall.candidates",
            "scope_fingerprint",
            "classification.reasons",
        ],
    }
    if suggested:
        handoff_context["suggested_read_order"] = suggested
    if scout_pack_warning:
        handoff_context["scout_pack_warning"] = scout_pack_warning

    return {
        "handoff_type": "agent_context_seed",
        "reused": False,
        "candidate_count": candidate_count,
        "selected_candidate": selected,
        "memory_candidates": safe_candidates,
        "expansion_skipped": True,
        "expansion_skip_reason": skip_reason,
        "hint": "Pass file_path/symbol/selection (or ask for scout/route/drill) to run deep workspace analysis.",
        "handoff_context": handoff_context,
    }


def _direct_reuse_candidate_is_safe(candidate: dict[str, Any]) -> bool:
    score = float(candidate.get("score", 0.0))
    match_type = str(candidate.get("match_type", ""))
    intent_overlap = float(candidate.get("intent_overlap", 0.0))
    scope_overlap = float(candidate.get("scope_overlap", 0.0))
    schema_version = str(candidate.get("schema_version", "reason-v1"))
    validation_status = str(candidate.get("validation_status", "")).strip().lower()
    scope_fallback = bool(candidate.get("_scope_fallback", False))

    # Skeleton cards are auto-committed by the resolver at handoff time.
    # They carry constraints.route="agent_handoff" AND source="resolver" or
    # source="resolver-agent-handoff".  Checking both fields prevents incorrectly
    # blocking legitimate agent cards committed during an agent_handoff session.
    _constraints_raw = candidate.get("constraints")
    if isinstance(_constraints_raw, dict):
        constraints = _constraints_raw
    elif isinstance(_constraints_raw, str):
        try:
            constraints = json.loads(_constraints_raw)
            if not isinstance(constraints, dict):
                constraints = {}
        except Exception:
            constraints = {}
    else:
        constraints = {}
    card_source = str(candidate.get("source", "")).strip().lower()
    if constraints.get("route") == "agent_handoff" and card_source in {
        "resolver",
        "mcp-resolver",
        "resolver-agent-handoff",
        "",
    }:
        return False

    # Secondary boilerplate guard: catch skeleton cards even if source field
    # is missing or misclassified (e.g. older DB entries before source was
    # surfaced in recall candidates).
    _BOILERPLATE_PHRASES = (
        "agent handoff prepared with memory-first context",
        "use recalled reasoning candidates first",
        "do targeted code lookup only for missing evidence",
        "cache empty for this question",
    )
    summary_lower = str(candidate.get("outcome_summary", "")).strip().lower()
    if any(phrase in summary_lower for phrase in _BOILERPLATE_PHRASES):
        return False

    # Strict path: reason-v2 cards with full validation metadata.
    if (
        score >= 0.95
        and match_type == "exact"
        and intent_overlap >= 0.99
        and scope_overlap >= 0.99
        and schema_version == "reason-v2"
        and validation_status in {"captured", "verified"}
    ):
        return True

    # Relaxed path: reason-v1 cards (agent write-back without schema upgrade)
    # that are a perfect intent+scope match.  These lack validation metadata but
    # the 1.0 exact score is sufficient evidence of a good hit.  Cards explicitly
    # marked "unverified" are still rejected.
    if (
        score >= 0.99
        and match_type == "exact"
        and intent_overlap >= 0.99
        and scope_overlap >= 0.99
        and schema_version == "reason-v1"
        and validation_status != "unverified"
    ):
        return True

    # Intent-only fallback path: card was found via tertiary intent-only recall
    # (or secondary file-path recall) where scope_overlap is ~0 due to the card
    # using a literal file-path scope vs the derived hash scope used at query time.
    # Threshold set to 0.80 (was 0.55) to leave a real DRQS near-miss window:
    # cards with intent_overlap 0.55–0.79 are found by tertiary recall but are
    # not safe for direct reuse — they are routed to graph_assisted instead.
    # Cards with intent_overlap >= 0.80 are strong enough paraphrases to reuse.
    if (
        scope_fallback
        and intent_overlap >= 0.80
        and score >= 0.35
        and schema_version in {"reason-v2", "reason-v1"}
        and validation_status != "unverified"
    ):
        return True

    # Warm-recall path: reason-v2 card with a strong paraphrase score found via
    # primary recall (scope not a fallback).  Scores 0.80–0.94 are below the
    # strict-path threshold (0.95 exact) but well above the DRQS band ceiling
    # (0.79).  The fast-lane preflight covers this zone when no editor context is
    # present, but preflight is skipped when file_path/symbol/selection are set.
    # This path closes that gap so high-confidence paraphrases always get a
    # direct reuse route rather than falling through to agent_handoff.
    if (
        not scope_fallback
        and score >= 0.80
        and intent_overlap >= 0.65
        and scope_overlap >= 0.15
        and schema_version == "reason-v2"
        and validation_status != "unverified"
    ):
        return True

    return False


def _commit_agent_handoff_reasoning(
    project_root: Path,
    *,
    question: str,
    scope_fingerprint: str,
    trace_id: str | None,
    classification: dict[str, Any],
    route_payload: dict[str, Any],
) -> dict[str, Any] | None:
    # Skeleton cards were previously committed here to prevent repeat cold-start
    # agent_handoff runs.  In practice the agent always calls reasoning_commit at
    # the end of its turn, so the skeleton was immediately superseded and actively
    # harmful: it blocked DRQS routing on the second ask (score 1.00, above
    # near-miss band) and required a periodic purge script to clean up.
    # Removed — if the agent fails to write back, the question goes to
    # agent_handoff again, which is the correct behaviour.
    return None


def _commit_forced_agent_session_reasoning(
    project_root: Path,
    *,
    question: str,
    scope_fingerprint: str,
    trace_id: str | None,
    classification: dict[str, Any],
    route: str,
    route_payload: dict[str, Any],
) -> dict[str, Any] | None:
    if route == "agent_handoff":
        return None

    if route == "fresh_delta":
        summary = f"fresh_delta completed (run_id={route_payload.get('run_id')}, runtime_seconds={route_payload.get('runtime_seconds')})"
    elif route in {"scout", "drill"}:
        summary = (
            f"{route} familiarization prepared with confidence={route_payload.get('pack_confidence', {}).get('overall')} "
            f"and evidence_count={len(route_payload.get('evidence_cards', []) or route_payload.get('suggested_read_order', []))}"
        )
    elif route == "recall":
        selected = route_payload.get("selected_candidate", {}) if isinstance(route_payload, dict) else {}
        summary = f"recall reused prior reasoning (card_id={selected.get('card_id')}, score={selected.get('score')})"
    else:
        summary = f"route={route} completed under forced true-agent-session mode"

    evidence_anchors: list[dict[str, Any]] = [
        {
            "anchor_type": "resolver_route",
            "route": route,
            "trace_id": trace_id,
        }
    ]
    if isinstance(route_payload, dict):
        if route_payload.get("run_id"):
            evidence_anchors.append(
                {
                    "anchor_type": "delta_run",
                    "run_id": route_payload.get("run_id"),
                }
            )
        selected = route_payload.get("selected_candidate")
        if isinstance(selected, dict) and selected.get("card_id"):
            evidence_anchors.append(
                {
                    "anchor_type": "reused_reasoning_card",
                    "card_id": selected.get("card_id"),
                    "score": selected.get("score"),
                }
            )

    card_payload = {
        "schema_version": "reason-v2",
        "task_intent": question,
        "scope_fingerprint": scope_fingerprint,
        "dependency_fingerprint": f"resolver:{scope_fingerprint}:route={route}:policy=forced_true_agent_session",
        "chosen_plan": [
            "Bypass agent_handoff to measure true agent-session behavior.",
            "Run the selected resolver route with full metrics collection.",
            "Persist local reasoning for follow-up recall and comparisons.",
        ],
        "assumptions": [
            "This run is for baseline metrics analysis.",
            "Reasoning-card remains local-only and out of central sync.",
        ],
        "constraints": {
            "route": route,
            "force_true_agent_session": True,
            "policy_mode": "forced_true_agent_session",
            "local_only": True,
        },
        "validation_evidence": [
            f"route={route}",
            "mode=forced_true_agent_session",
            f"trace_id={trace_id or ''}",
        ],
        "outcome_summary": summary,
        "confidence": float(classification.get("confidence", 0.0)) if isinstance(classification, dict) else 0.0,
        "evidence_anchors": evidence_anchors,
        "validation": {
            "status": "captured",
            "method": "resolver-forced-session-capture",
            "validated_at": _utc_now(),
        },
        "reuse_guardrails": [
            "Use this card for baseline comparisons where handoff is intentionally bypassed.",
            "Do not sync reasoning-card entries to central storage.",
        ],
        "source_run_id": trace_id,
    }

    try:
        return commit_reasoning_card(
            project_root=project_root,
            card_payload=card_payload,
            source="resolver-forced-agent-session",
        )
    except Exception:
        return None


def _build_memory_commit_summary(memory_commit: dict[str, Any]) -> dict[str, Any]:
    card_payload = memory_commit.get("card") if isinstance(memory_commit, dict) else None
    if not isinstance(card_payload, dict):
        card_payload = {}

    validation_payload = card_payload.get("validation") if isinstance(card_payload.get("validation"), dict) else {}
    evidence_anchors = card_payload.get("evidence_anchors") if isinstance(card_payload.get("evidence_anchors"), list) else []

    return {
        "status": memory_commit.get("status"),
        "entry_type": memory_commit.get("entry_type"),
        "chunk_id": memory_commit.get("chunk_id"),
        "schema_version": card_payload.get("schema_version"),
        "dependency_fingerprint": card_payload.get("dependency_fingerprint"),
        "supersedes_card_id": card_payload.get("supersedes_card_id"),
        "validation_status": validation_payload.get("status"),
        "evidence_anchor_count": len(evidence_anchors),
    }


def _prune_resolver_log(path: Path) -> None:
    if not path.exists():
        return

    retention_days = _resolver_log_retention_days()
    max_lines = _resolver_log_max_lines()
    cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)

    kept: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        keep_line = True
        try:
            payload = json.loads(line)
            generated = str(payload.get("generated_utc", "")).strip()
            if generated:
                candidate = datetime.fromisoformat(generated.replace("Z", "+00:00"))
                if candidate.tzinfo is None:
                    candidate = candidate.replace(tzinfo=timezone.utc)
                if candidate < cutoff:
                    keep_line = False
        except Exception:
            keep_line = True

        if keep_line:
            kept.append(line)

    if len(kept) > max_lines:
        kept = kept[-max_lines:]

    path.write_text("\n".join(kept) + ("\n" if kept else ""), encoding="utf-8")


def _fast_lane_eligible(candidate: dict[str, Any]) -> bool:
    """Return True if a recall candidate qualifies for the fast-lane shortcut.

    Fast-lane criteria (all must hold):
    - score >= _FAST_LANE_SCORE_THRESHOLD (0.80)
    - schema_version == "reason-v2"
    - source not in _FAST_LANE_REJECTED_SOURCES
    - constraints.route != "agent_handoff"  (blocks skeleton/placeholder cards)
    - outcome_summary is non-empty (card has actual content)
    """
    if float(candidate.get("score", 0.0)) < _FAST_LANE_SCORE_THRESHOLD:
        return False
    if str(candidate.get("schema_version", "")).strip() != "reason-v2":
        return False
    source = str(candidate.get("source", "")).strip().lower()
    if source in _FAST_LANE_REJECTED_SOURCES:
        return False
    constraints = candidate.get("constraints") if isinstance(candidate.get("constraints"), dict) else {}
    if constraints.get("route") == "agent_handoff":
        return False
    if not str(candidate.get("outcome_summary", "")).strip():
        return False
    return True


def _fast_lane_lru_key(project_root: Path, question: str) -> tuple[str, str]:
    return (str(project_root.resolve()), question.strip().lower())


def _fast_lane_lru_get(project_root: Path, question: str) -> dict[str, Any] | None:
    key = _fast_lane_lru_key(project_root, question)
    entry = _FAST_LANE_LRU.get(key)
    if entry is not None:
        # Refresh to most-recently-used position
        _FAST_LANE_LRU.pop(key)
        _FAST_LANE_LRU[key] = entry
    return entry


def _fast_lane_lru_put(project_root: Path, question: str, value: dict[str, Any]) -> None:
    key = _fast_lane_lru_key(project_root, question)
    if key in _FAST_LANE_LRU:
        _FAST_LANE_LRU.pop(key)
    _FAST_LANE_LRU[key] = value
    # Evict oldest entries when over capacity
    while len(_FAST_LANE_LRU) > _FAST_LANE_LRU_MAX:
        _FAST_LANE_LRU.pop(next(iter(_FAST_LANE_LRU)))


# ---------------------------------------------------------------------------
# DRQS near-miss helpers (Phase 7)
# ---------------------------------------------------------------------------

def _is_skeleton_candidate(candidate: dict[str, Any]) -> bool:
    """Return True if this recall candidate is a resolver-written skeleton/handoff card.

    Skeleton cards are auto-committed at agent_handoff time.  They score 1.00 on
    identical re-asks but carry no real answer content and must be excluded from
    DRQS eligibility evaluation so the real near-miss candidates below them can
    trigger graph_assisted routing.
    """
    constraints = candidate.get("constraints") if isinstance(candidate.get("constraints"), dict) else {}
    source = str(candidate.get("source", "")).strip().lower()
    if constraints.get("route") == "agent_handoff" and source in {
        "resolver", "mcp-resolver", "resolver-agent-handoff", "bundle-import", "",
    }:
        return True
    summary_lower = str(candidate.get("outcome_summary", "")).strip().lower()
    _BOILERPLATE = (
        "agent handoff prepared with memory-first context",
        "cache empty for this question",
        "use recalled reasoning candidates first",
        "do targeted code lookup only for missing evidence",
    )
    return any(phrase in summary_lower for phrase in _BOILERPLATE)


def _drqs_effective_top(
    top: dict[str, Any],
    recall_payload: dict[str, Any],
) -> dict[str, Any] | None:
    """Return the first non-skeleton candidate from the recall payload.

    Skeleton cards (auto-committed at agent_handoff, score 1.00) are skipped so
    that DRQS eligibility and graph-build are both evaluated against the real
    near-miss card rather than the blocking skeleton.  Returns None if every
    candidate is a skeleton.
    """
    all_candidates: list[dict[str, Any]] = recall_payload.get("candidates", [])
    for c in [top] + [x for x in all_candidates if x is not top]:
        if not _is_skeleton_candidate(c):
            return c
    return None


def _drqs_near_miss_eligible(
    top: dict[str, Any],
    recall_payload: dict[str, Any],
    force_true_agent_session: bool,
    project_root: "Path",
) -> bool:
    """Return True if the question is a near-miss candidate for graph-assisted routing.

    Criteria (all must hold):
    - Not a forced true-agent-session measurement run
    - recall returned at least 1 candidate
    - best non-skeleton candidate score is within configured near-miss band [min, max]
    - that candidate has sufficient scope overlap

    Skeleton cards (auto-committed at agent_handoff time) are excluded from the
    eligibility check — they score 1.00 on re-asks but carry no real answer and
    would otherwise block DRQS even when real near-miss cards exist below them.
    """
    if force_true_agent_session:
        return False
    if int(recall_payload.get("candidate_count", 0)) == 0:
        return False
    try:
        from .settings import load_settings
        settings = load_settings(project_root.resolve())
        nm_min = settings.drqs_near_miss_min_score
        nm_max = settings.drqs_near_miss_max_score
        nm_scope_gate = settings.drqs_min_scope_overlap
    except Exception:
        nm_min, nm_max, nm_scope_gate = 0.40, 0.79, 0.10

    # Find the first non-skeleton candidate to use as the effective "top".
    # Only the *best* real candidate is checked — scanning all would allow a
    # secondary in-band candidate to trigger DRQS even when the true best
    # candidate is outside the band.
    effective_top = _drqs_effective_top(top, recall_payload)
    if effective_top is None:
        return False
    top_score = float(effective_top.get("score", 0.0))
    scope_overlap = float(effective_top.get("scope_overlap", 0.0))

    # Tertiary recall (scope_fallback=True) ignores scope entirely by design,
    # so scope_overlap is always 0 for those candidates.  The scope gate would
    # permanently block DRQS for any tertiary match.  Intent quality is already
    # enforced upstream (require_intent_overlap >= 0.55 at recall time), so it
    # is safe to skip the scope gate for scope_fallback candidates.
    if effective_top.get("_scope_fallback"):
        return nm_min <= top_score <= nm_max

    return nm_min <= top_score <= nm_max and scope_overlap >= nm_scope_gate


def _build_graph_assisted_route(
    project_root: "Path",
    question: str,
    scope_fingerprint: str,
    recall_payload: dict[str, Any],
    top: dict[str, Any],
) -> tuple[str, dict[str, Any]]:
    """Build a graph_assisted route payload or return ("agent_handoff", fallback).

    Runs the DRQS graph walk within the configured timeout.
    Returns ("graph_assisted", payload) or ("agent_handoff", fallback_payload).
    Never raises.
    """
    import time
    try:
        from .settings import load_settings
        from .graph_store import GraphStore
        from .hydration_cache import HydrationCache

        settings = load_settings(project_root.resolve())
        min_nodes = settings.drqs_min_context_nodes

        candidates = recall_payload.get("candidates", [])[:3]
        # Add card_id to each candidate from the card dict if missing at top level
        dqa_candidates = []
        for c in candidates:
            card = c.get("card") if isinstance(c.get("card"), dict) else c
            cid = str(c.get("card_id", "")).strip() or str(card.get("card_id", "")).strip()
            if cid:
                dqa_candidates.append({"card_id": cid, "score": float(c.get("score", 0.0))})

        if not dqa_candidates:
            return ("agent_handoff", {})

        gs = GraphStore(project_root.resolve())
        hydration = HydrationCache(gs, settings)
        ctx = hydration.build(dqa_candidates, question_intent=question, question_scope=scope_fingerprint)

        if ctx.is_useful(min_nodes=min_nodes):
            payload = {
                "turn_context": ctx.to_dict(),
                "near_miss_top_score": float(top.get("score", 0.0)),
                "near_miss_top_card_id": str(top.get("card_id", "")),
                "candidate_count": len(dqa_candidates),
            }
            return ("graph_assisted", payload)

        return ("agent_handoff", {})

    except Exception:
        return ("agent_handoff", {})


def resolve_developer_question(
    project_root: Path,
    question: str,
    file_path: str | None = None,
    symbol: str | None = None,
    selection: str | None = None,
    against_snapshot_id: str | None = None,
    trace_id: str | None = None,
    trace_hook: Callable[[str, dict[str, Any]], None] | None = None,
) -> dict[str, Any]:
    resolved_root = project_root.resolve()

    # ------------------------------------------------------------------
    # Fast-lane: check in-process LRU first (near-zero cost).
    # Only applies when there is no editor context and no forced agent
    # session — broad questions only.
    # ------------------------------------------------------------------
    _force_agent = _force_true_agent_session_enabled()
    _has_ctx = bool(
        (file_path and file_path.strip())
        or (symbol and symbol.strip())
        or (selection and selection.strip())
    )
    if not _has_ctx and not _force_agent:
        _lru_hit = _fast_lane_lru_get(resolved_root, question)
        if _lru_hit is not None:
            return {
                **_lru_hit,
                "generated_utc": datetime.now(timezone.utc).isoformat(),
                "trace_id": trace_id or _lru_hit.get("trace_id", ""),
                "decision_trace": [{"step": "fast_lane_lru", "source": "in_memory_cache"}],
            }

        # Run a fast preflight recall to see if we can skip full classification.
        try:
            _fl_scope = derive_scope_fingerprint(
                resolved_root, question=question,
                file_path=None, symbol=None, selection=None,
            )
            _fl_recall = recall_reasoning_cards(
                project_root=resolved_root,
                task_intent=question,
                scope_fingerprint=_fl_scope,
                limit=1,
                max_age_hours=24.0 * 14.0,
            )
            _fl_top = (
                _fl_recall.get("candidates", [{}])[0]
                if _fl_recall.get("candidates")
                else {}
            )
            if _fast_lane_eligible(_fl_top):
                _fl_response = {
                    "route": "fast_lane",
                    "classification": {
                        "category": "repo_question",
                        "confidence": 1.0,
                        "reasons": ["fast_lane_recall"],
                        "repo_signal_terms": [],
                    },
                    "scope_fingerprint": _fl_top.get("scope_fingerprint", _fl_scope),
                    "context": {
                        "file_path": None,
                        "symbol": None,
                        "selection_excerpt": "",
                    },
                    "decision_trace": [
                        {
                            "step": "fast_lane",
                            "score": _fl_top.get("score"),
                            "match_type": _fl_top.get("match_type"),
                            "card_id": _fl_top.get("card_id"),
                        }
                    ],
                    "route_payload": {
                        "reused": True,
                        "selected_candidate": _fl_top,
                        "candidate_count": 1,
                    },
                    "recall": {
                        "candidate_count": 1,
                        "match_mode": _fl_top.get("match_type", "semantic"),
                        "candidates": [_fl_top],
                    },
                }
                _fast_lane_lru_put(resolved_root, question, _fl_response)
                return {
                    **_fl_response,
                    "generated_utc": datetime.now(timezone.utc).isoformat(),
                    "trace_id": trace_id or "",
                }
        except Exception:
            pass  # fast-lane failure must never block normal routing

    classification = classify_question(question, project_root=project_root)
    if (file_path and file_path.strip()) or (symbol and symbol.strip()) or (selection and selection.strip()):
        classification["category"] = "repo_question"
        classification["confidence"] = max(float(classification.get("confidence", 0.0)), 0.9)
        reasons = list(classification.get("reasons", []))
        if "editor_context_present" not in reasons:
            reasons.append("editor_context_present")
        classification["reasons"] = reasons
    scope_fingerprint = derive_scope_fingerprint(
        resolved_root,
        question=question,
        file_path=file_path,
        symbol=symbol,
        selection=selection,
    )

    decision_trace: list[dict[str, Any]] = []
    decision_trace.append(
        {
            "step": "classify",
            "category": classification["category"],
            "confidence": classification["confidence"],
            "reasons": classification.get("reasons", []),
        }
    )

    route = "generic_chat"
    route_payload: dict[str, Any] = {}
    recall_payload = None
    force_true_agent_session = _force_true_agent_session_enabled()
    policy_mode = "forced_true_agent_session" if force_true_agent_session else "standard"

    # Recall-first pre-check: even if the classifier says generic_chat, run a
    # lightweight recall probe.  If the cache has an exact/near-exact match,
    # promote the question to repo_question so the full recall path runs.
    # This prevents committed cards from being silently bypassed due to
    # classification misses on natural-language concept questions.
    if classification["category"] == "generic_chat" and not force_true_agent_session:
        try:
            _preflight_recall = recall_reasoning_cards(
                project_root=resolved_root,
                task_intent=question,
                scope_fingerprint=scope_fingerprint,
                limit=1,
                max_age_hours=24.0 * 14.0,
            )
            _preflight_top = (
                _preflight_recall.get("candidates", [{}])[0]
                if _preflight_recall.get("candidates")
                else {}
            )
            # Second-pass scope-agnostic probe: cards committed with specific
            # module scopes (e.g. ReactFiberWorkLoop, ReactFiberHooks) are
            # invisible to a scope-matched probe when the question has no
            # code-shape signals and resolves to scope="repo".  This is the
            # common case for natural-language concept questions (e.g.
            # "Where is the reconciliation algorithm implemented?").  Running
            # an intent-only pass after the scope-matched pass catches these
            # so committed cards are not silently bypassed.
            if float(_preflight_top.get("score", 0.0)) < 0.55:
                _preflight_recall_intent = recall_reasoning_cards(
                    project_root=resolved_root,
                    task_intent=question,
                    scope_fingerprint=scope_fingerprint,
                    limit=1,
                    max_age_hours=24.0 * 14.0,
                    require_intent_overlap=0.30,
                    require_scope_overlap=0.0,
                )
                _preflight_top_intent = (
                    _preflight_recall_intent.get("candidates", [{}])[0]
                    if _preflight_recall_intent.get("candidates")
                    else {}
                )
                if float(_preflight_top_intent.get("score", 0.0)) >= 0.55:
                    _preflight_top = _preflight_top_intent
            if float(_preflight_top.get("score", 0.0)) >= 0.55:
                classification["category"] = "repo_question"
                classification["confidence"] = max(float(classification.get("confidence", 0.0)), 0.6)
                reasons = list(classification.get("reasons", []))
                reasons.append("recall_preflight_hit")
                classification["reasons"] = reasons
                decision_trace.append(
                    {
                        "step": "classify_override",
                        "reason": "recall_preflight_hit",
                        "preflight_score": float(_preflight_top.get("score", 0.0)),
                    }
                )
        except Exception:
            pass  # preflight failure must never block routing
    allow_heavy_expansion, heavy_expansion_reason = _allow_heavy_expansion(
        question=question,
        file_path=file_path,
        symbol=symbol,
        selection=selection,
    )

    if classification["category"] == "repo_question" and force_true_agent_session and not allow_heavy_expansion:
        allow_heavy_expansion = True
        heavy_expansion_reason = "forced_true_agent_session"
        decision_trace.append(
            {
                "step": "heavy_expansion_override",
                "reason": heavy_expansion_reason,
            }
        )

    if classification["category"] == "repo_question":
        if force_true_agent_session:
            recall_payload = {
                "candidate_count": 0,
                "match_mode": "none",
                "candidates": [],
            }
            _emit_trace_event(
                trace_hook,
                "resolver_recall_skipped",
                reason="forced_true_agent_session",
            )
            decision_trace.append(
                {
                    "step": "recall_skipped",
                    "reason": "forced_true_agent_session",
                }
            )
        else:
            recall_started_at = datetime.now(timezone.utc)
            _emit_trace_event(trace_hook, "resolver_recall_start")
            # Primary recall: use the derived hash scope_fingerprint.
            recall_payload = recall_reasoning_cards(
                project_root=resolved_root,
                task_intent=question,
                scope_fingerprint=scope_fingerprint,
                limit=3,
                max_age_hours=24.0 * 14.0,
                require_intent_overlap=0.98,
                require_scope_overlap=0.98,
                allowed_policy_modes=["any", policy_mode, "forced_true_agent_session"],
            )
            _primary_top_unsafe = (
                int(recall_payload.get("candidate_count", 0)) > 0
                and not _direct_reuse_candidate_is_safe(
                    recall_payload.get("candidates", [{}])[0]
                )
            )
            # Secondary recall: when editor context (file_path) is present and the
            # primary recall missed OR returned only an unsafe candidate (skeleton).
            # Agent write-back cards use literal file paths, not the derived hash,
            # so this bridges the scope mismatch on the first post-commit recall.
            # Intent threshold raised to 0.55 to reduce false positives from
            # unrelated cards that happen to share a few tokens with the current
            # question about the same file.
            if (int(recall_payload.get("candidate_count", 0)) == 0 or _primary_top_unsafe) and file_path and file_path.strip():
                recall_payload_fp = recall_reasoning_cards(
                    project_root=resolved_root,
                    task_intent=question,
                    scope_fingerprint=file_path.strip(),
                    limit=3,
                    max_age_hours=24.0 * 14.0,
                    require_intent_overlap=0.55,
                    require_scope_overlap=0.0,
                    allowed_policy_modes=["any", policy_mode, "forced_true_agent_session"],
                )
                if int(recall_payload_fp.get("candidate_count", 0)) > 0:
                    for c in recall_payload_fp.get("candidates", []):
                        c["_scope_fallback"] = True
                    recall_payload = recall_payload_fp
                    decision_trace.append({"step": "recall_fallback", "reason": "file_path_scope_match"})
                    _primary_top_unsafe = False
            # Tertiary recall: intent-only pass — ignores scope entirely.
            # Catches cards committed with literal file-path scopes when no
            # file_path is available in the request (e.g. question asked without
            # an open editor tab), and also fires when the primary pass returned
            # a skeleton card (unsafe top) that was not resolved by secondary.
            # Intent threshold lowered to 0.10 (was 0.20, originally 0.55).
            # 0.20 was still too strict for vocabulary-divergent paraphrases
            # that share stemmed vocabulary but few raw tokens — e.g. "Explain
            # how React decides which updates are higher priority than others"
            # shares ~0.15 raw Jaccard with "How does the scheduler prioritize
            # work? What are lanes / lane-based priority?" but the Porter-stemmed
            # BM25 in the FTS sidecar ranks it as a strong match.  The BM25
            # score modifier in recall_reasoning_cards lifts these candidates to
            # 0.40 (nm_min) when fts_rr >= 0.70 — without lowering to 0.10 here
            # those candidates are filtered before BM25 can act.
            # The DRQS near-miss band (0.40–0.79) and
            # _direct_reuse_candidate_is_safe thresholds (0.80+) remain
            # unchanged — lowering this floor widens only what enters the
            # graph_assisted evaluation, not what gets direct reuse.
            if int(recall_payload.get("candidate_count", 0)) == 0 or _primary_top_unsafe:
                recall_payload_intent = recall_reasoning_cards(
                    project_root=resolved_root,
                    task_intent=question,
                    scope_fingerprint=scope_fingerprint,
                    limit=3,
                    max_age_hours=24.0 * 14.0,
                    require_intent_overlap=0.10,
                    require_scope_overlap=0.0,
                    allowed_policy_modes=["any", policy_mode, "forced_true_agent_session"],
                )
                if int(recall_payload_intent.get("candidate_count", 0)) > 0:
                    # Tag candidates so _direct_reuse_candidate_is_safe can apply
                    # intent-only criteria (scope_overlap will be ~0 since the card
                    # uses a literal file-path scope vs the derived hash scope).
                    for c in recall_payload_intent.get("candidates", []):
                        c["_scope_fallback"] = True
                    recall_payload = recall_payload_intent
                    decision_trace.append({"step": "recall_fallback", "reason": "intent_only_scope_mismatch"})
            _emit_trace_event(
                trace_hook,
                "resolver_recall_done",
                elapsed_seconds=round((datetime.now(timezone.utc) - recall_started_at).total_seconds(), 6),
                candidate_count=int(recall_payload.get("candidate_count", 0)),
                match_mode=recall_payload.get("match_mode", "none"),
            )
        top = recall_payload.get("candidates", [{}])[0] if recall_payload.get("candidates") else {}
        top_score = float(top.get("score", 0.0))
        top_match = str(top.get("match_type", "none"))
        direct_reuse_safe = _direct_reuse_candidate_is_safe(top)

        # If the top candidate was rejected (e.g. skeleton card), try the next
        # candidates in rank order before falling through to agent_handoff.
        # This handles the case where the skeleton scored 1.0 and a real answer
        # card is sitting at position 1 or 2 in the same recall result.
        if not direct_reuse_safe:
            for _alt in recall_payload.get("candidates", [])[1:]:
                if _direct_reuse_candidate_is_safe(_alt):
                    top = _alt
                    top_score = float(top.get("score", 0.0))
                    top_match = str(top.get("match_type", "none"))
                    direct_reuse_safe = True
                    decision_trace.append({"step": "recall_candidate_promotion", "reason": "top_rejected_used_next"})
                    break

        decision_trace.append(
            {
                "step": "recall",
                "candidate_count": int(recall_payload.get("candidate_count", 0)),
                "top_score": round(top_score, 5),
                "top_match": top_match,
                "top_schema_version": top.get("schema_version"),
                "top_validation_status": top.get("validation_status"),
                "top_policy_mode": top.get("policy_mode"),
                "direct_reuse_safe": direct_reuse_safe,
            }
        )

        # Phase 6A — same-module / different-verb-class demotion.
        # A card may score high enough for direct reuse but represent a different
        # operation on the same module (e.g. the cache has `resolver::build` and
        # the question is asking about `resolver::traverse`).  Re-using that card
        # would return the wrong answer.  Demote to DRQS so the existing card
        # supplies module context while the new angle is answered fresh.
        _canonical_intent_demoted = False
        if direct_reuse_safe and not force_true_agent_session:
            _q_ci = derive_canonical_intent(question, scope_fingerprint)
            _top_ci = str(top.get("canonical_intent") or "").strip()
            if (
                _q_ci
                and _top_ci
                and _q_ci != _top_ci
                and _q_ci.split("::")[0] == _top_ci.split("::")[0]
            ):
                direct_reuse_safe = False
                _canonical_intent_demoted = True
                decision_trace.append(
                    {
                        "step": "canonical_intent_demote",
                        "reason": "same_module_different_verb",
                        "question_canonical_intent": _q_ci,
                        "top_canonical_intent": _top_ci,
                    }
                )

        if direct_reuse_safe:
            route = "recall"
            route_payload = {
                "reused": True,
                "selected_candidate": top,
                "candidate_count": recall_payload.get("candidate_count", 0),
            }
        elif _canonical_intent_demoted or _drqs_near_miss_eligible(
            top=top,
            recall_payload=recall_payload,
            force_true_agent_session=force_true_agent_session,
            project_root=resolved_root,
        ):
            # Use the effective non-skeleton top for the graph build — the raw
            # `top` may be a skeleton that is absent from the graph store.
            _drqs_top = _drqs_effective_top(top, recall_payload) or top
            _graph_route, _graph_payload = _build_graph_assisted_route(
                project_root=resolved_root,
                question=question,
                scope_fingerprint=scope_fingerprint,
                recall_payload=recall_payload,
                top=_drqs_top,
            )
            if _graph_route == "graph_assisted":
                route = "graph_assisted"
                route_payload = _graph_payload
                decision_trace.append(
                    {
                        "step": "graph_assisted",
                        "top_score": round(float(_drqs_top.get("score", 0.0)), 5),
                        "node_count": _graph_payload.get("turn_context", {}).get("node_count", 0),
                        "validation": _graph_payload.get("turn_context", {}).get("validation"),
                    }
                )
            # If graph build failed/insufficient → fall through to elif symbol or selection below
        if route not in ("recall", "graph_assisted") and (symbol or selection):
            if _explicit_drill_requested(question):
                route = "drill"
                drill = build_familiarization_pack(
                    project_path=resolved_root,
                    mode="drill",
                    against_snapshot_id=against_snapshot_id,
                    query=question,
                )
                route_payload = {
                    "pack_mode": "drill",
                    "pack_confidence": drill.get("confidence", {}),
                    "evidence_cards": drill.get("evidence_cards", []),
                }
            else:
                route = "agent_handoff"
                route_payload = _build_agent_handoff_payload(
                    question=question,
                    recall_payload=recall_payload,
                    top_candidate=top,
                    skip_reason="editor_context_no_explicit_drill",
                    project_root=resolved_root,
                )
                _emit_trace_event(
                    trace_hook,
                    "resolver_agent_handoff",
                    reason="editor_context_no_explicit_drill",
                    candidate_count=int(recall_payload.get("candidate_count", 0)),
                )
                decision_trace.append(
                    {
                        "step": "agent_handoff",
                        "reason": "editor_context_no_explicit_drill",
                        "candidate_count": int(recall_payload.get("candidate_count", 0)),
                    }
                )
        elif route not in ("recall", "graph_assisted") and not allow_heavy_expansion:
            timeout_budget_seconds = _resolve_timeout_budget_seconds()
            if timeout_budget_seconds <= 10:
                route = "scout"
                scout_started_at = datetime.now(timezone.utc)
                _emit_trace_event(trace_hook, "resolver_scout_start", reason="timeout_budget_guard")
                scout = build_familiarization_pack(
                    project_path=resolved_root,
                    mode="scout",
                    against_snapshot_id=against_snapshot_id,
                    query=None,
                )
                _emit_trace_event(
                    trace_hook,
                    "resolver_scout_done",
                    reason="timeout_budget_guard",
                    elapsed_seconds=round((datetime.now(timezone.utc) - scout_started_at).total_seconds(), 6),
                    suggested_read_order_count=len(scout.get("suggested_read_order", [])),
                    confidence=scout.get("confidence", {}).get("overall"),
                )
                decision_trace.append(
                    {
                        "step": "scout_budget_guard",
                        "reason": heavy_expansion_reason,
                        "timeout_seconds": timeout_budget_seconds,
                    }
                )
                route_payload = {
                    "pack_mode": "scout",
                    "pack_confidence": scout.get("confidence", {}),
                    "suggested_read_order": scout.get("suggested_read_order", []),
                }
            else:
                route = "agent_handoff"
                route_payload = _build_agent_handoff_payload(
                    question=question,
                    recall_payload=recall_payload,
                    top_candidate=top,
                    skip_reason=heavy_expansion_reason,
                    project_root=resolved_root,
                )
                _emit_trace_event(
                    trace_hook,
                    "resolver_agent_handoff",
                    reason=heavy_expansion_reason,
                    candidate_count=int(recall_payload.get("candidate_count", 0)),
                )
                decision_trace.append(
                    {
                        "step": "agent_handoff",
                        "reason": heavy_expansion_reason,
                        "candidate_count": int(recall_payload.get("candidate_count", 0)),
                    }
                )
        elif route not in ("recall", "graph_assisted") and int(recall_payload.get("candidate_count", 0)) > 0:
            route = "scout"
            scout_started_at = datetime.now(timezone.utc)
            _emit_trace_event(trace_hook, "resolver_scout_start", reason="recall_candidates")
            scout = build_familiarization_pack(
                project_path=resolved_root,
                mode="scout",
                against_snapshot_id=against_snapshot_id,
                query=None,
            )
            _emit_trace_event(
                trace_hook,
                "resolver_scout_done",
                reason="recall_candidates",
                elapsed_seconds=round((datetime.now(timezone.utc) - scout_started_at).total_seconds(), 6),
                suggested_read_order_count=len(scout.get("suggested_read_order", [])),
                confidence=scout.get("confidence", {}).get("overall"),
            )
            route_payload = {
                "pack_mode": "scout",
                "pack_confidence": scout.get("confidence", {}),
                "suggested_read_order": scout.get("suggested_read_order", []),
            }
        elif route not in ("recall", "graph_assisted"):
            shadow = _load_shadow_metadata(resolved_root)
            decision_trace.append({"step": "shadow_check", "shadow": shadow or {"exists": False}})
            _emit_trace_event(
                trace_hook,
                "resolver_shadow_check",
                shadow_exists=bool(shadow),
                shadow_age_hours=shadow.get("age_hours") if shadow else None,
                shadow_changed_total=int(shadow.get("changed_total", 0)) if shadow else 0,
                shadow_run_id=shadow.get("run_id") if shadow else None,
            )

            shadow_recent = bool(shadow and shadow.get("age_hours") is not None and float(shadow["age_hours"]) <= 24.0)
            changed_total = int(shadow.get("changed_total", 0)) if shadow else 0
            timeout_budget_seconds = _resolve_timeout_budget_seconds()
            fresh_delta_explicit = _explicit_fresh_delta_requested(question)
            scout_reason = None
            if shadow_recent and changed_total <= 250:
                scout_reason = "shadow_recent"
            elif timeout_budget_seconds <= 10 and not fresh_delta_explicit:
                scout_reason = "timeout_budget_guard"

            if scout_reason is not None:
                route = "scout"
                scout_started_at = datetime.now(timezone.utc)
                _emit_trace_event(trace_hook, "resolver_scout_start", reason=scout_reason)
                scout = build_familiarization_pack(
                    project_path=resolved_root,
                    mode="scout",
                    against_snapshot_id=against_snapshot_id,
                    query=None,
                )
                _emit_trace_event(
                    trace_hook,
                    "resolver_scout_done",
                    reason=scout_reason,
                    elapsed_seconds=round((datetime.now(timezone.utc) - scout_started_at).total_seconds(), 6),
                    suggested_read_order_count=len(scout.get("suggested_read_order", [])),
                    confidence=scout.get("confidence", {}).get("overall"),
                )
                if scout_reason == "timeout_budget_guard":
                    decision_trace.append(
                        {
                            "step": "fresh_delta_skipped",
                            "reason": "timeout_budget_guard",
                            "timeout_seconds": timeout_budget_seconds,
                            "changed_total": changed_total,
                        }
                    )
                route_payload = {
                    "pack_mode": "scout",
                    "pack_confidence": scout.get("confidence", {}),
                    "suggested_read_order": scout.get("suggested_read_order", []),
                }
            else:
                if not allow_heavy_expansion:
                    route = "agent_handoff"
                    route_payload = _build_agent_handoff_payload(
                        question=question,
                        recall_payload=recall_payload,
                        top_candidate=top,
                        skip_reason=heavy_expansion_reason,
                        project_root=resolved_root,
                    )
                    _emit_trace_event(
                        trace_hook,
                        "resolver_agent_handoff",
                        reason=heavy_expansion_reason,
                        candidate_count=int(recall_payload.get("candidate_count", 0)),
                    )
                    decision_trace.append(
                        {
                            "step": "agent_handoff",
                            "reason": heavy_expansion_reason,
                            "candidate_count": int(recall_payload.get("candidate_count", 0)),
                        }
                    )
                elif changed_total > 1000:
                    # Cold cache + large repo: fresh_delta would exceed the
                    # MCP timeout budget.  Fall back to agent_handoff so the
                    # agent can read files directly rather than timing out.
                    route = "agent_handoff"
                    route_payload = _build_agent_handoff_payload(
                        question=question,
                        recall_payload=recall_payload,
                        top_candidate=top,
                        skip_reason="cold_cache_large_repo",
                        project_root=resolved_root,
                    )
                    _emit_trace_event(
                        trace_hook,
                        "resolver_agent_handoff",
                        reason="cold_cache_large_repo",
                        changed_total=changed_total,
                        candidate_count=int(recall_payload.get("candidate_count", 0)),
                    )
                    decision_trace.append(
                        {
                            "step": "agent_handoff",
                            "reason": "cold_cache_large_repo",
                            "changed_total": changed_total,
                            "candidate_count": int(recall_payload.get("candidate_count", 0)),
                        }
                    )
                else:
                    route = "fresh_delta"
                    route_payload = _run_fresh_delta(resolved_root, against_snapshot_id=against_snapshot_id)

    decision_trace.append({"step": "route_selected", "route": route})
    if force_true_agent_session and route != "agent_handoff":
        route_payload["forced_true_agent_session"] = True

    # Agent-facing trace is compact by default (step labels + a one-line summary)
    # to keep the resolver's token footprint minimal. The full decision tree is
    # always written to the decision log file below. Set
    # SEMANTIC_RESOLVER_VERBOSE_TRACE=1 to surface the full trace in the response
    # for live, supervised debugging.
    verbose_trace = _resolver_verbose_trace_enabled()
    compact_trace = [
        {"step": str(item.get("step", "unknown"))}
        for item in decision_trace
        if isinstance(item, dict)
    ]
    route_summary = "{route} | confidence={confidence:.2f} | steps: {steps}".format(
        route=route,
        confidence=float(classification.get("confidence", 0.0)),
        steps=" -> ".join(entry["step"] for entry in compact_trace),
    )

    response = {
        "generated_utc": _utc_now(),
        "trace_id": trace_id,
        "question": question,
        "classification": classification,
        "scope_fingerprint": scope_fingerprint,
        "context": {
            "file_path": file_path,
            "symbol": symbol,
            "selection_excerpt": (selection or "")[:160],
        },
        "route": route,
        "route_summary": route_summary,
        "decision_trace": decision_trace if verbose_trace else compact_trace,
        "route_payload": route_payload,
    }

    if recall_payload is not None:
        response["recall"] = {
            "candidate_count": recall_payload.get("candidate_count", 0),
            "match_mode": recall_payload.get("match_mode", "none"),
            "candidates": recall_payload.get("candidates", []),
        }

    if route == "agent_handoff":
        response["handoff_context"] = route_payload.get("handoff_context", {})
        memory_commit = _commit_agent_handoff_reasoning(
            resolved_root,
            question=question,
            scope_fingerprint=scope_fingerprint,
            trace_id=trace_id,
            classification=classification,
            route_payload=route_payload,
        )
        if isinstance(memory_commit, dict):
            response["memory_commit"] = _build_memory_commit_summary(memory_commit)
    elif classification["category"] == "repo_question" and force_true_agent_session:
        memory_commit = _commit_forced_agent_session_reasoning(
            resolved_root,
            question=question,
            scope_fingerprint=scope_fingerprint,
            trace_id=trace_id,
            classification=classification,
            route=route,
            route_payload=route_payload,
        )
        if isinstance(memory_commit, dict):
            response["memory_commit"] = _build_memory_commit_summary(memory_commit)

    log_payload = {
        "trace_id": trace_id,
        "generated_utc": response["generated_utc"],
        "scope_fingerprint": scope_fingerprint,
        "route": route,
        "classification": classification,
        "decision_trace": decision_trace,
    }
    response["decision_log_path"] = _append_resolver_log(resolved_root, log_payload)

    return response
