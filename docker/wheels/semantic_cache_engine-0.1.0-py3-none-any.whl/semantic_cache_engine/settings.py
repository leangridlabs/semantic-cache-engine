from __future__ import annotations

from dataclasses import dataclass
import functools
import os
from pathlib import Path


@dataclass(frozen=True)
class EngineSettings:
    operation_cache_backend: str
    sqlite_path: Path
    operation_sqlcipher_key: str | None
    turso_database_url: str | None
    turso_auth_token: str | None
    central_cache_backend: str
    central_sqlite_path: Path
    central_sqlcipher_key: str | None
    central_turso_database_url: str | None
    central_turso_auth_token: str | None
    default_playbook: str
    sync_schedule_utc: str
    live_provider: str
    provider_base_url: str
    provider_model: str
    provider_api_key: str | None
    provider_api_version: str | None
    churn_guard_enabled: bool
    churn_guard_min_hit_rate: float
    churn_guard_max_churn_rate: float
    churn_guard_min_total_chunks: int
    churn_guard_ema_alpha: float
    churn_guard_cooldown_seconds: int
    churn_guard_full_confidence_threshold: float
    churn_guard_passive_confidence_threshold: float
    churn_guard_self_edit_ratio: float
    churn_guard_self_edit_paths: tuple
    # DRQS — Directed Reasoning Query System thresholds
    drqs_near_miss_min_score: float
    drqs_near_miss_max_score: float
    drqs_graph_walk_timeout_ms: int
    drqs_min_scope_overlap: float
    drqs_min_context_nodes: int
    graph_sqlite_path: Path


def _read_local_env(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}

    values: dict[str, str] = {}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue

        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")

    return values


def _resolve_value(key: str, local_env: dict[str, str], default: str | None = None) -> str | None:
    from_os = os.getenv(key)
    if from_os is not None and from_os != "":
        return from_os

    from_file = local_env.get(key)
    if from_file is not None and from_file != "":
        return from_file

    return default


@functools.lru_cache(maxsize=8)
def load_settings(project_root: Path | None = None) -> EngineSettings:
    root = project_root or Path.cwd()
    local_env = _read_local_env(root / ".env")

    operation_backend_value = _resolve_value("SEMANTIC_CACHE_OPERATION_BACKEND", local_env)
    if not operation_backend_value:
        # Backward-compatible fallback for older env/config usage.
        operation_backend_value = _resolve_value("SEMANTIC_CACHE_DB_BACKEND", local_env, "sqlite")
    operation_backend = (operation_backend_value or "sqlite").strip().lower()
    sqlite_path_text = _resolve_value("SEMANTIC_CACHE_SQLITE_PATH", local_env, ".reason/cache/semantic_cache.sqlite")
    sqlite_path = (root / (sqlite_path_text or ".reason/cache/semantic_cache.sqlite")).resolve()
    operation_sqlcipher_key = _resolve_value("SEMANTIC_CACHE_SQLCIPHER_KEY", local_env)

    turso_database_url = _resolve_value("TURSO_DATABASE_URL", local_env)
    turso_auth_token = _resolve_value("TURSO_AUTH_TOKEN", local_env)
    central_backend = (
        _resolve_value("SEMANTIC_CACHE_CENTRAL_BACKEND", local_env, "turso")
        or "turso"
    ).strip().lower()
    central_sqlite_path_text = _resolve_value(
        "SEMANTIC_CACHE_CENTRAL_SQLITE_PATH",
        local_env,
        ".reason/cache/semantic_cache_central.sqlite",
    )
    central_sqlite_path = (root / (central_sqlite_path_text or ".reason/cache/semantic_cache_central.sqlite")).resolve()
    graph_sqlite_path_text = _resolve_value(
        "SEMANTIC_CACHE_GRAPH_SQLITE_PATH",
        local_env,
        ".reason/cache/reasoning_graph.sqlite",
    )
    graph_sqlite_path = (root / (graph_sqlite_path_text or ".reason/cache/reasoning_graph.sqlite")).resolve()
    central_sqlcipher_key = _resolve_value("SEMANTIC_CACHE_CENTRAL_SQLCIPHER_KEY", local_env, operation_sqlcipher_key)
    central_turso_database_url = _resolve_value("SEMANTIC_CACHE_CENTRAL_TURSO_DATABASE_URL", local_env, turso_database_url)
    central_turso_auth_token = _resolve_value("SEMANTIC_CACHE_CENTRAL_TURSO_AUTH_TOKEN", local_env, turso_auth_token)
    default_playbook = (
        _resolve_value("SEMANTIC_CACHE_DEFAULT_PLAYBOOK", local_env, "session-readiness")
        or "session-readiness"
    ).strip().lower()
    sync_schedule_utc = (
        _resolve_value("SEMANTIC_CACHE_SYNC_SCHEDULE_UTC", local_env, "23:00")
        or "23:00"
    ).strip()
    live_provider = (_resolve_value("SEMANTIC_CACHE_LIVE_PROVIDER", local_env, "none") or "none").strip().lower()
    provider_base_url = (
        _resolve_value("SEMANTIC_CACHE_PROVIDER_BASE_URL", local_env, "https://api.openai.com/v1")
        or "https://api.openai.com/v1"
    ).strip()
    provider_model = (
        _resolve_value("SEMANTIC_CACHE_PROVIDER_MODEL", local_env, "gpt-4o-mini")
        or "gpt-4o-mini"
    ).strip()
    # Fall back to OPENAI_API_KEY so projects that already have the standard
    # variable don't need to duplicate it as SEMANTIC_CACHE_PROVIDER_API_KEY.
    provider_api_key = (
        _resolve_value("SEMANTIC_CACHE_PROVIDER_API_KEY", local_env)
        or _resolve_value("OPENAI_API_KEY", local_env)
    )
    # When set (or when the base URL targets Azure), the provider adapter switches
    # to the Azure OpenAI request shape: `api-key` header plus the
    # `/openai/deployments/{deployment}/chat/completions?api-version=...` route.
    provider_api_version = _resolve_value("SEMANTIC_CACHE_PROVIDER_API_VERSION", local_env)

    churn_guard_enabled_raw = _resolve_value("SEMANTIC_CACHE_CHURN_GUARD_ENABLED", local_env, "true")
    churn_guard_enabled = (churn_guard_enabled_raw or "true").strip().lower() not in ("false", "0", "no", "off")
    churn_guard_min_hit_rate_raw = _resolve_value("SEMANTIC_CACHE_CHURN_GUARD_MIN_HIT_RATE", local_env, "0.3")
    try:
        churn_guard_min_hit_rate = max(0.0, min(1.0, float(churn_guard_min_hit_rate_raw or "0.3")))
    except (TypeError, ValueError):
        churn_guard_min_hit_rate = 0.3
    churn_guard_max_churn_rate_raw = _resolve_value("SEMANTIC_CACHE_CHURN_GUARD_MAX_CHURN_RATE", local_env, "0.4")
    try:
        churn_guard_max_churn_rate = max(0.0, min(1.0, float(churn_guard_max_churn_rate_raw or "0.4")))
    except (TypeError, ValueError):
        churn_guard_max_churn_rate = 0.4
    churn_guard_min_total_chunks_raw = _resolve_value("SEMANTIC_CACHE_CHURN_GUARD_MIN_TOTAL_CHUNKS", local_env, "30")
    try:
        churn_guard_min_total_chunks = max(1, int(churn_guard_min_total_chunks_raw or "30"))
    except (TypeError, ValueError):
        churn_guard_min_total_chunks = 30
    churn_guard_ema_alpha_raw = _resolve_value("SEMANTIC_CACHE_CHURN_GUARD_EMA_ALPHA", local_env, "0.3")
    try:
        churn_guard_ema_alpha = max(0.01, min(1.0, float(churn_guard_ema_alpha_raw or "0.3")))
    except (TypeError, ValueError):
        churn_guard_ema_alpha = 0.3
    churn_guard_cooldown_raw = _resolve_value("SEMANTIC_CACHE_CHURN_GUARD_COOLDOWN_SECONDS", local_env, "60")
    try:
        churn_guard_cooldown_seconds = max(0, int(churn_guard_cooldown_raw or "60"))
    except (TypeError, ValueError):
        churn_guard_cooldown_seconds = 60
    churn_guard_full_conf_raw = _resolve_value("SEMANTIC_CACHE_CHURN_GUARD_FULL_CONFIDENCE", local_env, "0.6")
    try:
        churn_guard_full_confidence_threshold = max(0.0, min(1.0, float(churn_guard_full_conf_raw or "0.6")))
    except (TypeError, ValueError):
        churn_guard_full_confidence_threshold = 0.6
    churn_guard_passive_conf_raw = _resolve_value("SEMANTIC_CACHE_CHURN_GUARD_PASSIVE_CONFIDENCE", local_env, "0.3")
    try:
        churn_guard_passive_confidence_threshold = max(0.0, min(1.0, float(churn_guard_passive_conf_raw or "0.3")))
    except (TypeError, ValueError):
        churn_guard_passive_confidence_threshold = 0.3
    churn_guard_self_edit_ratio_raw = _resolve_value("SEMANTIC_CACHE_CHURN_GUARD_SELF_EDIT_RATIO", local_env, "0.5")
    try:
        churn_guard_self_edit_ratio = max(0.0, min(1.0, float(churn_guard_self_edit_ratio_raw or "0.5")))
    except (TypeError, ValueError):
        churn_guard_self_edit_ratio = 0.5
    churn_guard_self_edit_paths_raw = _resolve_value(
        "SEMANTIC_CACHE_CHURN_GUARD_SELF_EDIT_PATHS",
        local_env,
        "src/semantic_cache_engine,src/",
    )
    churn_guard_self_edit_paths: tuple = tuple(
        p.strip()
        for p in (churn_guard_self_edit_paths_raw or "src/semantic_cache_engine,src/").split(",")
        if p.strip()
    )

    drqs_near_miss_min_score_raw = _resolve_value("SEMANTIC_DRQS_NEAR_MISS_MIN_SCORE", local_env, "0.40")
    try:
        drqs_near_miss_min_score = max(0.0, min(1.0, float(drqs_near_miss_min_score_raw or "0.40")))
    except (TypeError, ValueError):
        drqs_near_miss_min_score = 0.40
    drqs_near_miss_max_score_raw = _resolve_value("SEMANTIC_DRQS_NEAR_MISS_MAX_SCORE", local_env, "0.79")
    try:
        drqs_near_miss_max_score = max(0.0, min(1.0, float(drqs_near_miss_max_score_raw or "0.79")))
    except (TypeError, ValueError):
        drqs_near_miss_max_score = 0.79
    drqs_graph_walk_timeout_ms_raw = _resolve_value("SEMANTIC_DRQS_GRAPH_WALK_TIMEOUT_MS", local_env, "1500")
    try:
        drqs_graph_walk_timeout_ms = max(100, int(drqs_graph_walk_timeout_ms_raw or "1500"))
    except (TypeError, ValueError):
        drqs_graph_walk_timeout_ms = 1500
    drqs_min_scope_overlap_raw = _resolve_value("SEMANTIC_DRQS_MIN_SCOPE_OVERLAP", local_env, "0.10")
    try:
        drqs_min_scope_overlap = max(0.0, min(1.0, float(drqs_min_scope_overlap_raw or "0.10")))
    except (TypeError, ValueError):
        drqs_min_scope_overlap = 0.10
    drqs_min_context_nodes_raw = _resolve_value("SEMANTIC_DRQS_MIN_CONTEXT_NODES", local_env, "1")
    try:
        drqs_min_context_nodes = max(1, int(drqs_min_context_nodes_raw or "1"))
    except (TypeError, ValueError):
        drqs_min_context_nodes = 1

    return EngineSettings(
        operation_cache_backend=operation_backend,
        sqlite_path=sqlite_path,
        operation_sqlcipher_key=operation_sqlcipher_key,
        turso_database_url=turso_database_url,
        turso_auth_token=turso_auth_token,
        central_cache_backend=central_backend,
        central_sqlite_path=central_sqlite_path,
        central_sqlcipher_key=central_sqlcipher_key,
        central_turso_database_url=central_turso_database_url,
        central_turso_auth_token=central_turso_auth_token,
        default_playbook=default_playbook,
        sync_schedule_utc=sync_schedule_utc,
        live_provider=live_provider,
        provider_base_url=provider_base_url,
        provider_model=provider_model,
        provider_api_key=provider_api_key,
        provider_api_version=provider_api_version,
        churn_guard_enabled=churn_guard_enabled,
        churn_guard_min_hit_rate=churn_guard_min_hit_rate,
        churn_guard_max_churn_rate=churn_guard_max_churn_rate,
        churn_guard_min_total_chunks=churn_guard_min_total_chunks,
        churn_guard_ema_alpha=churn_guard_ema_alpha,
        churn_guard_cooldown_seconds=churn_guard_cooldown_seconds,
        churn_guard_full_confidence_threshold=churn_guard_full_confidence_threshold,
        churn_guard_passive_confidence_threshold=churn_guard_passive_confidence_threshold,
        churn_guard_self_edit_ratio=churn_guard_self_edit_ratio,
        churn_guard_self_edit_paths=churn_guard_self_edit_paths,
        drqs_near_miss_min_score=drqs_near_miss_min_score,
        drqs_near_miss_max_score=drqs_near_miss_max_score,
        drqs_graph_walk_timeout_ms=drqs_graph_walk_timeout_ms,
        drqs_min_scope_overlap=drqs_min_scope_overlap,
        drqs_min_context_nodes=drqs_min_context_nodes,
        graph_sqlite_path=graph_sqlite_path,
    )
