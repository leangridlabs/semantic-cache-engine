from __future__ import annotations

from array import array
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import sqlite3
import sys
import threading
import time
from typing import Any, Sequence

from .settings import EngineSettings, load_settings


def _resolve_sqlcipher_driver() -> Any:
    """Resolve an installed SQLCipher DB-API driver module."""
    try:
        import sqlcipher3  # type: ignore

        return sqlcipher3
    except Exception:
        try:
            from pysqlcipher3 import dbapi2 as pysqlcipher_dbapi  # type: ignore

            return pysqlcipher_dbapi
        except Exception as exc:
            raise RuntimeError(
                "SQLCipher backend requires sqlcipher3 or pysqlcipher3. "
                "Install dependencies in the bundled Python 3.11 runtime."
            ) from exc


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(frozen=True)
class CacheEntry:
    entry_id: str
    type: str
    chunk_id: str
    hash: str
    version: str
    timestamp_utc: str
    metadata: dict[str, Any]


@dataclass(frozen=True)
class CacheLookupResult:
    entry: CacheEntry | None
    hit: bool


@dataclass(frozen=True)
class VectorReference:
    chunk_id: str
    hash: str
    provider: str
    model: str
    vector_ref: str
    updated_utc: str


@dataclass(frozen=True)
class VectorEmbedding:
    chunk_id: str
    hash: str
    provider: str
    model: str
    dimension: int
    dtype: str
    values: list[float]
    updated_utc: str


class CacheBackend(ABC):
    @abstractmethod
    def ensure_schema(self) -> None:
        raise NotImplementedError

    @abstractmethod
    def upsert_cache_entry(self, entry: CacheEntry) -> None:
        raise NotImplementedError

    @abstractmethod
    def get_cache_entry(self, chunk_id: str, chunk_hash: str, entry_type: str = "embedding") -> CacheLookupResult:
        raise NotImplementedError

    @abstractmethod
    def get_cache_entries_map(
        self,
        keys: list[tuple[str, str]],
        entry_type: str = "embedding",
    ) -> dict[tuple[str, str], CacheEntry]:
        raise NotImplementedError

    @abstractmethod
    def get_entries_by_chunk_id(self, chunk_id: str) -> list[CacheEntry]:
        raise NotImplementedError

    @abstractmethod
    def list_cache_entries(self, entry_type: str | None = None) -> list[CacheEntry]:
        raise NotImplementedError

    @abstractmethod
    def upsert_vector_reference(self, reference: VectorReference) -> None:
        raise NotImplementedError

    @abstractmethod
    def get_vector_reference(
        self,
        chunk_id: str,
        chunk_hash: str,
        provider: str = "none",
        model: str = "none",
    ) -> VectorReference | None:
        raise NotImplementedError

    @abstractmethod
    def upsert_vector_embedding(self, embedding: VectorEmbedding) -> None:
        raise NotImplementedError

    @abstractmethod
    def get_vector_embedding(
        self,
        chunk_id: str,
        chunk_hash: str,
        provider: str = "local",
        model: str = "local-hash-v1",
    ) -> VectorEmbedding | None:
        raise NotImplementedError


def serialize_embedding_values(values: Sequence[float], max_dimension: int = 4096) -> tuple[bytes, int, str]:
    dimension = len(values)
    if dimension <= 0:
        raise ValueError("Embedding vector must contain at least one value")
    if dimension > max_dimension:
        raise ValueError(f"Embedding dimension {dimension} exceeds max {max_dimension}")

    packed = array("f")
    for value in values:
        scalar = float(value)
        if not math.isfinite(scalar):
            raise ValueError("Embedding values must be finite floats")
        packed.append(scalar)

    if sys.byteorder != "little":
        packed.byteswap()

    return packed.tobytes(), dimension, "float32-le"


def deserialize_embedding_values(blob: bytes, dimension: int, dtype: str) -> list[float]:
    if dtype != "float32-le":
        raise ValueError(f"Unsupported embedding dtype: {dtype}")
    if dimension <= 0:
        raise ValueError(f"Invalid embedding dimension: {dimension}")

    expected_bytes = dimension * 4
    if len(blob) != expected_bytes:
        raise ValueError(
            f"Embedding payload size mismatch: got {len(blob)} bytes, expected {expected_bytes}"
        )

    values = array("f")
    values.frombytes(blob)
    if sys.byteorder != "little":
        values.byteswap()
    return list(values)


class SQLiteCacheBackend(CacheBackend):
    _CACHE_MAP_BATCH_SIZE = 400

    def __init__(self, db_path: Path, passphrase: str | None = None, driver: Any | None = None) -> None:
        self.db_path = db_path
        self.passphrase = passphrase
        self._driver = driver
        self._schema_ready = False
        self._schema_lock = threading.Lock()

    @staticmethod
    def _safe_journal_mode(db_path: Path) -> str:
        """Use DELETE journal mode on cloud-synced paths to avoid OneDrive locking WAL files."""
        import os as _os
        path_str = str(db_path).lower()
        if "onedrive" in path_str or "dropbox" in path_str or "google drive" in path_str:
            return "DELETE"
        return "WAL"

    def _connect(self):
        import os as _os
        _db_dir = self.db_path.parent
        if not _os.path.isdir(_db_dir):
            _db_dir.mkdir(parents=True, exist_ok=True)
        journal_mode = self._safe_journal_mode(self.db_path)
        if self._driver is None:
            conn = sqlite3.connect(self.db_path, timeout=10.0)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA busy_timeout=10000")
            conn.execute(f"PRAGMA journal_mode={journal_mode}")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA cache_size=-65536")   # 64 MB page cache
            conn.execute("PRAGMA mmap_size=268435456") # 256 MB memory-mapped I/O
            conn.execute("PRAGMA temp_store=MEMORY")   # temp tables in RAM
            return conn

        conn = self._driver.connect(str(self.db_path), timeout=10.0)
        try:
            conn.row_factory = self._driver.Row
        except Exception:
            conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout=10000")
        escaped_key = (self.passphrase or "").replace("'", "''")
        conn.execute(f"PRAGMA key = '{escaped_key}'")
        conn.execute(f"PRAGMA journal_mode={journal_mode}")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA cache_size=-65536")
        conn.execute("PRAGMA mmap_size=268435456")
        conn.execute("PRAGMA temp_store=MEMORY")
        conn.execute("SELECT count(*) FROM sqlite_master").fetchone()
        return conn

    def ensure_schema(self) -> None:
        if self._schema_ready:
            return

        with self._schema_lock:
            if self._schema_ready:
                return

            with self._connect() as conn:
                conn.execute(
                    """
                    create table if not exists cache_entries (
                        entry_id text primary key,
                        type text not null,
                        chunk_id text not null,
                        hash text not null,
                        version text not null,
                        timestamp_utc text not null,
                        metadata_json text not null,
                        unique(chunk_id, hash, type)
                    )
                    """
                )
                conn.execute("create index if not exists idx_cache_entries_chunk_id on cache_entries(chunk_id)")
                conn.execute("create index if not exists idx_cache_entries_chunk_hash on cache_entries(chunk_id, hash)")
                # Composite indexes for list/summary queries and batch-lookup path.
                conn.execute(
                    "create index if not exists idx_cache_entries_type_ts "
                    "on cache_entries(type, timestamp_utc desc)"
                )
                conn.execute(
                    "create index if not exists idx_cache_entries_type_chunk_hash "
                    "on cache_entries(type, chunk_id, hash)"
                )
                conn.execute(
                    """
                    create table if not exists vector_references (
                        chunk_id text not null,
                        hash text not null,
                        provider text not null,
                        model text not null,
                        vector_ref text not null,
                        updated_utc text not null,
                        primary key (chunk_id, hash, provider, model)
                    )
                    """
                )
                conn.execute(
                    """
                    create table if not exists vector_embeddings (
                        chunk_id text not null,
                        hash text not null,
                        provider text not null,
                        model text not null,
                        dimension integer not null,
                        dtype text not null,
                        vector_blob blob not null,
                        updated_utc text not null,
                        primary key (chunk_id, hash, provider, model)
                    )
                    """
                )

            self._schema_ready = True

    def _execute_write_with_retry(
        self,
        query: str,
        params: Sequence[Any],
    ) -> None:
        # busy_timeout handles the primary wait; 2 retries cover commit-time edge cases.
        for attempt in range(2):
            try:
                with self._connect() as conn:
                    conn.execute(query, params)
                return
            except sqlite3.OperationalError as exc:
                if "locked" not in str(exc).lower() or attempt == 1:
                    raise
                time.sleep(0.1 * (attempt + 1))

    def batch_upsert_cache_entries(self, entries: list[CacheEntry]) -> None:
        """Insert or update multiple cache entries in a single transaction."""
        if not entries:
            return
        self.ensure_schema()
        params = [
            (
                e.entry_id,
                e.type,
                e.chunk_id,
                e.hash,
                e.version,
                e.timestamp_utc,
                json.dumps(e.metadata, sort_keys=True),
            )
            for e in entries
        ]
        for attempt in range(2):
            try:
                with self._connect() as conn:
                    conn.executemany(
                        """
                        insert into cache_entries(
                            entry_id, type, chunk_id, hash, version, timestamp_utc, metadata_json
                        )
                        values(?, ?, ?, ?, ?, ?, ?)
                        on conflict(chunk_id, hash, type) do update set
                            entry_id=excluded.entry_id,
                            version=excluded.version,
                            timestamp_utc=excluded.timestamp_utc,
                            metadata_json=excluded.metadata_json
                        """,
                        params,
                    )
                return
            except sqlite3.OperationalError as exc:
                if "locked" not in str(exc).lower() or attempt == 1:
                    raise
                time.sleep(0.1 * (attempt + 1))

    def upsert_cache_entry(self, entry: CacheEntry) -> None:
        self.ensure_schema()
        self._execute_write_with_retry(
            """
            insert into cache_entries(entry_id, type, chunk_id, hash, version, timestamp_utc, metadata_json)
            values(?, ?, ?, ?, ?, ?, ?)
            on conflict(chunk_id, hash, type) do update set
                entry_id=excluded.entry_id,
                version=excluded.version,
                timestamp_utc=excluded.timestamp_utc,
                metadata_json=excluded.metadata_json
            """,
            (
                entry.entry_id,
                entry.type,
                entry.chunk_id,
                entry.hash,
                entry.version,
                entry.timestamp_utc,
                json.dumps(entry.metadata, sort_keys=True),
            ),
        )

    def get_cache_entry(self, chunk_id: str, chunk_hash: str, entry_type: str = "embedding") -> CacheLookupResult:
        self.ensure_schema()
        with self._connect() as conn:
            row = conn.execute(
                """
                select entry_id, type, chunk_id, hash, version, timestamp_utc, metadata_json
                from cache_entries
                where chunk_id = ? and hash = ? and type = ?
                limit 1
                """,
                (chunk_id, chunk_hash, entry_type),
            ).fetchone()

        if row is None:
            return CacheLookupResult(entry=None, hit=False)

        entry = CacheEntry(
            entry_id=row["entry_id"],
            type=row["type"],
            chunk_id=row["chunk_id"],
            hash=row["hash"],
            version=row["version"],
            timestamp_utc=row["timestamp_utc"],
            metadata=json.loads(row["metadata_json"]),
        )
        return CacheLookupResult(entry=entry, hit=True)

    def get_entries_by_chunk_id(self, chunk_id: str) -> list[CacheEntry]:
        self.ensure_schema()
        with self._connect() as conn:
            rows = conn.execute(
                """
                select entry_id, type, chunk_id, hash, version, timestamp_utc, metadata_json
                from cache_entries
                where chunk_id = ?
                order by timestamp_utc desc
                """,
                (chunk_id,),
            ).fetchall()

        return [
            CacheEntry(
                entry_id=row["entry_id"],
                type=row["type"],
                chunk_id=row["chunk_id"],
                hash=row["hash"],
                version=row["version"],
                timestamp_utc=row["timestamp_utc"],
                metadata=json.loads(row["metadata_json"]),
            )
            for row in rows
        ]

    def list_cache_entries(self, entry_type: str | None = None) -> list[CacheEntry]:
        self.ensure_schema()
        query = (
            "select entry_id, type, chunk_id, hash, version, timestamp_utc, metadata_json "
            "from cache_entries"
        )
        params: tuple[str, ...] = ()
        if entry_type is not None:
            query += " where type = ?"
            params = (entry_type,)
        query += " order by timestamp_utc asc"

        with self._connect() as conn:
            rows = conn.execute(query, params).fetchall()

        return [
            CacheEntry(
                entry_id=row["entry_id"],
                type=row["type"],
                chunk_id=row["chunk_id"],
                hash=row["hash"],
                version=row["version"],
                timestamp_utc=row["timestamp_utc"],
                metadata=json.loads(row["metadata_json"]),
            )
            for row in rows
        ]

    def get_cache_entries_map(
        self,
        keys: list[tuple[str, str]],
        entry_type: str = "embedding",
    ) -> dict[tuple[str, str], CacheEntry]:
        if not keys:
            return {}

        self.ensure_schema()
        unique_keys = sorted(set(keys))
        result: dict[tuple[str, str], CacheEntry] = {}

        for start in range(0, len(unique_keys), self._CACHE_MAP_BATCH_SIZE):
            batch = unique_keys[start : start + self._CACHE_MAP_BATCH_SIZE]
            placeholders = ", ".join(["(?, ?)"] * len(batch))
            flat_params: list[str] = []
            for chunk_id, chunk_hash in batch:
                flat_params.extend([chunk_id, chunk_hash])

            query = (
                "select entry_id, type, chunk_id, hash, version, timestamp_utc, metadata_json "
                "from cache_entries "
                "where type = ? and (chunk_id, hash) in ("
                f"{placeholders}"
                ")"
            )

            with self._connect() as conn:
                rows = conn.execute(query, [entry_type, *flat_params]).fetchall()

            for row in rows:
                entry = CacheEntry(
                    entry_id=row["entry_id"],
                    type=row["type"],
                    chunk_id=row["chunk_id"],
                    hash=row["hash"],
                    version=row["version"],
                    timestamp_utc=row["timestamp_utc"],
                    metadata=json.loads(row["metadata_json"]),
                )
                result[(entry.chunk_id, entry.hash)] = entry

        return result

    def upsert_vector_reference(self, reference: VectorReference) -> None:
        self.ensure_schema()
        self._execute_write_with_retry(
            """
            insert into vector_references(chunk_id, hash, provider, model, vector_ref, updated_utc)
            values(?, ?, ?, ?, ?, ?)
            on conflict(chunk_id, hash, provider, model) do update set
                vector_ref=excluded.vector_ref,
                updated_utc=excluded.updated_utc
            """,
            (
                reference.chunk_id,
                reference.hash,
                reference.provider,
                reference.model,
                reference.vector_ref,
                reference.updated_utc,
            ),
        )

    def get_vector_reference(
        self,
        chunk_id: str,
        chunk_hash: str,
        provider: str = "none",
        model: str = "none",
    ) -> VectorReference | None:
        self.ensure_schema()
        with self._connect() as conn:
            row = conn.execute(
                """
                select chunk_id, hash, provider, model, vector_ref, updated_utc
                from vector_references
                where chunk_id = ? and hash = ? and provider = ? and model = ?
                limit 1
                """,
                (chunk_id, chunk_hash, provider, model),
            ).fetchone()

        if row is None:
            return None

        return VectorReference(
            chunk_id=row["chunk_id"],
            hash=row["hash"],
            provider=row["provider"],
            model=row["model"],
            vector_ref=row["vector_ref"],
            updated_utc=row["updated_utc"],
        )

    def upsert_vector_embedding(self, embedding: VectorEmbedding) -> None:
        self.ensure_schema()
        vector_blob, dimension, dtype = serialize_embedding_values(embedding.values)
        self._execute_write_with_retry(
            """
            insert into vector_embeddings(
                chunk_id, hash, provider, model, dimension, dtype, vector_blob, updated_utc
            )
            values(?, ?, ?, ?, ?, ?, ?, ?)
            on conflict(chunk_id, hash, provider, model) do update set
                dimension=excluded.dimension,
                dtype=excluded.dtype,
                vector_blob=excluded.vector_blob,
                updated_utc=excluded.updated_utc
            """,
            (
                embedding.chunk_id,
                embedding.hash,
                embedding.provider,
                embedding.model,
                dimension,
                dtype,
                vector_blob,
                embedding.updated_utc,
            ),
        )

    def get_vector_embedding(
        self,
        chunk_id: str,
        chunk_hash: str,
        provider: str = "local",
        model: str = "local-hash-v1",
    ) -> VectorEmbedding | None:
        self.ensure_schema()
        with self._connect() as conn:
            row = conn.execute(
                """
                select chunk_id, hash, provider, model, dimension, dtype, vector_blob, updated_utc
                from vector_embeddings
                where chunk_id = ? and hash = ? and provider = ? and model = ?
                limit 1
                """,
                (chunk_id, chunk_hash, provider, model),
            ).fetchone()

        if row is None:
            return None

        values = deserialize_embedding_values(row["vector_blob"], int(row["dimension"]), row["dtype"])
        return VectorEmbedding(
            chunk_id=row["chunk_id"],
            hash=row["hash"],
            provider=row["provider"],
            model=row["model"],
            dimension=int(row["dimension"]),
            dtype=row["dtype"],
            values=values,
            updated_utc=row["updated_utc"],
        )


class SQLCipherCacheBackend(SQLiteCacheBackend):
    def __init__(self, db_path: Path, passphrase: str) -> None:
        if not passphrase:
            raise ValueError("SQLCipher passphrase cannot be empty")
        super().__init__(db_path, passphrase=passphrase, driver=_resolve_sqlcipher_driver())


class TursoCacheBackend(CacheBackend):
    _CACHE_MAP_BATCH_SIZE = 300

    def __init__(self, database_url: str, auth_token: str) -> None:
        self.database_url = database_url
        self.auth_token = auth_token

    def _client(self):
        from libsql_client import create_client_sync

        return create_client_sync(url=self.database_url, auth_token=self.auth_token)

    @staticmethod
    def _metadata_to_json(metadata: dict[str, Any]) -> str:
        return json.dumps(metadata, sort_keys=True)

    @staticmethod
    def _row_to_entry(row: Any) -> CacheEntry:
        return CacheEntry(
            entry_id=row[0],
            type=row[1],
            chunk_id=row[2],
            hash=row[3],
            version=row[4],
            timestamp_utc=row[5],
            metadata=json.loads(row[6]),
        )

    def ensure_schema(self) -> None:
        with self._client() as client:
            client.execute(
                """
                create table if not exists cache_entries (
                    entry_id text primary key,
                    type text not null,
                    chunk_id text not null,
                    hash text not null,
                    version text not null,
                    timestamp_utc text not null,
                    metadata_json text not null,
                    unique(chunk_id, hash, type)
                )
                """
            )
            client.execute("create index if not exists idx_cache_entries_chunk_id on cache_entries(chunk_id)")
            client.execute("create index if not exists idx_cache_entries_chunk_hash on cache_entries(chunk_id, hash)")
            client.execute(
                """
                create table if not exists vector_references (
                    chunk_id text not null,
                    hash text not null,
                    provider text not null,
                    model text not null,
                    vector_ref text not null,
                    updated_utc text not null,
                    primary key (chunk_id, hash, provider, model)
                )
                """
            )
            client.execute(
                """
                create table if not exists vector_embeddings (
                    chunk_id text not null,
                    hash text not null,
                    provider text not null,
                    model text not null,
                    dimension integer not null,
                    dtype text not null,
                    vector_blob blob not null,
                    updated_utc text not null,
                    primary key (chunk_id, hash, provider, model)
                )
                """
            )

    def upsert_cache_entry(self, entry: CacheEntry) -> None:
        self.ensure_schema()
        with self._client() as client:
            client.execute(
                """
                insert into cache_entries(entry_id, type, chunk_id, hash, version, timestamp_utc, metadata_json)
                values(?, ?, ?, ?, ?, ?, ?)
                on conflict(chunk_id, hash, type) do update set
                    entry_id=excluded.entry_id,
                    version=excluded.version,
                    timestamp_utc=excluded.timestamp_utc,
                    metadata_json=excluded.metadata_json
                """,
                [
                    entry.entry_id,
                    entry.type,
                    entry.chunk_id,
                    entry.hash,
                    entry.version,
                    entry.timestamp_utc,
                    self._metadata_to_json(entry.metadata),
                ],
            )

    def get_cache_entry(self, chunk_id: str, chunk_hash: str, entry_type: str = "embedding") -> CacheLookupResult:
        self.ensure_schema()
        with self._client() as client:
            result = client.execute(
                """
                select entry_id, type, chunk_id, hash, version, timestamp_utc, metadata_json
                from cache_entries
                where chunk_id = ? and hash = ? and type = ?
                limit 1
                """,
                [chunk_id, chunk_hash, entry_type],
            )

        if not result.rows:
            return CacheLookupResult(entry=None, hit=False)

        return CacheLookupResult(entry=self._row_to_entry(result.rows[0]), hit=True)

    def get_entries_by_chunk_id(self, chunk_id: str) -> list[CacheEntry]:
        self.ensure_schema()
        with self._client() as client:
            result = client.execute(
                """
                select entry_id, type, chunk_id, hash, version, timestamp_utc, metadata_json
                from cache_entries
                where chunk_id = ?
                order by timestamp_utc desc
                """,
                [chunk_id],
            )

        return [self._row_to_entry(row) for row in result.rows]

    def list_cache_entries(self, entry_type: str | None = None) -> list[CacheEntry]:
        self.ensure_schema()
        if entry_type is None:
            query = (
                "select entry_id, type, chunk_id, hash, version, timestamp_utc, metadata_json "
                "from cache_entries order by timestamp_utc asc"
            )
            params: list[str] = []
        else:
            query = (
                "select entry_id, type, chunk_id, hash, version, timestamp_utc, metadata_json "
                "from cache_entries where type = ? order by timestamp_utc asc"
            )
            params = [entry_type]

        with self._client() as client:
            result = client.execute(query, params)

        return [self._row_to_entry(row) for row in result.rows]

    def get_cache_entries_map(
        self,
        keys: list[tuple[str, str]],
        entry_type: str = "embedding",
    ) -> dict[tuple[str, str], CacheEntry]:
        if not keys:
            return {}

        self.ensure_schema()
        unique_keys = sorted(set(keys))
        entries: dict[tuple[str, str], CacheEntry] = {}

        try:
            for start in range(0, len(unique_keys), self._CACHE_MAP_BATCH_SIZE):
                batch = unique_keys[start : start + self._CACHE_MAP_BATCH_SIZE]
                clauses = " or ".join(["(chunk_id = ? and hash = ?)"] * len(batch))
                params: list[str] = [entry_type]
                for chunk_id, chunk_hash in batch:
                    params.extend([chunk_id, chunk_hash])

                query = (
                    "select entry_id, type, chunk_id, hash, version, timestamp_utc, metadata_json "
                    "from cache_entries "
                    "where type = ? and ("
                    f"{clauses}"
                    ")"
                )

                with self._client() as client:
                    result = client.execute(query, params)

                for row in result.rows:
                    entry = self._row_to_entry(row)
                    entries[(entry.chunk_id, entry.hash)] = entry

            return entries
        except Exception:
            # Fallback path for backends that reject dynamic batched query shapes.
            fallback: dict[tuple[str, str], CacheEntry] = {}
            for chunk_id, chunk_hash in unique_keys:
                lookup = self.get_cache_entry(chunk_id, chunk_hash, entry_type=entry_type)
                if lookup.hit and lookup.entry is not None:
                    fallback[(chunk_id, chunk_hash)] = lookup.entry
            return fallback

    def upsert_vector_reference(self, reference: VectorReference) -> None:
        self.ensure_schema()
        with self._client() as client:
            client.execute(
                """
                insert into vector_references(chunk_id, hash, provider, model, vector_ref, updated_utc)
                values(?, ?, ?, ?, ?, ?)
                on conflict(chunk_id, hash, provider, model) do update set
                    vector_ref=excluded.vector_ref,
                    updated_utc=excluded.updated_utc
                """,
                [
                    reference.chunk_id,
                    reference.hash,
                    reference.provider,
                    reference.model,
                    reference.vector_ref,
                    reference.updated_utc,
                ],
            )

    def get_vector_reference(
        self,
        chunk_id: str,
        chunk_hash: str,
        provider: str = "none",
        model: str = "none",
    ) -> VectorReference | None:
        self.ensure_schema()
        with self._client() as client:
            result = client.execute(
                """
                select chunk_id, hash, provider, model, vector_ref, updated_utc
                from vector_references
                where chunk_id = ? and hash = ? and provider = ? and model = ?
                limit 1
                """,
                [chunk_id, chunk_hash, provider, model],
            )

        if not result.rows:
            return None

        row = result.rows[0]
        return VectorReference(
            chunk_id=row[0],
            hash=row[1],
            provider=row[2],
            model=row[3],
            vector_ref=row[4],
            updated_utc=row[5],
        )

    def upsert_vector_embedding(self, embedding: VectorEmbedding) -> None:
        self.ensure_schema()
        vector_blob, dimension, dtype = serialize_embedding_values(embedding.values)
        with self._client() as client:
            client.execute(
                """
                insert into vector_embeddings(
                    chunk_id, hash, provider, model, dimension, dtype, vector_blob, updated_utc
                )
                values(?, ?, ?, ?, ?, ?, ?, ?)
                on conflict(chunk_id, hash, provider, model) do update set
                    dimension=excluded.dimension,
                    dtype=excluded.dtype,
                    vector_blob=excluded.vector_blob,
                    updated_utc=excluded.updated_utc
                """,
                [
                    embedding.chunk_id,
                    embedding.hash,
                    embedding.provider,
                    embedding.model,
                    dimension,
                    dtype,
                    vector_blob,
                    embedding.updated_utc,
                ],
            )

    def get_vector_embedding(
        self,
        chunk_id: str,
        chunk_hash: str,
        provider: str = "local",
        model: str = "local-hash-v1",
    ) -> VectorEmbedding | None:
        self.ensure_schema()
        with self._client() as client:
            result = client.execute(
                """
                select chunk_id, hash, provider, model, dimension, dtype, vector_blob, updated_utc
                from vector_embeddings
                where chunk_id = ? and hash = ? and provider = ? and model = ?
                limit 1
                """,
                [chunk_id, chunk_hash, provider, model],
            )

        if not result.rows:
            return None

        row = result.rows[0]
        blob_raw = row[6]
        if isinstance(blob_raw, memoryview):
            blob_bytes = blob_raw.tobytes()
        elif isinstance(blob_raw, bytes):
            blob_bytes = blob_raw
        else:
            blob_bytes = bytes(blob_raw)

        dimension = int(row[4])
        dtype = str(row[5])
        values = deserialize_embedding_values(blob_bytes, dimension, dtype)
        return VectorEmbedding(
            chunk_id=row[0],
            hash=row[1],
            provider=row[2],
            model=row[3],
            dimension=dimension,
            dtype=dtype,
            values=values,
            updated_utc=row[7],
        )


def create_cache_backend(settings: EngineSettings | None = None) -> CacheBackend:
    resolved = settings or load_settings()
    backend = resolved.operation_cache_backend

    if backend == "turso":
        if not resolved.turso_database_url or not resolved.turso_auth_token:
            raise ValueError("Turso backend requires TURSO_DATABASE_URL and TURSO_AUTH_TOKEN")
        return TursoCacheBackend(
            database_url=resolved.turso_database_url,
            auth_token=resolved.turso_auth_token,
        )

    if backend == "sqlcipher":
        if not resolved.operation_sqlcipher_key:
            raise ValueError("SQLCipher backend requires SEMANTIC_CACHE_SQLCIPHER_KEY")
        return SQLCipherCacheBackend(
            db_path=resolved.sqlite_path,
            passphrase=resolved.operation_sqlcipher_key,
        )

    # Default and fallback backend for deterministic local tests.
    return SQLiteCacheBackend(resolved.sqlite_path)


def create_operation_cache_backend(settings: EngineSettings | None = None) -> CacheBackend:
    return create_cache_backend(settings)


def create_central_cache_backend(settings: EngineSettings | None = None) -> CacheBackend:
    resolved = settings or load_settings()
    backend = resolved.central_cache_backend

    if backend == "turso":
        if not resolved.central_turso_database_url or not resolved.central_turso_auth_token:
            raise ValueError(
                "Central Turso backend requires SEMANTIC_CACHE_CENTRAL_TURSO_DATABASE_URL "
                "and SEMANTIC_CACHE_CENTRAL_TURSO_AUTH_TOKEN"
            )
        return TursoCacheBackend(
            database_url=resolved.central_turso_database_url,
            auth_token=resolved.central_turso_auth_token,
        )

    if backend == "sqlcipher":
        if not resolved.central_sqlcipher_key:
            raise ValueError("Central SQLCipher backend requires SEMANTIC_CACHE_CENTRAL_SQLCIPHER_KEY")
        return SQLCipherCacheBackend(
            db_path=resolved.central_sqlite_path,
            passphrase=resolved.central_sqlcipher_key,
        )

    return SQLiteCacheBackend(resolved.central_sqlite_path)


def build_cache_entry(
    chunk_id: str,
    chunk_hash: str,
    entry_type: str,
    version: str,
    metadata: dict[str, Any],
) -> CacheEntry:
    return CacheEntry(
        entry_id=f"{entry_type}:{chunk_id}:{chunk_hash}",
        type=entry_type,
        chunk_id=chunk_id,
        hash=chunk_hash,
        version=version,
        timestamp_utc=_utc_now(),
        metadata=metadata,
    )


def build_vector_reference(
    chunk_id: str,
    chunk_hash: str,
    provider: str = "none",
    model: str = "none",
    vector_ref: str = "pending",
) -> VectorReference:
    return VectorReference(
        chunk_id=chunk_id,
        hash=chunk_hash,
        provider=provider,
        model=model,
        vector_ref=vector_ref,
        updated_utc=_utc_now(),
    )


def build_vector_embedding(
    chunk_id: str,
    chunk_hash: str,
    values: Sequence[float],
    provider: str = "local",
    model: str = "local-hash-v1",
    dtype: str = "float32-le",
) -> VectorEmbedding:
    return VectorEmbedding(
        chunk_id=chunk_id,
        hash=chunk_hash,
        provider=provider,
        model=model,
        dimension=len(values),
        dtype=dtype,
        values=[float(value) for value in values],
        updated_utc=_utc_now(),
    )
