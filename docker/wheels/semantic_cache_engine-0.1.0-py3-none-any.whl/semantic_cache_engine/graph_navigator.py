"""
graph_navigator.py
==================
Graph traversal for the DRQS reasoning graph.

``GraphNavigator`` walks the reasoning graph stored in ``GraphStore`` to
produce a ``GraphNeighborhood`` — the set of cards, chunks, artifacts, and
edges reachable within N hops from a starting card or chunk.

This is the core retrieval primitive used by the resolver's near-miss path.

Public API
----------
``GraphNavigator(graph_store)``
    Create a navigator bound to a GraphStore.

``GraphNavigator.expand(card_id, hops=1) -> GraphNeighborhood``
    Expand the graph neighbourhood from a card.

``GraphNavigator.expand_chunk(chunk_id, hops=1) -> GraphNeighborhood``
    Expand the graph neighbourhood from a chunk.

``GraphNeighborhood``
    Dataclass: cards, chunks, artifacts, edges, root_card_id, root_chunk_id.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .graph_store import GraphStore


@dataclass
class GraphNeighborhood:
    """The set of nodes and edges reachable within N hops from a root node."""
    root_card_id: str | None = None
    root_chunk_id: str | None = None
    cards: list[dict[str, Any]] = field(default_factory=list)
    chunks: list[dict[str, Any]] = field(default_factory=list)
    artifacts: list[dict[str, Any]] = field(default_factory=list)
    edges: list[dict[str, Any]] = field(default_factory=list)

    @property
    def node_count(self) -> int:
        return len(self.cards) + len(self.chunks)

    @property
    def card_ids(self) -> set[str]:
        return {c["card_id"] for c in self.cards if "card_id" in c}

    @property
    def chunk_ids(self) -> set[str]:
        return {c["chunk_id"] for c in self.chunks if "chunk_id" in c}

    def is_empty(self) -> bool:
        return self.node_count == 0


class GraphNavigator:
    """Walks the reasoning graph to produce a GraphNeighborhood.

    All traversal is cheap: indexed SQL lookups with no full table scans.
    Never raises — if the graph store is unavailable returns an empty
    neighbourhood so callers degrade gracefully.
    """

    def __init__(self, graph_store: GraphStore) -> None:
        self._gs = graph_store

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def expand(self, card_id: str, hops: int = 1) -> GraphNeighborhood:
        """Expand neighbourhood from a card_id.

        Collects:
        - The card itself
        - card→card edges (shared_scope, shared_dependency, supersession, semantic_neighbor)
        - card→chunk edges (evidence, context, dependency)
        - Artifacts for each referenced chunk
        - chunk→chunk edges for each referenced chunk (1 level)
        """
        neighborhood = GraphNeighborhood(root_card_id=card_id)
        visited_cards: set[str] = set()
        visited_chunks: set[str] = set()

        try:
            self._expand_card(card_id, hops, neighborhood, visited_cards, visited_chunks)
        except Exception:
            pass  # degrade gracefully

        return neighborhood

    def expand_chunk(self, chunk_id: str, hops: int = 1) -> GraphNeighborhood:
        """Expand neighbourhood from a chunk_id.

        Collects:
        - The chunk itself + its artifact
        - Cards referencing this chunk
        - chunk→chunk edges (imports/calls)
        """
        neighborhood = GraphNeighborhood(root_chunk_id=chunk_id)
        visited_cards: set[str] = set()
        visited_chunks: set[str] = set()

        try:
            self._expand_chunk(chunk_id, hops, neighborhood, visited_cards, visited_chunks)
        except Exception:
            pass

        return neighborhood

    def expand_multi(self, card_ids: list[str], hops: int = 1) -> GraphNeighborhood:
        """Merge neighbourhoods from multiple cards (used in near-miss stitching)."""
        merged = GraphNeighborhood()
        seen_card_ids: set[str] = set()
        seen_chunk_ids: set[str] = set()
        seen_artifact_ids: set[str] = set()
        seen_edge_keys: set[tuple] = set()

        for card_id in card_ids:
            n = self.expand(card_id, hops=hops)
            if merged.root_card_id is None:
                merged.root_card_id = card_id
            for card in n.cards:
                cid = card.get("card_id", "")
                if cid and cid not in seen_card_ids:
                    seen_card_ids.add(cid)
                    merged.cards.append(card)
            for chunk in n.chunks:
                cid = chunk.get("chunk_id", "")
                if cid and cid not in seen_chunk_ids:
                    seen_chunk_ids.add(cid)
                    merged.chunks.append(chunk)
            for artifact in n.artifacts:
                aid = artifact.get("artifact_id", "")
                if aid and aid not in seen_artifact_ids:
                    seen_artifact_ids.add(aid)
                    merged.artifacts.append(artifact)
            for edge in n.edges:
                key = (
                    edge.get("from_card_id", edge.get("from_chunk_id", "")),
                    edge.get("to_card_id", edge.get("to_chunk_id", "")),
                    edge.get("edge_type", ""),
                )
                if key not in seen_edge_keys:
                    seen_edge_keys.add(key)
                    merged.edges.append(edge)

        return merged

    # ------------------------------------------------------------------
    # Internal traversal
    # ------------------------------------------------------------------

    def _expand_card(
        self,
        card_id: str,
        remaining_hops: int,
        neighborhood: GraphNeighborhood,
        visited_cards: set[str],
        visited_chunks: set[str],
    ) -> None:
        if card_id in visited_cards:
            return
        visited_cards.add(card_id)

        card = self._gs.get_card(card_id)
        if card:
            neighborhood.cards.append(card)

        if remaining_hops <= 0:
            return

        # card → card edges
        for edge in self._gs.get_card_card_edges(card_id):
            neighborhood.edges.append({**edge, "_table": "card_card_edges"})
            neighbor_id = (
                edge["to_card_id"]
                if edge.get("from_card_id") == card_id
                else edge.get("from_card_id", "")
            )
            if neighbor_id and neighbor_id not in visited_cards:
                self._expand_card(
                    neighbor_id, remaining_hops - 1, neighborhood, visited_cards, visited_chunks
                )

        # card → chunk edges
        for edge in self._gs.get_card_chunk_edges(card_id):
            neighborhood.edges.append({**edge, "_table": "card_chunk_edges"})
            chunk_id = edge.get("to_chunk_id", "")
            if chunk_id and chunk_id not in visited_chunks:
                self._expand_chunk(
                    chunk_id, 0, neighborhood, visited_cards, visited_chunks
                )

    def _expand_chunk(
        self,
        chunk_id: str,
        remaining_hops: int,
        neighborhood: GraphNeighborhood,
        visited_cards: set[str],
        visited_chunks: set[str],
    ) -> None:
        if chunk_id in visited_chunks:
            return
        visited_chunks.add(chunk_id)

        chunk = self._gs.get_chunk(chunk_id)
        if chunk:
            neighborhood.chunks.append(chunk)

        # artifact for this chunk
        artifact = self._gs.get_artifact_for_chunk(chunk_id)
        if artifact:
            neighborhood.artifacts.append(artifact)

        if remaining_hops <= 0:
            return

        # chunk → chunk edges
        for edge in self._gs.get_chunk_chunk_edges(chunk_id):
            neighborhood.edges.append({**edge, "_table": "chunk_chunk_edges"})
            neighbor_id = (
                edge["to_chunk_id"]
                if edge.get("from_chunk_id") == chunk_id
                else edge.get("from_chunk_id", "")
            )
            if neighbor_id and neighbor_id not in visited_chunks:
                self._expand_chunk(
                    neighbor_id, remaining_hops - 1, neighborhood, visited_cards, visited_chunks
                )
