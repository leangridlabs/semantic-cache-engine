"""
gap_detector.py
===============
Detects reasoning gaps in a ``GraphNeighborhood``.

``GapDetector`` inspects a neighbourhood for structural weaknesses — missing
artifacts, missing lineage, stale fingerprints, absent dependency cards, and
cards with no chunk anchors.  Each ``Gap`` carries the gap type, the target
node ID, and a short reason string suitable for being included in handoff
context or DQA prompts.

Gap types
---------
``missing_artifact``     A chunk has no artifact (no dependency metadata seeded).
``missing_card``         A scope_fingerprint referenced in edges has no card.
``stale_fingerprint``    A card's dependency_fingerprint is empty.
``missing_lineage``      A card references a superseded card that is absent.
``missing_dependency``   A chunk referenced via a card→chunk edge has no chunk node.
``no_chunk_anchor``      A card has no outgoing card→chunk evidence edges.

Public API
----------
``GapDetector(graph_store)``
``GapDetector.find_gaps(neighborhood) -> list[Gap]``
    Inspect a neighbourhood and return all detected gaps.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .graph_store import GraphStore
from .graph_navigator import GraphNeighborhood


@dataclass
class Gap:
    gap_type: str
    target_id: str
    reason: str
    metadata: dict[str, Any] = field(default_factory=dict)


class GapDetector:
    """Detects structural gaps in a GraphNeighborhood.

    All checks are O(N) in-memory over the neighbourhood; no extra DB queries
    beyond what GraphNavigator already fetched.  Never raises.
    """

    def __init__(self, graph_store: GraphStore) -> None:
        self._gs = graph_store

    def find_gaps(self, neighborhood: GraphNeighborhood) -> list[Gap]:
        """Inspect the neighbourhood and return all detected gaps."""
        gaps: list[Gap] = []

        try:
            gaps.extend(self._check_missing_artifacts(neighborhood))
            gaps.extend(self._check_stale_fingerprints(neighborhood))
            gaps.extend(self._check_missing_lineage(neighborhood))
            gaps.extend(self._check_missing_dependency_chunks(neighborhood))
            gaps.extend(self._check_no_chunk_anchor(neighborhood))
            gaps.extend(self._check_missing_card_nodes(neighborhood))
        except Exception:
            pass  # degrade gracefully — return whatever gaps we collected so far

        return gaps

    # ------------------------------------------------------------------
    # Individual gap checks
    # ------------------------------------------------------------------

    def _check_missing_artifacts(self, n: GraphNeighborhood) -> list[Gap]:
        """Chunks that have no artifact (scout-seeded stubs with no depends_on)."""
        artifact_chunk_ids = {a.get("chunk_id", "") for a in n.artifacts}
        gaps = []
        for chunk in n.chunks:
            cid = chunk.get("chunk_id", "")
            if cid and cid not in artifact_chunk_ids:
                gaps.append(Gap(
                    gap_type="missing_artifact",
                    target_id=cid,
                    reason=f"Chunk {cid[:20]} has no artifact record (dependency metadata absent).",
                    metadata={"chunk": chunk},
                ))
        return gaps

    def _check_stale_fingerprints(self, n: GraphNeighborhood) -> list[Gap]:
        """Cards with an empty dependency_fingerprint."""
        gaps = []
        for card in n.cards:
            dep = str(card.get("dependency_fingerprint", "")).strip()
            if not dep:
                cid = card.get("card_id", "")
                gaps.append(Gap(
                    gap_type="stale_fingerprint",
                    target_id=cid,
                    reason=f"Card {cid[:20]} has no dependency_fingerprint (possibly migrated v1 card).",
                    metadata={"scope_fingerprint": card.get("scope_fingerprint", "")},
                ))
        return gaps

    def _check_missing_lineage(self, n: GraphNeighborhood) -> list[Gap]:
        """Cards whose superseded card is referenced in edges but absent from the neighbourhood."""
        present_card_ids = n.card_ids
        gaps = []
        for edge in n.edges:
            if edge.get("edge_type") != "supersession":
                continue
            target = edge.get("to_card_id", "")
            if target and target not in present_card_ids:
                gaps.append(Gap(
                    gap_type="missing_lineage",
                    target_id=target,
                    reason=(
                        f"Superseded card {target[:20]} is referenced in an edge "
                        "but was not found in the graph."
                    ),
                    metadata={"edge": edge},
                ))
        return gaps

    def _check_missing_dependency_chunks(self, n: GraphNeighborhood) -> list[Gap]:
        """card→chunk edges that point to a chunk absent from the neighbourhood chunks list."""
        present_chunk_ids = n.chunk_ids
        gaps = []
        for edge in n.edges:
            if edge.get("_table") != "card_chunk_edges":
                continue
            chunk_id = edge.get("to_chunk_id", "")
            if chunk_id and chunk_id not in present_chunk_ids:
                gaps.append(Gap(
                    gap_type="missing_dependency",
                    target_id=chunk_id,
                    reason=(
                        f"card→chunk edge points to chunk {chunk_id[:20]} "
                        "which is absent from the graph."
                    ),
                    metadata={"edge": edge},
                ))
        return gaps

    def _check_no_chunk_anchor(self, n: GraphNeighborhood) -> list[Gap]:
        """Cards that have no outgoing card→chunk evidence edges at all."""
        cards_with_chunk_edges: set[str] = set()
        for edge in n.edges:
            if edge.get("_table") == "card_chunk_edges":
                cid = edge.get("from_card_id", "")
                if cid:
                    cards_with_chunk_edges.add(cid)
        gaps = []
        for card in n.cards:
            cid = card.get("card_id", "")
            if cid and cid not in cards_with_chunk_edges:
                gaps.append(Gap(
                    gap_type="no_chunk_anchor",
                    target_id=cid,
                    reason=(
                        f"Card {cid[:20]} has no chunk anchor edges "
                        "(reasoning not tied to any code location)."
                    ),
                    metadata={"scope_fingerprint": card.get("scope_fingerprint", "")},
                ))
        return gaps

    def _check_missing_card_nodes(self, n: GraphNeighborhood) -> list[Gap]:
        """Scope fingerprints referenced in card→card edges that have no card node."""
        present_card_ids = n.card_ids
        gaps = []
        for edge in n.edges:
            if edge.get("_table") != "card_card_edges":
                continue
            for key in ("from_card_id", "to_card_id"):
                referenced = edge.get(key, "")
                if referenced and referenced not in present_card_ids:
                    # Check DB to see if it exists globally (not just in neighbourhood)
                    db_card = self._gs.get_card(referenced)
                    if not db_card:
                        gaps.append(Gap(
                            gap_type="missing_card",
                            target_id=referenced,
                            reason=(
                                f"Card {referenced[:20]} is referenced in an edge "
                                "but does not exist in the graph store."
                            ),
                            metadata={"edge": edge},
                        ))
        return gaps
