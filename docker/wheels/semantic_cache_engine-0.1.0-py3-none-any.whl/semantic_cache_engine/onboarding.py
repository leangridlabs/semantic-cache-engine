from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Any

from .playbooks import load_playbook


def build_onboarding_manifest(project_root: Path) -> dict[str, Any]:
    profile = load_playbook("integration-ready")
    root = project_root.resolve()

    return {
        "project_root": str(root),
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "repo_onboarding_profile": profile.to_dict(),
        "recommended_env": _recommended_env_lines(profile),
        "setup_steps": [
            "Copy .env.integration.example to .env if you want a local working config.",
            "Run ingest or delta with the integration-ready playbook to establish a baseline.",
            "Use sync to publish approved local reasoning artifacts to central storage.",
        ],
        "scoped_rollout": {
            "folder_based": profile.include_patterns,
            "policy_based": profile.exclude_patterns,
        },
        "generated_paths": [
            ".env.integration.example",
            "config.integration.example.json",
            "data/onboarding/integration-ready.json",
        ],
    }


def write_onboarding_artifacts(project_root: Path, force: bool = False) -> list[Path]:
    root = project_root.resolve()
    manifest = build_onboarding_manifest(root)
    profile = load_playbook("integration-ready")

    output_paths: list[Path] = []

    env_path = root / ".env.integration.example"
    config_path = root / "config.integration.example.json"
    onboarding_dir = root / "data" / "onboarding"
    onboarding_path = onboarding_dir / "integration-ready.json"

    _write_text_file(env_path, _recommended_env_text(profile), force=force)
    output_paths.append(env_path)

    _write_text_file(config_path, json.dumps(manifest, indent=2), force=force)
    output_paths.append(config_path)

    onboarding_dir.mkdir(parents=True, exist_ok=True)
    _write_text_file(onboarding_path, json.dumps(manifest, indent=2), force=force)
    output_paths.append(onboarding_path)

    for relative in [".reason/cache", ".reason/baselines", ".reason/deltas", ".reason/runs"]:
        (root / relative).mkdir(parents=True, exist_ok=True)

    return output_paths


def onboarding_manifest_to_json(project_root: Path) -> str:
    return json.dumps(build_onboarding_manifest(project_root), indent=2)


def _recommended_env_lines(profile) -> list[str]:
    return [
        "SEMANTIC_CACHE_OPERATION_BACKEND=sqlite",
        "SEMANTIC_CACHE_SQLITE_PATH=.reason/cache/semantic_cache.sqlite",
        "SEMANTIC_CACHE_CENTRAL_BACKEND=turso",
        "SEMANTIC_CACHE_CENTRAL_SQLITE_PATH=.reason/cache/semantic_cache_central.sqlite",
        f"SEMANTIC_CACHE_DEFAULT_PLAYBOOK={profile.name}",
        "SEMANTIC_CACHE_SYNC_SCHEDULE_UTC=23:00",
        "SEMANTIC_CACHE_LIVE_PROVIDER=none",
        "# Optional provider settings:",
        "# SEMANTIC_CACHE_PROVIDER_BASE_URL=https://api.openai.com/v1",
        "# SEMANTIC_CACHE_PROVIDER_MODEL=gpt-4o-mini",
        "# SEMANTIC_CACHE_PROVIDER_API_KEY=",
    ]


def _recommended_env_text(profile) -> str:
    return "\n".join(_recommended_env_lines(profile)) + "\n"


def _write_text_file(path: Path, content: str, force: bool = False) -> None:
    if path.exists() and not force:
        return

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")