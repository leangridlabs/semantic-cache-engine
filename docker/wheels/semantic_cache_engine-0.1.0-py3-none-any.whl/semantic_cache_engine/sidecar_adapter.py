from __future__ import annotations

from typing import Any, Protocol

from .sidecar_contract import (
    SIDECAR_CONTRACT_VERSION,
    SIDECAR_HANDSHAKE_SCHEMA,
    build_resolve_response,
)


class SidecarAdapter(Protocol):
    def handshake(
        self,
        *,
        client_name: str,
        client_version: str,
        requested_capabilities: list[str] | None = None,
    ) -> dict[str, Any]:
        ...

    def resolve(
        self,
        *,
        trace_id: str,
        question: str,
        workspace_root: str,
        editor_context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        ...


class MockSidecarAdapter:
    """Deterministic adapter used for contract and shell integration tests."""

    def __init__(
        self,
        *,
        sidecar_version: str = "mock-sidecar/0.1.0",
        supported_capabilities: tuple[str, ...] = ("resolve_question",),
    ) -> None:
        self.sidecar_version = sidecar_version
        self.supported_capabilities = list(supported_capabilities)

    def handshake(
        self,
        *,
        client_name: str,
        client_version: str,
        requested_capabilities: list[str] | None = None,
    ) -> dict[str, Any]:
        requested = requested_capabilities or ["resolve_question"]
        accepted = [cap for cap in requested if cap in self.supported_capabilities]

        return {
            "contract_version": SIDECAR_CONTRACT_VERSION,
            "schema": SIDECAR_HANDSHAKE_SCHEMA,
            "status": "ok",
            "client": {"name": client_name, "version": client_version},
            "sidecar_version": self.sidecar_version,
            "accepted_capabilities": accepted,
        }

    def resolve(
        self,
        *,
        trace_id: str,
        question: str,
        workspace_root: str,
        editor_context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        _ = workspace_root
        context = editor_context or {}

        lowered = question.lower()
        if "scout" in lowered:
            route = "scout"
            confidence = 0.88
        elif context:
            route = "drill"
            confidence = 0.81
        else:
            route = "recall"
            confidence = 0.76

        return build_resolve_response(
            trace_id=trace_id,
            route=route,
            confidence=confidence,
            decision_trace=[
                {"step": "classify", "route": route},
                {"step": "score", "confidence": confidence},
            ],
            route_payload={
                "mock": True,
                "has_editor_context": bool(context),
            },
        )
