from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
from pathlib import Path

from .cache import create_cache_backend
from .delta import _classify
from .ingest import ingest_project
from .reasoning import ReasoningArtifact
from .snapshot import build_snapshot_manifest, latest_snapshot_id, load_snapshot_manifest


@dataclass(frozen=True)
class StartupBootstrapBundle:
    run_id: str
    baseline_snapshot_id: str
    current_snapshot_id: str
    created_utc: str
    cache_retrieval_metrics: dict[str, float | int]
    architecture_context: list[str]
    dependency_context: list[str]
    implementation_steps: list[str]

    def to_dict(self) -> dict:
        return asdict(self)


def _now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _run_id() -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"bootstrap-{stamp}"


def build_startup_bundle(project_path: Path, against_snapshot_id: str | None = None) -> StartupBootstrapBundle:
    baseline_id = against_snapshot_id or latest_snapshot_id()
    baseline = load_snapshot_manifest(baseline_id)

    current_ingest = ingest_project(project_path.resolve())
    current_snapshot = build_snapshot_manifest(current_ingest, baseline_snapshot_id=baseline_id)
    status_counts, _ = _classify(baseline, current_snapshot)

    unchanged_key_set = {
        key
        for key, previous_hash in baseline.chunk_key_index.items()
        if current_snapshot.chunk_key_index.get(key) == previous_hash
    }

    backend = create_cache_backend()
    backend.ensure_schema()

    retrieved_artifacts: list[ReasoningArtifact] = []
    for record in current_snapshot.chunks:
        key = f"{record.path}::{record.anchor}"
        if key not in unchanged_key_set:
            continue

        lookup = backend.get_cache_entry(record.chunk_id, record.hash, entry_type="reasoning")
        if not lookup.hit or lookup.entry is None:
            continue

        artifact_payload = lookup.entry.metadata.get("artifact")
        if isinstance(artifact_payload, dict):
            retrieved_artifacts.append(ReasoningArtifact.from_dict(artifact_payload))

    architecture_context = _unique_in_order(
        insight
        for artifact in retrieved_artifacts
        for insight in artifact.architectural_insights
    )
    dependency_context = _unique_in_order(
        note
        for artifact in retrieved_artifacts
        for note in artifact.dependency_notes
    )

    requested_chunks = len(unchanged_key_set)
    retrieved_count = len(retrieved_artifacts)
    missing_count = max(requested_chunks - retrieved_count, 0)
    hit_ratio = (retrieved_count / requested_chunks) if requested_chunks else 0.0

    implementation_steps = _build_implementation_steps(
        changed_count=status_counts.MODIFIED + status_counts.NEW + status_counts.DELETED,
        missing_count=missing_count,
        retrieved_count=retrieved_count,
    )

    return StartupBootstrapBundle(
        run_id=_run_id(),
        baseline_snapshot_id=baseline.snapshot_id,
        current_snapshot_id=current_snapshot.snapshot_id,
        created_utc=_now_utc(),
        cache_retrieval_metrics={
            "requested_chunks": requested_chunks,
            "retrieved_artifacts": retrieved_count,
            "missing_artifacts": missing_count,
            "cache_hit_ratio": hit_ratio,
        },
        architecture_context=architecture_context,
        dependency_context=dependency_context,
        implementation_steps=implementation_steps,
    )


def bootstrap_to_json(project_path: Path, against_snapshot_id: str | None = None) -> str:
    bundle = build_startup_bundle(project_path.resolve(), against_snapshot_id=against_snapshot_id)
    return json.dumps(bundle.to_dict(), indent=2)


def _unique_in_order(items) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for item in items:
        if not item or item in seen:
            continue
        seen.add(item)
        ordered.append(item)
    return ordered


def _build_implementation_steps(changed_count: int, missing_count: int, retrieved_count: int) -> list[str]:
    steps: list[str] = []

    if retrieved_count > 0:
        steps.append("Start from cached architecture context and dependency notes before editing.")

    if changed_count == 0:
        steps.append("No semantic drift detected versus baseline; prioritize reuse over regeneration.")
    else:
        steps.append(f"Review {changed_count} changed chunk keys and confirm invalidation scope.")

    if missing_count > 0:
        steps.append(
            "Generate missing reasoning artifacts for unchanged chunks lacking cached startup context."
        )

    steps.append("Run delta and report commands to verify cost and cache telemetry before implementation.")
    return steps
