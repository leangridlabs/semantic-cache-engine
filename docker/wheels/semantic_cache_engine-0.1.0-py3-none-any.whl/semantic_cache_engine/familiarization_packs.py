from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
from pathlib import Path

from .hashing.sha256 import sha256_hex

from .cache import build_cache_entry, create_operation_cache_backend
from .bootstrap import build_startup_bundle
from .delta import _classify
from .ingest import ingest_project
from .snapshot import build_snapshot_manifest, latest_snapshot_id, load_snapshot_manifest

PACK_CACHE_ENTRY_TYPE = "familiarization-pack"
PACK_CACHE_VERSION = "phase-4"
PACK_CACHE_TTL_SECONDS = 60


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(frozen=True)
class ConfidenceScores:
    freshness: float
    relevance: float
    coverage: float
    overall: float

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class ScoutPack:
    mode: str
    generated_utc: str
    baseline_snapshot_id: str
    current_snapshot_id: str
    project_map: list[str]
    changed_highlights: list[str]
    suggested_read_order: list[str]
    architecture_context: list[str]
    dependency_context: list[str]
    implementation_steps: list[str]
    confidence: ConfidenceScores

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["confidence"] = self.confidence.to_dict()
        return payload


@dataclass(frozen=True)
class RoutePack:
    mode: str
    generated_utc: str
    baseline_snapshot_id: str
    current_snapshot_id: str
    module_summaries: list[str]
    dependency_hotspots: list[str]
    changed_risk_zones: list[str]
    suggested_questions: list[str]
    confidence: ConfidenceScores

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["confidence"] = self.confidence.to_dict()
        return payload


@dataclass(frozen=True)
class DrillPack:
    mode: str
    generated_utc: str
    baseline_snapshot_id: str
    current_snapshot_id: str
    query: str
    evidence_cards: list[str]
    expansion_reason: str
    confidence: ConfidenceScores

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["confidence"] = self.confidence.to_dict()
        return payload


def _confidence_from_payload(payload: dict) -> ConfidenceScores:
    confidence_payload = payload.get("confidence", {}) if isinstance(payload, dict) else {}
    return ConfidenceScores(
        freshness=float(confidence_payload.get("freshness", 0.0)),
        relevance=float(confidence_payload.get("relevance", 0.0)),
        coverage=float(confidence_payload.get("coverage", 0.0)),
        overall=float(confidence_payload.get("overall", 0.0)),
    )


def _scout_pack_from_payload(payload: dict) -> ScoutPack:
    return ScoutPack(
        mode=str(payload.get("mode", "scout")),
        generated_utc=str(payload.get("generated_utc", _utc_now())),
        baseline_snapshot_id=str(payload.get("baseline_snapshot_id", "")),
        current_snapshot_id=str(payload.get("current_snapshot_id", "")),
        project_map=list(payload.get("project_map", [])),
        changed_highlights=list(payload.get("changed_highlights", [])),
        suggested_read_order=list(payload.get("suggested_read_order", [])),
        architecture_context=list(payload.get("architecture_context", [])),
        dependency_context=list(payload.get("dependency_context", [])),
        implementation_steps=list(payload.get("implementation_steps", [])),
        confidence=_confidence_from_payload(payload),
    )


def _route_pack_from_payload(payload: dict) -> RoutePack:
    return RoutePack(
        mode=str(payload.get("mode", "route")),
        generated_utc=str(payload.get("generated_utc", _utc_now())),
        baseline_snapshot_id=str(payload.get("baseline_snapshot_id", "")),
        current_snapshot_id=str(payload.get("current_snapshot_id", "")),
        module_summaries=list(payload.get("module_summaries", [])),
        dependency_hotspots=list(payload.get("dependency_hotspots", [])),
        changed_risk_zones=list(payload.get("changed_risk_zones", [])),
        suggested_questions=list(payload.get("suggested_questions", [])),
        confidence=_confidence_from_payload(payload),
    )


def _drill_pack_from_payload(payload: dict) -> DrillPack:
    return DrillPack(
        mode=str(payload.get("mode", "drill")),
        generated_utc=str(payload.get("generated_utc", _utc_now())),
        baseline_snapshot_id=str(payload.get("baseline_snapshot_id", "")),
        current_snapshot_id=str(payload.get("current_snapshot_id", "")),
        query=str(payload.get("query", "")),
        evidence_cards=list(payload.get("evidence_cards", [])),
        expansion_reason=str(payload.get("expansion_reason", "")),
        confidence=_confidence_from_payload(payload),
    )


def _pack_cache_identity(
    baseline_snapshot_id: str,
    current_snapshot_id: str,
    mode: str,
    query: str | None,
) -> tuple[str, str]:
    query_hash = sha256_hex((query or "").strip().lower())
    cache_key = f"pack::{mode}::{baseline_snapshot_id}::{current_snapshot_id}::{query_hash}"
    return cache_key, sha256_hex(cache_key)


def _load_cached_pack(
    *,
    baseline_snapshot_id: str,
    current_snapshot_id: str,
    mode: str,
    query: str | None,
) -> dict | None:
    cache_key, cache_hash = _pack_cache_identity(baseline_snapshot_id, current_snapshot_id, mode, query)
    backend = create_operation_cache_backend()
    lookup = backend.get_cache_entry(cache_key, cache_hash, entry_type=PACK_CACHE_ENTRY_TYPE)
    if not lookup.hit or lookup.entry is None:
        return None

    timestamp_text = str(lookup.entry.timestamp_utc)
    try:
        cached_at = datetime.fromisoformat(timestamp_text.replace("Z", "+00:00"))
    except ValueError:
        return None

    age_seconds = (datetime.now(timezone.utc) - cached_at.astimezone(timezone.utc)).total_seconds()
    if age_seconds > PACK_CACHE_TTL_SECONDS:
        return None

    payload = lookup.entry.metadata.get("payload")
    if not isinstance(payload, dict):
        return None
    return payload


def _store_cached_pack(
    *,
    baseline_snapshot_id: str,
    current_snapshot_id: str,
    mode: str,
    query: str | None,
    payload: dict,
) -> None:
    cache_key, cache_hash = _pack_cache_identity(baseline_snapshot_id, current_snapshot_id, mode, query)
    backend = create_operation_cache_backend()
    backend.upsert_cache_entry(
        build_cache_entry(
            chunk_id=cache_key,
            chunk_hash=cache_hash,
            entry_type=PACK_CACHE_ENTRY_TYPE,
            version=PACK_CACHE_VERSION,
            metadata={"payload": payload},
        )
    )


def _path_from_chunk_key(chunk_key: str) -> str:
    if "::" not in chunk_key:
        return chunk_key
    return chunk_key.split("::", 1)[0]


def _unique(items: list[str]) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for item in items:
        if not item or item in seen:
            continue
        seen.add(item)
        ordered.append(item)
    return ordered


def _prioritize_paths(paths: list[str]) -> list[str]:
    def rank(path: str) -> tuple[int, str]:
        low = path.lower()
        if low == "readme.md":
            return (0, low)
        if low.startswith("docs/"):
            return (1, low)
        if low.startswith("src/") or low.startswith("app/") or low.startswith("lib/"):
            return (2, low)
        return (3, low)

    return sorted(paths, key=rank)


def _module_summaries(paths: list[str], max_items: int = 8) -> list[str]:
    counts: dict[str, int] = {}
    for path in paths:
        normalized = path.replace("\\", "/")
        parts = [part for part in normalized.split("/") if part]
        if not parts:
            continue
        if parts[0] in {"src", "app", "lib", "docs"} and len(parts) > 1:
            module = f"{parts[0]}/{parts[1]}"
        else:
            module = parts[0]
        counts[module] = counts.get(module, 0) + 1

    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return [f"{name}: {count} file(s)" for name, count in ranked[:max_items]]


def _confidence_scores(
    total_paths: int,
    changed_paths: int,
    cache_hit_ratio: float,
    context_signal_count: int,
) -> ConfidenceScores:
    if total_paths <= 0:
        freshness = 0.0
    else:
        freshness = max(0.0, min(1.0, 1.0 - (changed_paths / total_paths)))

    if freshness >= 0.85:
        relevance = max(0.0, min(context_signal_count / 16.0, 1.0))
        coverage = max(0.0, min(cache_hit_ratio, 1.0))
        overall = round((freshness * 0.6) + (relevance * 0.15) + (coverage * 0.25), 5)
    else:
        relevance = max(0.0, min(context_signal_count / 8.0, 1.0))
        coverage = max(0.0, min(cache_hit_ratio, 1.0))
        overall = round((freshness * 0.35) + (relevance * 0.25) + (coverage * 0.40), 5)

    return ConfidenceScores(
        freshness=round(freshness, 5),
        relevance=round(relevance, 5),
        coverage=round(coverage, 5),
        overall=overall,
    )


def _snapshot_pair(project_path: Path, against_snapshot_id: str | None) -> tuple:
    baseline_id = against_snapshot_id or latest_snapshot_id()
    baseline = load_snapshot_manifest(baseline_id)
    current_ingest = ingest_project(project_path.resolve())
    current_snapshot = build_snapshot_manifest(current_ingest, baseline_snapshot_id=baseline_id)
    status_counts, changed = _classify(baseline, current_snapshot)
    return baseline, current_snapshot, status_counts, changed


def build_scout_pack(project_path: Path, against_snapshot_id: str | None = None) -> ScoutPack:
    baseline, current_snapshot, _, changed = _snapshot_pair(project_path, against_snapshot_id)

    cached_payload = _load_cached_pack(
        baseline_snapshot_id=baseline.snapshot_id,
        current_snapshot_id=current_snapshot.snapshot_id,
        mode="scout",
        query=None,
    )
    if cached_payload is not None:
        return _scout_pack_from_payload(cached_payload)

    startup = build_startup_bundle(project_path.resolve(), against_snapshot_id=baseline.snapshot_id)

    project_paths = _unique([record.path for record in current_snapshot.chunks])
    changed_paths = _unique([_path_from_chunk_key(key) for key in changed])
    suggested_read_order = _prioritize_paths(project_paths)[:12]

    confidence = _confidence_scores(
        total_paths=len(project_paths),
        changed_paths=len(changed_paths),
        cache_hit_ratio=float(startup.cache_retrieval_metrics.get("cache_hit_ratio", 0.0)),
        context_signal_count=(
            len(startup.architecture_context)
            + len(startup.dependency_context)
            + len(startup.implementation_steps)
        ),
    )

    pack = ScoutPack(
        mode="scout",
        generated_utc=_utc_now(),
        baseline_snapshot_id=baseline.snapshot_id,
        current_snapshot_id=current_snapshot.snapshot_id,
        project_map=project_paths[:40],
        changed_highlights=changed_paths[:20],
        suggested_read_order=suggested_read_order,
        architecture_context=startup.architecture_context,
        dependency_context=startup.dependency_context,
        implementation_steps=startup.implementation_steps,
        confidence=confidence,
    )
    _store_cached_pack(
        baseline_snapshot_id=baseline.snapshot_id,
        current_snapshot_id=current_snapshot.snapshot_id,
        mode="scout",
        query=None,
        payload=pack.to_dict(),
    )
    return pack


def build_route_pack(project_path: Path, against_snapshot_id: str | None = None) -> RoutePack:
    scout = build_scout_pack(project_path, against_snapshot_id=against_snapshot_id)
    cached_payload = _load_cached_pack(
        baseline_snapshot_id=scout.baseline_snapshot_id,
        current_snapshot_id=scout.current_snapshot_id,
        mode="route",
        query=None,
    )
    if cached_payload is not None:
        return _route_pack_from_payload(cached_payload)

    module_summaries = _module_summaries(scout.project_map)
    dependency_hotspots = scout.dependency_context[:12]
    changed_risk_zones = scout.changed_highlights[:12]
    suggested_questions = [
        "Which changed areas have cross-module dependency impact?",
        "Which modules should be reviewed before touching regeneration logic?",
        "Where does cached reasoning coverage look weak?",
    ]

    confidence = _confidence_scores(
        total_paths=max(len(scout.project_map), 1),
        changed_paths=len(changed_risk_zones),
        cache_hit_ratio=scout.confidence.coverage,
        context_signal_count=len(module_summaries) + len(dependency_hotspots),
    )
    pack = RoutePack(
        mode="route",
        generated_utc=_utc_now(),
        baseline_snapshot_id=scout.baseline_snapshot_id,
        current_snapshot_id=scout.current_snapshot_id,
        module_summaries=module_summaries,
        dependency_hotspots=dependency_hotspots,
        changed_risk_zones=changed_risk_zones,
        suggested_questions=suggested_questions,
        confidence=confidence,
    )
    _store_cached_pack(
        baseline_snapshot_id=scout.baseline_snapshot_id,
        current_snapshot_id=scout.current_snapshot_id,
        mode="route",
        query=None,
        payload=pack.to_dict(),
    )
    return pack


def build_drill_pack(
    project_path: Path,
    against_snapshot_id: str | None = None,
    query: str | None = None,
) -> DrillPack:
    route = build_route_pack(project_path, against_snapshot_id=against_snapshot_id)
    normalized_query = (query or "targeted evidence review").strip()
    cached_payload = _load_cached_pack(
        baseline_snapshot_id=route.baseline_snapshot_id,
        current_snapshot_id=route.current_snapshot_id,
        mode="drill",
        query=normalized_query,
    )
    if cached_payload is not None:
        return _drill_pack_from_payload(cached_payload)

    query_tokens = {token for token in normalized_query.lower().split() if token}

    evidence_pool = route.dependency_hotspots + route.changed_risk_zones + route.module_summaries
    if query_tokens:
        evidence_cards = [
            item for item in evidence_pool if any(token in item.lower() for token in query_tokens)
        ]
    else:
        evidence_cards = []
    if not evidence_cards:
        evidence_cards = evidence_pool[:10]

    confidence = _confidence_scores(
        total_paths=max(len(route.module_summaries), 1),
        changed_paths=len(route.changed_risk_zones),
        cache_hit_ratio=route.confidence.coverage,
        context_signal_count=len(evidence_cards),
    )
    pack = DrillPack(
        mode="drill",
        generated_utc=_utc_now(),
        baseline_snapshot_id=route.baseline_snapshot_id,
        current_snapshot_id=route.current_snapshot_id,
        query=normalized_query,
        evidence_cards=evidence_cards,
        expansion_reason="explicit_request" if query else "low_confidence_or_default_drill",
        confidence=confidence,
    )
    _store_cached_pack(
        baseline_snapshot_id=route.baseline_snapshot_id,
        current_snapshot_id=route.current_snapshot_id,
        mode="drill",
        query=normalized_query,
        payload=pack.to_dict(),
    )
    return pack


def build_familiarization_pack(
    project_path: Path,
    mode: str = "scout",
    against_snapshot_id: str | None = None,
    query: str | None = None,
) -> dict:
    normalized_mode = mode.strip().lower()
    if normalized_mode == "scout":
        return build_scout_pack(project_path, against_snapshot_id=against_snapshot_id).to_dict()
    if normalized_mode == "route":
        return build_route_pack(project_path, against_snapshot_id=against_snapshot_id).to_dict()
    if normalized_mode == "drill":
        return build_drill_pack(project_path, against_snapshot_id=against_snapshot_id, query=query).to_dict()

    raise ValueError("Unknown pack mode. Supported modes: scout, route, drill")


def familiarization_pack_to_json(
    project_path: Path,
    mode: str = "scout",
    against_snapshot_id: str | None = None,
    query: str | None = None,
) -> str:
    payload = build_familiarization_pack(
        project_path=project_path,
        mode=mode,
        against_snapshot_id=against_snapshot_id,
        query=query,
    )
    return json.dumps(payload, indent=2)