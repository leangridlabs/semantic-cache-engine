"""scope_identity.py — Canonical scope normalizer.

Single source of truth for scope_fingerprint identity across all three sites:
  - QUERY:   derive_scope_fingerprint in resolver.py / phase13b_resolver.py
  - WRITE:   build_reasoning_card in reasoning_memory.py
  - COMPARE: _match_score / scope_overlap in reasoning_memory.py

All surface forms of the same module identity collapse to the same string:
  HydrationCache          -> hydration_cache
  HydrationCache._finalise-> hydration_cache (module portion)
  hydrationcache          -> hydrationcache  (already-flattened; no boundaries)
  hydration_cache         -> hydration_cache (idempotent)
  graph_navigator         -> graph_navigator (idempotent)
  GraphNavigator          -> graph_navigator
  DirectedQueryRouter     -> directed_query_router
  hydration_cache::build  -> hydration_cache::build
  repo                    -> repo (sentinel preserved)
  ""                      -> "" (empty preserved)

NOTE: already-flattened lowercase forms like "hydrationcache" have lost their
word boundaries and cannot be recovered by normalisation alone.  The migration
script (_migrate_canonical_scope.py) handles those via reverse-lookup against
known module names.  The _scope_token_set function below bridges them at Jaccard
compare time until migration has run.
"""

from __future__ import annotations

import re


_MULTI_UNDERSCORE = re.compile(r"_+")
_CAMEL_BOUNDARY = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")


def canonical_scope(raw: str) -> str:
    """Return the canonical scope identity for *raw*.

    Rules
    -----
    - Empty string and the sentinel ``"repo"`` pass through unchanged.
    - Split on ``::`` into at most two parts (module, optional symbol).
    - Each part is run through ``_normalise_part``.
    - Parts are rejoined with ``::`` and returned.
    """
    value = raw.strip()
    if not value or value == "repo":
        return value

    parts = value.split("::", 1)
    normalised = "::".join(_normalise_part(p) for p in parts)
    return normalised


def _normalise_part(part: str) -> str:
    """Insert underscores at CamelCase boundaries, lowercase, collapse repeated underscores."""
    if not part:
        return part
    # Replace dots with underscores before CamelCase normalization so that
    # variant suffixes like ".old" / ".new" (from React-style filenames such as
    # ReactFiberLazyComponent.old.js) are treated as word boundaries rather than
    # preserved as literal dots in the stored scope fingerprint.
    dot_normalized = part.replace(".", "_")
    # Insert _ before each uppercase letter that follows a lowercase letter or digit.
    # This converts CamelCase → snake_case while leaving already-snake identifiers intact.
    with_boundaries = _CAMEL_BOUNDARY.sub("_", dot_normalized)
    lowered = with_boundaries.lower()
    # Collapse any run of underscores (e.g. from leading _ on symbol names) to one,
    # but preserve a single leading underscore (private symbol convention).
    cleaned = _MULTI_UNDERSCORE.sub("_", lowered)
    return cleaned


def _scope_token_set(value: str) -> set[str]:
    """Tokenize a canonical scope for Jaccard comparison.

    In addition to the standard ``[a-z0-9]+`` split, also adds the *joined*
    form of multi-part identifiers so that already-flattened scopes
    (``hydrationcache``) share a token with their correctly-formed counterparts
    (``hydration_cache`` → tokens ``{hydration, cache, hydrationcache}``).

    Use this function ONLY for scope overlap comparisons, never for intent
    overlap — joining intent tokens would inject noise like ``whatdoesfinalise``.
    """
    canon = canonical_scope(value)
    # Split module and symbol separately so "hydration_cache::build" produces
    # {hydration, cache, build, hydrationcache} not {hydrationcachebuild}.
    parts = canon.split("::", 1)
    all_parts_tokens: list[str] = []
    token_sets: list[set[str]] = []
    for part in parts:
        tokens = [t for t in re.findall(r"[a-z0-9]+", part) if t]
        all_parts_tokens.extend(tokens)
        token_sets.append(set(tokens))

    result: set[str] = set()
    for ts in token_sets:
        result.update(ts)

    # Add joined form per part so hydration_cache -> hydrationcache
    for part in parts:
        tokens = [t for t in re.findall(r"[a-z0-9]+", part) if t]
        if len(tokens) > 1:
            joined = "".join(tokens)
            if len(joined) >= 4:
                result.add(joined)

    return result
