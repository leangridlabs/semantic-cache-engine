from __future__ import annotations

import asyncio
from collections import deque
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import signal
import socket
import sqlite3
import subprocess
import sys
import time
import threading
from typing import Any
import uuid
import webbrowser

# FastMCP is imported lazily inside create_mcp_server() so that non-MCP CLI
# commands (resolver-baseline, ingest, delta, etc.) never load the mcp package.
# This eliminates the Windows KBI crash that fires inside the frozen import
# bootstrap (_path_join / find_spec) when the large mcp dependency tree is
# probed at process startup for commands that don't need it.

from .delta import compute_delta_report
from .familiarization_packs import build_familiarization_pack
from .phase13_metrics import build_metrics_report
from .resolver import (
    resolve_developer_question,
    _fast_lane_lru_get,
    _fast_lane_lru_put,
    _fast_lane_eligible,
)
from .reason_bundle import warm_start_if_bundle_exists
from .reasoning_memory import commit_reasoning_card, recall_reasoning_cards
from .run_report import save_delta_run_report, summarize_run_report
from .settings import load_settings
from .snapshot import latest_snapshot_id

_BASE = Path(os.environ.get("SEMANTIC_CACHE_BASE_DIR", ".reason"))
SHADOW_REPORT_PATH = _BASE / "runs/shadow/session-shadow-latest.json"
MCP_PID_PATH = _BASE / "runs/mcp/server.pid"
MCP_LOCK_PATH = _BASE / "runs/mcp/server.lock"
MCP_RESOLVE_TRACE_PATH = _BASE / "runs/mcp/resolve-trace.jsonl"
MCP_TOOL_TRACE_PATH = _BASE / "runs/mcp/tool-trace.jsonl"
SQLITE_SUMMARY_LIMIT_MAX = 250
_TRACE_FILE_HANDLES: dict[Path, Any] = {}
SESSION_EGRESS_LIVE_PATH = _BASE / "runs/egress/session-egress-live.jsonl"
_RESOLVE_EXECUTOR = ThreadPoolExecutor(max_workers=2, thread_name_prefix="semantic-cache-resolve")
_RESOLVE_STATE_LOCK = threading.Lock()
_RESOLVE_PENDING_REQUESTS = 0
_RESOLVE_OUTCOME_HISTORY: deque[dict[str, Any]] = deque(maxlen=200)
_RESOLVE_TIMEOUT_TRACE_IDS: deque[str] = deque(maxlen=5)


class _SessionEgressMonitor:
    """Persistent session-lifetime socket egress monitor.

    Records every DNS lookup and outbound TCP connect for the lifetime of the
    MCP server process, tagged with the active tool phase. Flushes to a JSON
    file on every event so evidence is never lost on crash.
    """

    _LOOPBACK = {"127.0.0.1", "::1", "localhost", "0.0.0.0", ""}

    def __init__(self, flush_path: Path) -> None:
        self.flush_path = flush_path
        self.session_start_utc = datetime.now(timezone.utc).isoformat()
        self.events: list[dict[str, Any]] = []
        self.phase = "startup"
        self.resolved_ips: dict[str, str] = {}
        self._lock = threading.Lock()
        self._orig_getaddrinfo = socket.getaddrinfo
        self._orig_connect = socket.socket.connect
        self._orig_connect_ex = socket.socket.connect_ex

    @staticmethod
    def _is_loopback(host: str) -> bool:
        h = (host or "").strip().lower()
        return h in _SessionEgressMonitor._LOOPBACK or h.startswith("127.")

    def _host_port(self, address: object) -> tuple[str, int | None]:
        if isinstance(address, tuple) and address:
            host = str(address[0])
            port = address[1] if len(address) > 1 else None
            try:
                port = int(port) if port is not None else None
            except (TypeError, ValueError):
                port = None
            return host, port
        return str(address), None

    def _record(self, kind: str, host: str, port: int | None) -> None:
        resolved_from = None
        if kind in ("connect", "connect_ex"):
            resolved_from = self.resolved_ips.get(host)
        loopback = self._is_loopback(host)
        with self._lock:
            self.events.append({
                "utc": datetime.now(timezone.utc).isoformat(),
                "phase": self.phase,
                "kind": kind,
                "host": host,
                "resolved_from": resolved_from,
                "port": port,
                "loopback": loopback,
            })
            self._flush_locked()

    def _flush_locked(self) -> None:
        if not self.events:
            return
        try:
            with open(self.flush_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(self.events[-1]) + "\n")
        except OSError:
            pass

    def set_phase(self, phase: str) -> None:
        with self._lock:
            self.phase = phase

    def summary(self) -> dict[str, Any]:
        with self._lock:
            remote = [e for e in self.events if not e["loopback"] and e["kind"] in ("connect", "connect_ex")]
            return {
                "session_start_utc": self.session_start_utc,
                "total_events": len(self.events),
                "remote_connect_count": len(remote),
                "remote_hosts": sorted({(e["resolved_from"] or e["host"]).lower() for e in remote}),
                "events_by_phase": _count_by(self.events, "phase"),
                "remote_by_phase": _count_by(remote, "phase"),
                "flush_path": str(self.flush_path),
            }

    def start(self) -> None:
        monitor = self

        def patched_getaddrinfo(host, *args, **kwargs):
            result = monitor._orig_getaddrinfo(host, *args, **kwargs)
            for info in result:
                try:
                    ip = str(info[4][0])
                except (IndexError, TypeError):
                    continue
                if ip and not monitor._is_loopback(ip):
                    with monitor._lock:
                        monitor.resolved_ips[ip] = str(host)
            monitor._record("getaddrinfo", str(host), None)
            return result

        def patched_connect(self_sock, address):
            host, port = monitor._host_port(address)
            monitor._record("connect", host, port)
            return monitor._orig_connect(self_sock, address)

        def patched_connect_ex(self_sock, address):
            host, port = monitor._host_port(address)
            monitor._record("connect_ex", host, port)
            return monitor._orig_connect_ex(self_sock, address)

        # Truncate/create the file and write session header before installing patches.
        try:
            self.flush_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.flush_path, "w", encoding="utf-8") as f:
                f.write(json.dumps({"type": "session_start", "session_start_utc": self.session_start_utc}) + "\n")
        except OSError:
            pass

        socket.getaddrinfo = patched_getaddrinfo
        socket.socket.connect = patched_connect
        socket.socket.connect_ex = patched_connect_ex

    def stop(self) -> None:
        socket.getaddrinfo = self._orig_getaddrinfo
        socket.socket.connect = self._orig_connect
        socket.socket.connect_ex = self._orig_connect_ex


def _count_by(items: list[dict], key: str) -> dict[str, int]:
    out: dict[str, int] = {}
    for item in items:
        v = item.get(key, "unknown")
        out[v] = out.get(v, 0) + 1
    return out


_SESSION_EGRESS_MONITOR: _SessionEgressMonitor | None = None


def _open_dashboard_url(url: str) -> tuple[bool, str]:
    if os.name == "nt" and hasattr(os, "startfile"):
        try:
            os.startfile(url)
            return True, "os.startfile"
        except OSError:
            pass

    try:
        opened = webbrowser.open(url, new=2)
    except Exception:
        return False, "none"

    return (True, "webbrowser") if opened else (False, "none")


def _port_is_listening(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.25)
        return sock.connect_ex((host, port)) == 0


def _first_available_port(host: str, start_port: int, max_tries: int = 20) -> int:
    candidate = int(start_port)
    for _ in range(max(1, max_tries)):
        if not _port_is_listening(host, candidate):
            return candidate
        candidate += 1
    return int(start_port)


@dataclass(frozen=True)
class CacheSummary:
    db_path: str
    exists: bool
    entry_type: str
    entry_count: int
    recent_entries: list[dict[str, Any]]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def run_shadow_session(
    project_root: Path,
    against_snapshot_id: str | None = None,
    playbook: str = "session-readiness",
    live_provider: str | None = None,
    provider_hydration: str = "probe",
) -> dict[str, Any]:
    resolved_root = project_root.resolve()
    resolved_against = against_snapshot_id or latest_snapshot_id(resolved_root / "data" / "baselines")
    resolved_live_provider = (live_provider or "openai-compatible").strip().lower()
    report = compute_delta_report(
        resolved_root,
        resolved_against,
        live_provider=resolved_live_provider,
        playbook=playbook,
        provider_hydration=provider_hydration,
    )
    save_delta_run_report(report, resolved_root / "data" / "runs")
    payload = report.to_dict()

    output_path = resolved_root / SHADOW_REPORT_PATH
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    summary = summarize_run_report(payload)
    provider_usage = payload.get("provider_usage", {})
    return {
        "run_id": report.run_id,
        "baseline_snapshot_id": report.baseline_snapshot_id,
        "shadow_report_path": str(output_path),
        "summary": summary.to_dict(),
        "provider_usage": provider_usage,
        "chunk_status_counts": payload.get("chunk_status_counts", {}),
        "runtime_seconds": report.runtime_seconds,
    }


def load_session_context(project_root: Path, bootstrap_if_missing: bool = True) -> dict[str, Any]:
    resolved_root = project_root.resolve()
    report_path = resolved_root / SHADOW_REPORT_PATH
    if not report_path.exists():
        if not bootstrap_if_missing:
            raise FileNotFoundError(f"Shadow report not found: {report_path}")
        return run_shadow_session(resolved_root)

    payload = json.loads(report_path.read_text(encoding="utf-8"))
    summary = summarize_run_report(payload)
    provider_usage = payload.get("provider_usage", {})
    execution_profile = payload.get("execution_profile", {})
    return {
        "shadow_report_path": str(report_path),
        "run_id": payload.get("run_id"),
        "summary": summary.to_dict(),
        "provider_usage": provider_usage,
        "execution_profile": execution_profile,
        "chunk_status_counts": payload.get("chunk_status_counts", {}),
        "runtime_seconds": payload.get("runtime_seconds"),
    }


def load_sqlite_cache_summary(
    project_root: Path,
    entry_type: str = "reasoning",
    limit: int = 5,
) -> dict[str, Any]:
    resolved_root = project_root.resolve()
    settings = load_settings(resolved_root)
    db_path = settings.sqlite_path
    if not db_path.exists():
        return CacheSummary(
            db_path=str(db_path),
            exists=False,
            entry_type=entry_type,
            entry_count=0,
            recent_entries=[],
        ).to_dict()

    with sqlite3.connect(db_path) as conn:
        conn.execute("PRAGMA busy_timeout=10000")
        conn.execute("PRAGMA journal_mode=WAL")
        conn.row_factory = sqlite3.Row
        bounded_limit = max(1, min(int(limit), SQLITE_SUMMARY_LIMIT_MAX))
        count_row = conn.execute(
            "select count(*) as count from cache_entries where type = ?",
            (entry_type,),
        ).fetchone()
        rows = conn.execute(
            """
            select entry_id, chunk_id, hash, version, timestamp_utc
            from cache_entries
            where type = ?
            order by timestamp_utc desc
            limit ?
            """,
            (entry_type, bounded_limit),
        ).fetchall()

    return CacheSummary(
        db_path=str(db_path),
        exists=True,
        entry_type=entry_type,
        entry_count=int(count_row["count"] if count_row is not None else 0),
        recent_entries=[dict(row) for row in rows],
    ).to_dict()


def load_reasoning_recall(
    project_root: Path,
    task_intent: str,
    scope_fingerprint: str,
    limit: int = 5,
) -> dict[str, Any]:
    return recall_reasoning_cards(
        project_root=project_root,
        task_intent=task_intent,
        scope_fingerprint=scope_fingerprint,
        limit=limit,
    )


def save_reasoning_card(
    project_root: Path,
    card_payload: dict[str, Any],
    source: str = "mcp",
) -> dict[str, Any]:
    # Pass agent-supplied scope_fingerprint through unchanged.
    # Agents typically supply a file path (e.g. "src/api.py") as the scope.
    # The resolver's secondary and tertiary recall passes query by file path
    # and intent respectively, so the literal value is more useful than a
    # derived hash (which would require identical inputs at both commit and
    # query time — not guaranteed across natural-language rephrasings).
    return commit_reasoning_card(
        project_root=project_root,
        card_payload=card_payload,
        source=source,
    )


def save_reasoning_cards_batch(
    project_root: Path,
    cards: list[dict[str, Any]],
    source: str = "mcp",
) -> dict[str, Any]:
    """Commit multiple reasoning cards in a single call.

    Cards are committed in order. Each card follows the same rules as
    save_reasoning_card. Results are collected per-card; a failure on one
    card does not abort the remaining cards.
    """
    results = []
    committed = 0
    for card_payload in cards:
        try:
            result = commit_reasoning_card(
                project_root=project_root,
                card_payload=card_payload,
                source=source,
            )
            results.append({"scope_fingerprint": card_payload.get("scope_fingerprint", ""), "status": "ok", "result": result})
            committed += 1
        except Exception as exc:  # noqa: BLE001
            results.append({"scope_fingerprint": card_payload.get("scope_fingerprint", ""), "status": "error", "error": str(exc)})
    return {"committed": committed, "total": len(cards), "results": results}


def load_file_or_card(
    project_root: Path,
    path: str,
    min_confidence: float = 0.80,
) -> dict[str, Any]:
    """Return a reasoning card summary for *path* when confidence >= min_confidence.

    Derives the module scope from the file stem, queries reasoning recall, and
    returns the card's outcome_summary when a qualifying card is found.  Falls
    through to actual file content when no card meets the threshold.

    Served-from values:
      "card"  — high-confidence card returned; file was not read.
      "file"  — no qualifying card; file content returned.
      "error" — file not found or unreadable.
    """
    resolved_root = project_root.resolve()
    file_path = Path(path)

    # Derive module scope from path stem (mirrors resolver._extract_module_from_path)
    stem = file_path.stem
    _SKIP_STEMS = {"README", "readme", "config", "settings", "__init__", "conftest"}
    _NON_CODE_SUFFIXES = {
        ".env", ".md", ".txt", ".json", ".yaml", ".yml",
        ".toml", ".cfg", ".ini", ".lock", ".csv", ".log",
    }
    scope: str | None = None
    if stem and stem not in _SKIP_STEMS and file_path.suffix.lower() not in _NON_CODE_SUFFIXES:
        scope = stem.lower().replace("-", "_")

    # Attempt recall when we have a usable scope
    if scope:
        try:
            recall_result = recall_reasoning_cards(
                project_root=resolved_root,
                task_intent=scope,
                scope_fingerprint=scope,
                limit=3,
            )
            _BOILERPLATE = (
                "agent handoff prepared with memory-first context",
                "cache empty for this question",
                "use recalled reasoning candidates first",
            )
            for candidate in recall_result.get("candidates", []):
                score = float(candidate.get("score", 0.0))
                if score < min_confidence:
                    break  # candidates sorted descending — no point scanning further

                # Reject skeleton / placeholder cards
                constraints = candidate.get("constraints") if isinstance(candidate.get("constraints"), dict) else {}
                if constraints.get("route") == "agent_handoff":
                    continue
                summary = str(candidate.get("outcome_summary", "")).strip()
                if not summary:
                    continue
                if any(p in summary.lower() for p in _BOILERPLATE):
                    continue

                # Qualifying card found — return summary, no file I/O
                return {
                    "served_from": "card",
                    "is_summary": True,
                    "path": path,
                    "scope_fingerprint": scope,
                    "card_id": candidate.get("card_id"),
                    "score": score,
                    "outcome_summary": summary,
                    "chosen_plan": candidate.get("chosen_plan", []),
                    "card_updated_utc": candidate.get("updated_utc"),
                    "hint": (
                        "PARTIAL SUMMARY — not full file source. "
                        "Evaluate whether the outcome_summary above covers the specific detail "
                        "this question requires. If it does not, call read_file on '"
                        + path +
                        "' to get the full source before answering. "
                        "A wrong answer from an incomplete card is worse than one extra file read."
                    ),
                }
        except Exception:  # noqa: BLE001
            pass  # Fall through to file read on any recall error

    # Fall through: read the actual file
    abs_path = file_path if file_path.is_absolute() else resolved_root / file_path
    try:
        content = abs_path.read_text(encoding="utf-8", errors="replace")
        return {
            "served_from": "file",
            "path": path,
            "scope_fingerprint": scope,
            "content": content,
            "size_bytes": abs_path.stat().st_size,
        }
    except FileNotFoundError:
        return {
            "served_from": "error",
            "path": path,
            "error": f"File not found: {abs_path}",
        }
    except Exception as exc:  # noqa: BLE001
        return {
            "served_from": "error",
            "path": path,
            "error": str(exc),
        }


def load_familiarization_pack(
    project_root: Path,
    mode: str = "scout",
    against_snapshot_id: str | None = None,
    query: str | None = None,
) -> dict[str, Any]:
    return build_familiarization_pack(
        project_path=project_root,
        mode=mode,
        against_snapshot_id=against_snapshot_id,
        query=query,
    )


def load_metrics_report(
    project_root: Path,
    window_days: int = 7,
    top_n: int = 3,
) -> dict[str, Any]:
    report = build_metrics_report(
        project_root=project_root,
        window_days=window_days,
        top_n=top_n,
    )
    return report.to_dict()


def load_engine_health(project_root: Path) -> dict[str, Any]:
    resolved_root = project_root.resolve()
    status = mcp_server_status(resolved_root)
    return {
        "project_root": str(resolved_root),
        "running": status.get("running", False),
        "pid": status.get("pid"),
        "queue_depth": _resolve_queue_depth(),
        "queue_limit": _resolve_queue_limit(),
        "timeout_rate": _resolve_timeout_rate(),
        "timeout_trace_ids": _resolve_timeout_trace_ids(),
        "budget": _resolve_budget_snapshot(),
        "mcp_status": status,
    }


def resolve_question_with_policy(
    project_root: Path,
    question: str,
    file_path: str | None = None,
    symbol: str | None = None,
    selection: str | None = None,
    against_snapshot_id: str | None = None,
    trace_id: str | None = None,
    trace_hook: Any | None = None,
) -> dict[str, Any]:
    return resolve_developer_question(
        project_root=project_root,
        question=question,
        file_path=file_path,
        symbol=symbol,
        selection=selection,
        against_snapshot_id=against_snapshot_id,
        trace_id=trace_id,
        trace_hook=trace_hook,
    )


def _resolve_trace_enabled() -> bool:
    return (os.getenv("SEMANTIC_MCP_RESOLVE_TRACE") or "").strip().lower() in {"1", "true", "yes", "on"}


def _resolve_timeout_seconds() -> int:
    raw = (os.getenv("SEMANTIC_MCP_RESOLVE_TIMEOUT_SECONDS") or "").strip()
    try:
        value = int(raw) if raw else 30
    except ValueError:
        value = 30
    return max(3, min(120, value))


def _resolve_timeout_override(env_name: str, default_value: int) -> int:
    raw = (os.getenv(env_name) or "").strip()
    try:
        value = int(raw) if raw else int(default_value)
    except ValueError:
        value = int(default_value)
    return max(3, min(120, value))


def _has_editor_context(file_path: str | None, symbol: str | None, selection: str | None) -> bool:
    return bool(file_path) or bool(symbol) or bool(selection)


def _resolve_queue_limit() -> int:
    raw = (os.getenv("SEMANTIC_MCP_RESOLVE_QUEUE_LIMIT") or "4").strip()
    try:
        value = int(raw)
    except ValueError:
        value = 4
    return max(1, min(value, 32))


def _resolve_queue_depth() -> int:
    with _RESOLVE_STATE_LOCK:
        return _RESOLVE_PENDING_REQUESTS


def _reserve_resolve_slot() -> tuple[bool, int, int]:
    global _RESOLVE_PENDING_REQUESTS
    with _RESOLVE_STATE_LOCK:
        queue_depth = _RESOLVE_PENDING_REQUESTS
        queue_limit = _resolve_queue_limit()
        if queue_depth >= queue_limit:
            return False, queue_depth, queue_limit

        _RESOLVE_PENDING_REQUESTS += 1
        return True, _RESOLVE_PENDING_REQUESTS, queue_limit


def _release_resolve_slot() -> None:
    global _RESOLVE_PENDING_REQUESTS
    with _RESOLVE_STATE_LOCK:
        _RESOLVE_PENDING_REQUESTS = max(0, _RESOLVE_PENDING_REQUESTS - 1)


def _record_resolve_outcome(*, trace_id: str, timed_out: bool, route: str, status: str) -> None:
    outcome = {
        "trace_id": trace_id,
        "timed_out": timed_out,
        "route": route,
        "status": status,
        "generated_utc": datetime.now(timezone.utc).isoformat(),
    }
    with _RESOLVE_STATE_LOCK:
        _RESOLVE_OUTCOME_HISTORY.append(outcome)
        if timed_out:
            _RESOLVE_TIMEOUT_TRACE_IDS.append(trace_id)


def _resolve_timeout_rate() -> float:
    with _RESOLVE_STATE_LOCK:
        if not _RESOLVE_OUTCOME_HISTORY:
            return 0.0
        timeout_count = sum(1 for item in _RESOLVE_OUTCOME_HISTORY if item.get("timed_out"))
        return round(timeout_count / len(_RESOLVE_OUTCOME_HISTORY), 5)


def _resolve_timeout_trace_ids() -> list[str]:
    with _RESOLVE_STATE_LOCK:
        return list(_RESOLVE_TIMEOUT_TRACE_IDS)


def _resolve_budget_snapshot() -> dict[str, int]:
    default_seconds = _resolve_timeout_seconds()
    return {
        "default_seconds": default_seconds,
        "fast_seconds": _resolve_timeout_override(
            "SEMANTIC_MCP_RESOLVE_TIMEOUT_FAST_SECONDS",
            min(default_seconds, 12),
        ),
        "deep_seconds": _resolve_timeout_override(
            "SEMANTIC_MCP_RESOLVE_TIMEOUT_DEEP_SECONDS",
            max(default_seconds, 45),
        ),
        "queue_limit": _resolve_queue_limit(),
    }


def _is_explicit_deep_request(question: str) -> bool:
    text = (question or "").strip().lower()
    if not text:
        return False
    deep_markers = (
        "drill",
        "deep analysis",
        "full analysis",
        "investigate deeply",
        "fresh delta",
        "run delta",
    )
    return any(marker in text for marker in deep_markers)


def _select_resolve_timeout(
    question: str,
    file_path: str | None,
    symbol: str | None,
    selection: str | None,
) -> tuple[int, str, bool, bool]:
    base_timeout = _resolve_timeout_seconds()
    fast_timeout = _resolve_timeout_override(
        "SEMANTIC_MCP_RESOLVE_TIMEOUT_FAST_SECONDS",
        min(base_timeout, 12),
    )
    deep_timeout = _resolve_timeout_override(
        "SEMANTIC_MCP_RESOLVE_TIMEOUT_DEEP_SECONDS",
        max(base_timeout, 45),
    )

    # Keep route budgets coherent with global limits.
    fast_timeout = min(fast_timeout, base_timeout)
    deep_timeout = max(deep_timeout, base_timeout)

    has_editor_context = _has_editor_context(file_path, symbol, selection)
    explicit_deep = _is_explicit_deep_request(question)
    timeout_profile = "deep" if (has_editor_context or explicit_deep) else "fast"
    selected_timeout = deep_timeout if timeout_profile == "deep" else fast_timeout
    return selected_timeout, timeout_profile, has_editor_context, explicit_deep


def _append_mcp_resolve_trace(project_root: Path, payload: dict[str, Any]) -> None:
    if not _resolve_trace_enabled():
        return

    path = project_root.resolve() / MCP_RESOLVE_TRACE_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = dict(payload)
    payload.setdefault("generated_utc", datetime.now(timezone.utc).isoformat())
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, separators=(",", ":")) + "\n")


def _append_mcp_tool_trace(project_root: Path, payload: dict[str, Any]) -> None:
    path = project_root.resolve() / MCP_TOOL_TRACE_PATH
    if path not in _TRACE_FILE_HANDLES:
        path.parent.mkdir(parents=True, exist_ok=True)
        _TRACE_FILE_HANDLES[path] = path.open("a", encoding="utf-8")
    event_payload = dict(payload)
    event_payload.setdefault("generated_utc", datetime.now(timezone.utc).isoformat())
    handle = _TRACE_FILE_HANDLES[path]
    handle.write(json.dumps(event_payload, separators=(",", ":")) + "\n")
    handle.flush()


def _sanitize_tool_value(value: Any, depth: int = 0) -> Any:
    if value is None or isinstance(value, (bool, int, float)):
        return value

    if isinstance(value, str):
        text = value.strip()
        return text[:120] + ("..." if len(text) > 120 else "")

    if depth >= 2:
        if isinstance(value, (dict, list, tuple, set)):
            return f"<{type(value).__name__} len={len(value)}>"
        return f"<{type(value).__name__}>"

    if isinstance(value, dict):
        items = list(value.items())[:20]
        return {str(key): _sanitize_tool_value(item, depth + 1) for key, item in items}

    if isinstance(value, (list, tuple, set)):
        items = list(value)[:10]
        return [_sanitize_tool_value(item, depth + 1) for item in items]

    return f"<{type(value).__name__}>"


def _summarize_tool_result(result: Any) -> dict[str, Any]:
    if not isinstance(result, dict):
        return {"result_type": type(result).__name__}

    summary: dict[str, Any] = {"result_type": "dict", "key_count": len(result)}
    for key in (
        "route",
        "run_id",
        "trace_id",
        "error",
        "launched",
        "exists",
        "entry_count",
        "window_days",
    ):
        if key in result:
            summary[key] = _sanitize_tool_value(result.get(key))
    return summary


def _run_tracked_tool(
    project_root: Path,
    tool_name: str,
    args_payload: dict[str, Any],
    runner,
) -> dict[str, Any]:
    trace_id = f"tool-{uuid.uuid4().hex[:12]}"
    started_at = time.perf_counter()
    if _SESSION_EGRESS_MONITOR is not None:
        _SESSION_EGRESS_MONITOR.set_phase(tool_name)
    _append_mcp_tool_trace(
        project_root,
        {
            "trace_id": trace_id,
            "event": "tool_invocation_start",
            "tool_name": tool_name,
            "args": _sanitize_tool_value(args_payload),
        },
    )
    try:
        result = runner()
        _append_mcp_tool_trace(
            project_root,
            {
                "trace_id": trace_id,
                "event": "tool_invocation_end",
                "tool_name": tool_name,
                "elapsed_seconds": round(max(time.perf_counter() - started_at, 0.0), 6),
                "status": "ok",
                "result_summary": _summarize_tool_result(result),
            },
        )
        return result
    except Exception as exc:
        _append_mcp_tool_trace(
            project_root,
            {
                "trace_id": trace_id,
                "event": "tool_invocation_end",
                "tool_name": tool_name,
                "elapsed_seconds": round(max(time.perf_counter() - started_at, 0.0), 6),
                "status": "error",
                "error": str(exc),
                "error_type": type(exc).__name__,
            },
        )
        raise
    finally:
        if _SESSION_EGRESS_MONITOR is not None:
            _SESSION_EGRESS_MONITOR.set_phase("idle")


def _build_late_resolver_completion_trace(
    trace_id: str,
    *,
    started_at: float,
    timed_out_before_completion: bool,
    result: dict[str, Any] | None = None,
    error: BaseException | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "trace_id": trace_id,
        "event": "resolver_future_done",
        "timed_out_before_completion": timed_out_before_completion,
        "elapsed_seconds": round(max(time.perf_counter() - started_at, 0.0), 6),
    }

    if error is not None:
        payload["future_error"] = str(error)
        return payload

    safe_result = result if isinstance(result, dict) else {}
    payload["route"] = safe_result.get("route")
    payload["classification"] = (safe_result.get("classification") or {}).get("category")

    route_payload = safe_result.get("route_payload")
    if isinstance(route_payload, dict) and safe_result.get("route") == "fresh_delta":
        payload["fresh_delta_runtime_seconds"] = route_payload.get("runtime_seconds")
        debug = route_payload.get("debug")
        if isinstance(debug, dict):
            provider_usage = debug.get("provider_usage") if isinstance(debug.get("provider_usage"), dict) else {}
            execution_profile = debug.get("execution_profile") if isinstance(debug.get("execution_profile"), dict) else {}
            payload["delta_debug"] = {
                "operation_cache_backend": debug.get("operation_cache_backend"),
                "progress_event_count": int(debug.get("progress_event_count", 0)),
                "progress_tail": list(debug.get("progress_tail", []))[-25:],
                "provider_usage": {
                    "mode": provider_usage.get("mode"),
                    "model": provider_usage.get("model"),
                    "latency_ms": provider_usage.get("latency_ms"),
                    "error": provider_usage.get("error"),
                },
                "execution_profile": {
                    "playbook": execution_profile.get("playbook"),
                    "token_budget": execution_profile.get("token_budget"),
                    "estimated_ingest_tokens": execution_profile.get("estimated_ingest_tokens"),
                    "token_budget_exhausted": execution_profile.get("token_budget_exhausted"),
                    "embedding_cache_enabled": execution_profile.get("embedding_cache_enabled"),
                },
            }

    return payload


def launch_metrics_dashboard(
    project_root: Path,
    host: str = "127.0.0.1",
    port: int = 8501,
    open_browser: bool = False,
) -> dict[str, Any]:
    resolved_root = project_root.resolve()
    dashboard_script = resolved_root / "scripts" / "metrics_dashboard.py"

    if not dashboard_script.exists():
        return {
            "launched": False,
            "error": f"Dashboard script not found: {dashboard_script}",
        }

    if importlib.util.find_spec("streamlit") is None:
        return {
            "launched": False,
            "error": "Streamlit is not installed in the current Python environment.",
            "hint": "Install with: pip install streamlit",
        }

    url = f"http://{host}:{port}"

    # If a dashboard is already listening, reuse it and optionally open the browser.
    if _port_is_listening(host, port):
        opened, open_method = _open_dashboard_url(url) if open_browser else (False, "none")
        return {
            "launched": True,
            "already_running": True,
            "pid": None,
            "url": url,
            "script": str(dashboard_script),
            "open_browser": open_browser,
            "browser_opened": opened,
            "browser_open_method": open_method,
        }

    command = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        str(dashboard_script),
        "--server.address",
        host,
        "--server.port",
        str(port),
        "--server.headless",
        "true",
    ]

    child_env = dict(os.environ)
    child_env["SEMANTIC_DASHBOARD_AUTO_EXIT_ON_IDLE"] = "1"
    child_env["SEMANTIC_DASHBOARD_IDLE_SECONDS"] = "10"

    process = subprocess.Popen(
        command,
        cwd=str(resolved_root),
        env=child_env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )

    deadline = time.time() + 5.0
    while time.time() < deadline:
        if process.poll() is not None:
            return {
                "launched": False,
                "error": "Dashboard process exited before startup completed.",
                "exit_code": process.returncode,
                "url": url,
                "hint": "Check whether streamlit is installed and whether the port is available.",
            }
        if _port_is_listening(host, port):
            break
        time.sleep(0.1)
    else:
        return {
            "launched": False,
            "error": "Dashboard did not become reachable before timeout.",
            "pid": process.pid,
            "url": url,
            "hint": "Try again or call metrics_dashboard with a different port.",
        }

    opened, open_method = _open_dashboard_url(url) if open_browser else (False, "none")

    return {
        "launched": True,
        "already_running": False,
        "pid": process.pid,
        "url": url,
        "script": str(dashboard_script),
        "command": command,
        "open_browser": open_browser,
        "browser_opened": opened,
        "browser_open_method": open_method,
    }


def show_metrics_dashboard(project_root: Path) -> dict[str, Any]:
    host = "127.0.0.1"
    port = _first_available_port(host=host, start_port=8501, max_tries=20)
    return launch_metrics_dashboard(
        project_root=project_root,
        host=host,
        port=port,
        open_browser=True,
    )


def resolve_question_with_shared_executor(
    project_root: Path,
    question: str,
    file_path: str | None = None,
    symbol: str | None = None,
    selection: str | None = None,
    against_snapshot_id: str | None = None,
) -> dict[str, Any]:
    resolved_root = project_root.resolve()

    # ------------------------------------------------------------------
    # Fast-lane LRU: serve from in-process cache before acquiring a slot.
    # Only fires for broad questions (no editor context).
    # ------------------------------------------------------------------
    _has_ctx = bool(
        (file_path and file_path.strip())
        or (symbol and symbol.strip())
        or (selection and selection.strip())
    )
    if not _has_ctx:
        _lru_entry = _fast_lane_lru_get(resolved_root, question)
        if _lru_entry is not None:
            return {
                **_lru_entry,
                "generated_utc": datetime.now(timezone.utc).isoformat(),
                "trace_id": f"fl-lru-{uuid.uuid4().hex[:8]}",
                "decision_trace": [{"step": "fast_lane_lru", "source": "mcp_in_memory_cache"}],
            }

    trace_id = f"rq-{uuid.uuid4().hex[:12]}"
    accepted, queue_depth, queue_limit = _reserve_resolve_slot()
    if not accepted:
        _append_mcp_resolve_trace(
            resolved_root,
            {
                "trace_id": trace_id,
                "event": "resolver_queue_busy",
                "queue_depth": queue_depth,
                "queue_limit": queue_limit,
            },
        )
        _record_resolve_outcome(trace_id=trace_id, timed_out=False, route="queue_busy", status="rejected")
        return {
            "generated_utc": datetime.now(timezone.utc).isoformat(),
            "trace_id": trace_id,
            "route": "queue_busy",
            "error": "Resolver queue is busy.",
            "queue_depth": queue_depth,
            "queue_limit": queue_limit,
            "hint": "Retry shortly or narrow the question with file_path/symbol/selection.",
        }

    timeout_seconds, timeout_profile, has_editor_context, explicit_deep = _select_resolve_timeout(
        question,
        file_path,
        symbol,
        selection,
    )
    _append_mcp_resolve_trace(
        resolved_root,
        {
            "trace_id": trace_id,
            "event": "request_received",
            "question_len": len(question or ""),
            "has_file_path": bool(file_path),
            "has_symbol": bool(symbol),
            "has_selection": bool(selection),
            "has_editor_context": has_editor_context,
            "explicit_deep_intent": explicit_deep,
            "timeout_profile": timeout_profile,
            "timeout_seconds": timeout_seconds,
            "against_snapshot_id": against_snapshot_id,
        },
    )

    if has_editor_context and not explicit_deep and timeout_seconds <= 10:
        _append_mcp_resolve_trace(
            resolved_root,
            {
                "trace_id": trace_id,
                "event": "resolver_preflight_guard",
                "reason": "low_timeout_editor_context",
                "timeout_profile": timeout_profile,
                "timeout_seconds": timeout_seconds,
            },
        )
        _record_resolve_outcome(trace_id=trace_id, timed_out=False, route="agent_handoff", status="preflight_guard")
        _release_resolve_slot()
        return {
            "generated_utc": datetime.now(timezone.utc).isoformat(),
            "trace_id": trace_id,
            "route": "agent_handoff",
            "error": "Resolve preflight guard bypassed deep analysis under low timeout budget.",
            "timeout_seconds": timeout_seconds,
            "timeout_profile": timeout_profile,
            "hint": (
                "Retry with explicit deep intent (for example, include 'drill' or 'fresh delta') "
                "or increase SEMANTIC_MCP_RESOLVE_TIMEOUT_DEEP_SECONDS."
            ),
        }

    started_at = time.perf_counter()
    timed_out = False
    try:
        def _emit_resolver_step(event: str, payload: dict[str, Any]) -> None:
            _append_mcp_resolve_trace(
                resolved_root,
                {
                    "trace_id": trace_id,
                    "event": event,
                    **payload,
                },
            )

        _append_mcp_resolve_trace(
            resolved_root,
            {
                "trace_id": trace_id,
                "event": "resolver_submit",
                "timeout_profile": timeout_profile,
                "timeout_seconds": timeout_seconds,
            },
        )
        future = _RESOLVE_EXECUTOR.submit(
            resolve_question_with_policy,
            resolved_root,
            question,
            file_path,
            symbol,
            selection,
            against_snapshot_id,
            trace_id,
            _emit_resolver_step,
        )

        def _trace_late_completion(done_future) -> None:
            nonlocal timed_out
            if not timed_out:
                return
            try:
                late_result = done_future.result()
                payload = _build_late_resolver_completion_trace(
                    trace_id,
                    started_at=started_at,
                    timed_out_before_completion=True,
                    result=late_result,
                )
            except Exception as exc:
                payload = _build_late_resolver_completion_trace(
                    trace_id,
                    started_at=started_at,
                    timed_out_before_completion=True,
                    error=exc,
                )
            _append_mcp_resolve_trace(resolved_root, payload)

        future.add_done_callback(_trace_late_completion)
        try:
            result = future.result(timeout=timeout_seconds)
            _append_mcp_resolve_trace(
                resolved_root,
                {
                    "trace_id": trace_id,
                    "event": "resolver_result",
                    "elapsed_seconds": round(max(time.perf_counter() - started_at, 0.0), 6),
                    "timeout_profile": timeout_profile,
                    "timeout_seconds": timeout_seconds,
                    "route": result.get("route"),
                    "classification": (result.get("classification") or {}).get("category"),
                },
            )
            _record_resolve_outcome(
                trace_id=trace_id,
                timed_out=False,
                route=str(result.get("route", "unknown")),
                status="completed",
            )
            return result
        except FuturesTimeoutError:
            timed_out = True
            _append_mcp_resolve_trace(
                resolved_root,
                {
                    "trace_id": trace_id,
                    "event": "resolver_timeout",
                    "elapsed_seconds": round(max(time.perf_counter() - started_at, 0.0), 6),
                    "timeout_profile": timeout_profile,
                    "timeout_seconds": timeout_seconds,
                },
            )
            _record_resolve_outcome(trace_id=trace_id, timed_out=True, route="timeout", status="timeout")
            return {
                "generated_utc": datetime.now(timezone.utc).isoformat(),
                "trace_id": trace_id,
                "route": "timeout",
                "error": "resolve_question timed out before a policy result was returned.",
                "timeout_profile": timeout_profile,
                "timeout_seconds": timeout_seconds,
                "hint": "Retry with file_path/symbol/selection for a narrower drill route.",
            }
        except Exception as exc:
            _append_mcp_resolve_trace(
                resolved_root,
                {
                    "trace_id": trace_id,
                    "event": "resolver_error",
                    "error": str(exc),
                },
            )
            _record_resolve_outcome(trace_id=trace_id, timed_out=False, route="error", status="error")
            return {
                "generated_utc": datetime.now(timezone.utc).isoformat(),
                "trace_id": trace_id,
                "route": "error",
                "error": f"resolve_question failed: {exc}",
            }
    finally:
        _release_resolve_slot()


def create_mcp_server(project_root: Path):
    # Lazy import: only load the mcp package when the MCP server is actually
    # being started.  All other CLI paths remain unaffected.
    from mcp.server.fastmcp import FastMCP  # noqa: PLC0415
    resolved_root = project_root.resolve()

    # Start the session-lifetime egress monitor before any tool is registered.
    global _SESSION_EGRESS_MONITOR
    _SESSION_EGRESS_MONITOR = _SessionEgressMonitor(
        flush_path=resolved_root / SESSION_EGRESS_LIVE_PATH,
    )
    _SESSION_EGRESS_MONITOR.start()

    server = FastMCP(
        name="semantic-cache-engine",
        instructions=(
            "Local-first semantic cache tools for session bootstrap, shadow delta runs, "
            "and SQLite cache inspection."
        ),
    )

    @server.tool(description="Return the latest shadow session summary, optionally bootstrapping if no report exists.", structured_output=False)
    def session_context(bootstrap_if_missing: bool = True) -> dict[str, Any]:
        return _run_tracked_tool(
            resolved_root,
            "session_context",
            {"bootstrap_if_missing": bootstrap_if_missing},
            lambda: load_session_context(resolved_root, bootstrap_if_missing=bootstrap_if_missing),
        )

    @server.tool(description="Run a fresh shadow delta session and return summary, provider usage, and runtime metadata.", structured_output=False)
    def run_shadow_delta(
        against_snapshot_id: str | None = None,
        playbook: str = "session-readiness",
        live_provider: str = "openai-compatible",
        provider_hydration: str = "probe",
    ) -> dict[str, Any]:
        return _run_tracked_tool(
            resolved_root,
            "run_shadow_delta",
            {
                "against_snapshot_id": against_snapshot_id,
                "playbook": playbook,
                "live_provider": live_provider,
                "provider_hydration": provider_hydration,
            },
            lambda: run_shadow_session(
                resolved_root,
                against_snapshot_id=against_snapshot_id,
                playbook=playbook,
                live_provider=live_provider,
                provider_hydration=provider_hydration,
            ),
        )

    @server.tool(description="Summarize local SQLite cache entries by type, including count and recent records.", structured_output=False)
    def sqlite_cache_summary(entry_type: str = "reasoning-card", limit: int = 5) -> dict[str, Any]:
        return _run_tracked_tool(
            resolved_root,
            "sqlite_cache_summary",
            {"entry_type": entry_type, "limit": limit},
            lambda: load_sqlite_cache_summary(resolved_root, entry_type=entry_type, limit=limit),
        )

    @server.tool(description="Recall reasoning cards by task intent and scope fingerprint.", structured_output=False)
    def reasoning_recall(task_intent: str, scope_fingerprint: str, limit: int = 5) -> dict[str, Any]:
        return _run_tracked_tool(
            resolved_root,
            "reasoning_recall",
            {
                "task_intent": task_intent,
                "scope_fingerprint": scope_fingerprint,
                "limit": limit,
            },
            lambda: load_reasoning_recall(
                resolved_root,
                task_intent=task_intent,
                scope_fingerprint=scope_fingerprint,
                limit=limit,
            ),
        )

    @server.tool(
        description=(
            "Return a reasoning card summary for a file path when a high-confidence card "
            "(score >= min_confidence, default 0.80) exists for that module scope. "
            "When a card is found the file is NOT read — token cost is near-zero. "
            "Falls through to the actual file content when no qualifying card is found. "
            "Use this instead of read_file for well-reasoned source modules."
        ),
        structured_output=False,
    )
    def get_file_or_card(path: str, min_confidence: float = 0.80) -> dict[str, Any]:
        return _run_tracked_tool(
            resolved_root,
            "get_file_or_card",
            {"path": path, "min_confidence": min_confidence},
            lambda: load_file_or_card(resolved_root, path=path, min_confidence=min_confidence),
        )

    @server.tool(
        description=(
            "Commit a reasoning card payload into local cache for future recall. "
            "Pass context_file_path (workspace-relative path to the source file being described) "
            "to automatically wire a file evidence anchor — improves graph traversal and "
            "staleness invalidation when that file is later modified."
        ),
        structured_output=False,
    )
    def reasoning_commit(card_payload: dict[str, Any], source: str = "mcp", context_file_path: str = "") -> dict[str, Any]:
        _payload = dict(card_payload)
        if context_file_path and context_file_path.strip():
            anchors = list(_payload.get("evidence_anchors") or [])
            if not any(isinstance(a, dict) and a.get("path") == context_file_path.strip() for a in anchors):
                anchors.append({"anchor_type": "file", "path": context_file_path.strip()})
            _payload["evidence_anchors"] = anchors
        return _run_tracked_tool(
            resolved_root,
            "reasoning_commit",
            {
                "card_payload": _payload,
                "source": source,
            },
            lambda: save_reasoning_card(
                resolved_root,
                card_payload=_payload,
                source=source,
            ),
        )

    @server.tool(
        description=(
            "Commit multiple reasoning cards in a single round-trip. "
            "Preferred over repeated reasoning_commit calls when an answer spans "
            "multiple files or functions. Each card must have its own focused "
            "scope_fingerprint at module or module::symbol granularity."
        ),
        structured_output=False,
    )
    def reasoning_commit_batch(cards: list[dict[str, Any]], source: str = "mcp") -> dict[str, Any]:
        return _run_tracked_tool(
            resolved_root,
            "reasoning_commit_batch",
            {
                "cards": cards,
                "source": source,
            },
            lambda: save_reasoning_cards_batch(
                resolved_root,
                cards=cards,
                source=source,
            ),
        )

    @server.tool(description="Build a familiarization pack in scout, route, or drill mode for the workspace.", structured_output=False)
    def familiarization_pack(
        mode: str = "scout",
        against_snapshot_id: str | None = None,
        query: str | None = None,
    ) -> dict[str, Any]:
        return _run_tracked_tool(
            resolved_root,
            "familiarization_pack",
            {
                "mode": mode,
                "against_snapshot_id": against_snapshot_id,
                "query": query,
            },
            lambda: load_familiarization_pack(
                resolved_root,
                mode=mode,
                against_snapshot_id=against_snapshot_id,
                query=query,
            ),
        )

    @server.tool(description="Return rolling token and runtime metrics with top operation spend categories.", structured_output=False)
    def metrics_report(window_days: int = 7, top_n: int = 3) -> dict[str, Any]:
        """Return rolling token/runtime metrics and top spend operations for the current workspace."""
        return _run_tracked_tool(
            resolved_root,
            "metrics_report",
            {"window_days": window_days, "top_n": top_n},
            lambda: load_metrics_report(
                resolved_root,
                window_days=window_days,
                top_n=top_n,
            ),
        )

    @server.tool(description="Return resolver queue depth, timeout rate, and current budget configuration.", structured_output=False)
    def engine_health() -> dict[str, Any]:
        return _run_tracked_tool(
            resolved_root,
            "engine_health",
            {},
            lambda: load_engine_health(resolved_root),
        )

    @server.tool(description="Launch the metrics dashboard with optional host, port, and browser controls.", structured_output=False)
    def metrics_dashboard(
        host: str = "127.0.0.1",
        port: int = 8501,
        open_browser: bool = False,
    ) -> dict[str, Any]:
        """Launch the metrics dashboard with optional host, port, and browser behavior overrides."""
        return _run_tracked_tool(
            resolved_root,
            "metrics_dashboard",
            {"host": host, "port": port, "open_browser": open_browser},
            lambda: launch_metrics_dashboard(
                resolved_root,
                host=host,
                port=port,
                open_browser=open_browser,
            ),
        )

    @server.tool(description="One-click dashboard launch at default local URL with browser auto-open.", structured_output=False)
    def show_dashboard() -> dict[str, Any]:
        """One-click launch for the local metrics dashboard using default URL and browser open behavior."""
        return _run_tracked_tool(
            resolved_root,
            "show_dashboard",
            {},
            lambda: show_metrics_dashboard(resolved_root),
        )

    @server.tool(description="Resolve a normal developer repo question using deterministic recall/scout/drill/fresh-delta policy.", structured_output=False)
    def resolve_question(
        question: str,
        file_path: str | None = None,
        symbol: str | None = None,
        selection: str | None = None,
        against_snapshot_id: str | None = None,
    ) -> dict[str, Any]:
        return _run_tracked_tool(
            resolved_root,
            "resolve_question",
            {
                "question": question,
                "file_path": file_path,
                "symbol": symbol,
                "selection": selection,
                "against_snapshot_id": against_snapshot_id,
            },
            lambda: resolve_question_with_shared_executor(
                resolved_root,
                question,
                file_path=file_path,
                symbol=symbol,
                selection=selection,
                against_snapshot_id=against_snapshot_id,
            ),
        )

    # ------------------------------------------------------------------
    # DRQS graph query tools (Phase 8)
    # ------------------------------------------------------------------

    @server.tool(
        description="Return the dependency artifact (depends_on metadata) for a chunk node in the reasoning graph.",
        structured_output=False,
    )
    def get_chunk_artifact(chunk_id: str) -> dict[str, Any]:
        def _fn() -> dict[str, Any]:
            from .graph_store import GraphStore
            from .directed_query import DirectedQueryRouter
            gs = GraphStore(resolved_root)
            router = DirectedQueryRouter(gs)
            result = router.get_chunk_artifact(chunk_id)
            return {"status": result.status, "data": result.data, "reason": result.reason, "target_id": result.target_id}
        return _run_tracked_tool(resolved_root, "get_chunk_artifact", {"chunk_id": chunk_id}, _fn)

    @server.tool(
        description="Return reasoning cards related to a given card_id within N hops in the reasoning graph.",
        structured_output=False,
    )
    def get_related_cards(card_id: str, hops: int = 1) -> dict[str, Any]:
        def _fn() -> dict[str, Any]:
            from .graph_store import GraphStore
            from .directed_query import DirectedQueryRouter
            gs = GraphStore(resolved_root)
            router = DirectedQueryRouter(gs)
            result = router.get_related_cards(card_id, hops=hops)
            return {"status": result.status, "data": result.data, "reason": result.reason, "metadata": result.metadata}
        return _run_tracked_tool(resolved_root, "get_related_cards", {"card_id": card_id, "hops": hops}, _fn)

    @server.tool(
        description="Return all reasoning cards in the graph that match a given scope_fingerprint.",
        structured_output=False,
    )
    def get_cards_for_scope(scope_fingerprint: str, limit: int = 5) -> dict[str, Any]:
        def _fn() -> dict[str, Any]:
            from .graph_store import GraphStore
            from .directed_query import DirectedQueryRouter
            gs = GraphStore(resolved_root)
            router = DirectedQueryRouter(gs)
            result = router.get_cards_for_scope(scope_fingerprint, limit=limit)
            return {"status": result.status, "data": result.data, "reason": result.reason, "metadata": result.metadata}
        return _run_tracked_tool(resolved_root, "get_cards_for_scope", {"scope_fingerprint": scope_fingerprint, "limit": limit}, _fn)

    @server.tool(
        description="Follow supersession edges to return the full card history chain from newest to oldest.",
        structured_output=False,
    )
    def get_supersession_chain(card_id: str, max_depth: int = 10) -> dict[str, Any]:
        def _fn() -> dict[str, Any]:
            from .graph_store import GraphStore
            from .directed_query import DirectedQueryRouter
            gs = GraphStore(resolved_root)
            router = DirectedQueryRouter(gs)
            result = router.get_supersession_chain(card_id, max_depth=max_depth)
            return {"status": result.status, "data": result.data, "reason": result.reason, "metadata": result.metadata}
        return _run_tracked_tool(resolved_root, "get_supersession_chain", {"card_id": card_id, "max_depth": max_depth}, _fn)

    @server.tool(
        description="Return dependency edges (imports/calls) for a chunk node in the reasoning graph.",
        structured_output=False,
    )
    def get_dependency_edges(chunk_id: str) -> dict[str, Any]:
        def _fn() -> dict[str, Any]:
            from .graph_store import GraphStore
            from .directed_query import DirectedQueryRouter
            gs = GraphStore(resolved_root)
            router = DirectedQueryRouter(gs)
            result = router.get_dependency_edges(chunk_id)
            return {"status": result.status, "data": result.data, "reason": result.reason, "target_id": result.target_id}
        return _run_tracked_tool(resolved_root, "get_dependency_edges", {"chunk_id": chunk_id}, _fn)

    @server.tool(
        description="Return the current session egress monitor summary — all socket connections made since MCP server startup, tagged by tool phase.",
        structured_output=False,
    )
    def egress_report() -> dict[str, Any]:
        return _run_tracked_tool(
            resolved_root,
            "egress_report",
            {},
            lambda: _SESSION_EGRESS_MONITOR.summary() if _SESSION_EGRESS_MONITOR is not None
            else {"error": "egress monitor not active"},
        )

    return server


def _mcp_pid_file(project_root: Path) -> Path:
    return project_root.resolve() / MCP_PID_PATH


def _mcp_lock_file(project_root: Path) -> Path:
    return project_root.resolve() / MCP_LOCK_PATH


def _pid_is_running(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except (OSError, SystemError, ValueError, PermissionError):
        return False
    except BaseException:
        return False
    return True


def _read_mcp_pid(project_root: Path) -> dict[str, Any] | None:
    pid_file = _mcp_pid_file(project_root)
    if not pid_file.exists():
        return None

    try:
        payload = json.loads(pid_file.read_text(encoding="utf-8"))
    except Exception:
        return None

    if not isinstance(payload, dict):
        return None
    return payload


def _write_mcp_pid(project_root: Path) -> dict[str, Any]:
    pid_file = _mcp_pid_file(project_root)
    pid_file.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "pid": os.getpid(),
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "project_root": str(project_root.resolve()),
        "command": " ".join(sys.argv),
    }
    pid_file.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return payload


def _remove_mcp_pid(project_root: Path) -> None:
    pid_file = _mcp_pid_file(project_root)
    if pid_file.exists():
        pid_file.unlink()


def _read_mcp_lock(project_root: Path) -> dict[str, Any] | None:
    lock_file = _mcp_lock_file(project_root)
    if not lock_file.exists():
        return None

    try:
        payload = json.loads(lock_file.read_text(encoding="utf-8"))
    except Exception:
        return None

    if not isinstance(payload, dict):
        return None
    return payload


def _release_mcp_lock(project_root: Path) -> None:
    lock_file = _mcp_lock_file(project_root)
    if lock_file.exists():
        lock_file.unlink()


def _acquire_mcp_lock(project_root: Path) -> tuple[bool, dict[str, Any] | None]:
    lock_file = _mcp_lock_file(project_root)
    lock_file.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "pid": os.getpid(),
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "project_root": str(project_root.resolve()),
        "command": " ".join(sys.argv),
    }

    for _ in range(2):
        try:
            descriptor = os.open(str(lock_file), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2)
            return True, payload
        except FileExistsError:
            holder = _read_mcp_lock(project_root)
            holder_pid = int((holder or {}).get("pid") or 0)
            if holder_pid > 0 and not _pid_is_running(holder_pid):
                _release_mcp_lock(project_root)
                continue
            return False, holder

    return False, _read_mcp_lock(project_root)


def mcp_server_status(project_root: Path) -> dict[str, Any]:
    payload = _read_mcp_pid(project_root)
    lock_payload = _read_mcp_lock(project_root)
    lock_pid = int((lock_payload or {}).get("pid") or 0)
    lock_running = lock_pid > 0 and _pid_is_running(lock_pid)
    if payload is None:
        return {
            "running": lock_running,
            "pid": lock_pid if lock_running else None,
            "pid_file": str(_mcp_pid_file(project_root)),
            "lock_file": str(_mcp_lock_file(project_root)),
        }

    pid = int(payload.get("pid") or 0)
    running = _pid_is_running(pid)
    return {
        "running": running or lock_running,
        "pid": pid if running else (lock_pid if lock_running else None),
        "pid_file": str(_mcp_pid_file(project_root)),
        "lock_file": str(_mcp_lock_file(project_root)),
        "started_utc": payload.get("started_utc"),
        "project_root": payload.get("project_root"),
        "command": payload.get("command"),
    }


def stop_mcp_server(project_root: Path, wait_seconds: float = 2.0) -> dict[str, Any]:
    status = mcp_server_status(project_root)
    if not status.get("running", False):
        _remove_mcp_pid(project_root)
        _release_mcp_lock(project_root)
        status["stopped"] = False
        status["verified_closed"] = True
        return status

    pid = int(status.get("pid") or 0)
    killed = False
    if pid > 0:
        try:
            os.kill(pid, signal.SIGTERM)
            killed = True
        except OSError:
            killed = False

    deadline = time.time() + max(wait_seconds, 0.0)
    while time.time() < deadline:
        if not _pid_is_running(pid):
            break
        time.sleep(0.05)

    verified_closed = not _pid_is_running(pid)
    if verified_closed:
        _remove_mcp_pid(project_root)
        _release_mcp_lock(project_root)

    return {
        "running": not verified_closed,
        "pid": None if verified_closed else pid,
        "pid_file": str(_mcp_pid_file(project_root)),
        "lock_file": str(_mcp_lock_file(project_root)),
        "stopped": killed,
        "verified_closed": verified_closed,
    }


def verify_mcp_closed(project_root: Path) -> dict[str, Any]:
    status = mcp_server_status(project_root)
    verified_closed = not status.get("running", False)
    if verified_closed:
        _remove_mcp_pid(project_root)
        _release_mcp_lock(project_root)
    return {
        "verified_closed": verified_closed,
        "running": status.get("running", False),
        "pid": status.get("pid"),
        "pid_file": status.get("pid_file"),
        "lock_file": status.get("lock_file"),
    }


def run_mcp_server(project_root: Path) -> None:
    acquired, lock_payload = _acquire_mcp_lock(project_root)
    if not acquired:
        lock_pid = int((lock_payload or {}).get("pid") or 0)
        print(
            json.dumps(
                {
                    "event": "mcp_already_running",
                    "pid": lock_pid if lock_pid > 0 else None,
                    "pid_file": str(_mcp_pid_file(project_root)),
                    "lock_file": str(_mcp_lock_file(project_root)),
                    "hint": "Use 'engine mcp --path <repo> --stop' to close existing server.",
                }
            ),
            file=sys.stderr,
            flush=True,
        )
        return

    registration = _write_mcp_pid(project_root)
    print(
        json.dumps(
            {
                "event": "mcp_started",
                "instance": 1,
                "pid": registration["pid"],
                "pid_file": str(_mcp_pid_file(project_root)),
                "lock_file": str(_mcp_lock_file(project_root)),
            }
        ),
        file=sys.stderr,
        flush=True,
    )
    warm_start_result = warm_start_if_bundle_exists(project_root)
    if warm_start_result is not None:
        print(
            json.dumps(
                {
                    "event": "warm_start_complete",
                    "committed": warm_start_result["committed"],
                    "skipped": warm_start_result["skipped"],
                    "bundle_id": warm_start_result["bundle_id"],
                }
            ),
            file=sys.stderr,
            flush=True,
        )

    server = create_mcp_server(project_root)
    try:
        server.run()
    except BaseException as exc:
        if _is_graceful_shutdown_exception(exc):
            # Client-side transport teardown should not surface as a crash.
            return
        raise
    finally:
        _remove_mcp_pid(project_root)
        _release_mcp_lock(project_root)


def _is_graceful_shutdown_exception(exc: BaseException) -> bool:
    if isinstance(exc, (KeyboardInterrupt, BrokenPipeError, asyncio.CancelledError)):
        return True

    if isinstance(exc, BaseExceptionGroup):
        return all(_is_graceful_shutdown_exception(item) for item in exc.exceptions)

    return False