"""Session export: build a privacy-scrubbed metric payload that proves the
current build, then bundle it as a shareable zip.

The payload deliberately separates two kinds of evidence:

* ``observed``        -- the REAL metrics measured in *this* session/repo over
                         the window (the in-the-wild signal an alpha tester
                         produces on a codebase the founder never authored).
* ``claims_baseline`` -- a compact summary of the committed claims ledger,
                         clearly labelled as the founder, same-machine baseline
                         the observed numbers can be compared against.

Nothing here contains source code, file contents, or absolute paths -- the
repo identity is reduced to an anonymized fingerprint.
"""

from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import shutil
from typing import Any
import zipfile

from .phase13_metrics import build_metrics_report
from .reason_bundle import export_reason_bundle, verify_reason_bundle

EXPORT_SCHEMA_VERSION = "session-export-v1"

# Claims whose `result` block carries a clean structured ratio we can surface
# directly (no prose parsing). Everything else is shown verbatim from `number`.
_STRUCTURED_RATIO_CLAIMS = {"1", "1b"}


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _utc_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def load_claims_ledger(project_root: Path) -> dict[str, Any] | None:
    """Load the committed claims ledger, or None if it is absent/unreadable."""
    path = project_root.resolve() / "data" / "evidence" / "claims-ledger.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def summarize_claims(ledger: dict[str, Any] | None) -> dict[str, Any]:
    """Reduce the ledger to a compact, display-friendly summary.

    Returns a dict with the build provenance, a per-claim list (id/title/label/
    number/status), and a verified-claim count. Long ``number`` strings are kept
    verbatim because they carry the honest measured values and caveats.
    """
    if not isinstance(ledger, dict):
        return {"available": False, "claims": [], "done_count": 0, "total_count": 0}

    raw_claims = ledger.get("claims")
    claims: list[dict[str, Any]] = []
    if isinstance(raw_claims, list):
        for entry in raw_claims:
            if not isinstance(entry, dict):
                continue
            claims.append(
                {
                    "id": str(entry.get("id")),
                    "title": entry.get("title"),
                    "label": entry.get("current_label"),
                    "number": entry.get("number"),
                    "status": entry.get("status"),
                }
            )

    done_count = sum(1 for c in claims if c.get("status") == "done")
    return {
        "available": True,
        "build": ledger.get("build", {}),
        "generated_utc": ledger.get("generated_utc"),
        "claims": claims,
        "done_count": done_count,
        "total_count": len(claims),
    }


def claim_ratio(ledger: dict[str, Any] | None, claim_id: str) -> float | None:
    """Return ``result.savings_ratio_pct`` for a structured-ratio claim, if present."""
    if not isinstance(ledger, dict):
        return None
    for entry in ledger.get("claims", []) or []:
        if not isinstance(entry, dict):
            continue
        if str(entry.get("id")) != claim_id:
            continue
        result = entry.get("result")
        if isinstance(result, dict):
            value = result.get("savings_ratio_pct")
            if isinstance(value, (int, float)):
                return float(value)
    return None


def _repo_fingerprint(project_root: Path) -> dict[str, Any]:
    """Anonymized repo identity -- never the path or any source content."""
    resolved = project_root.resolve()
    digest = hashlib.sha256(str(resolved).encode("utf-8")).hexdigest()[:16]
    name_digest = hashlib.sha256(resolved.name.encode("utf-8")).hexdigest()[:12]
    return {
        "repo_fingerprint": digest,
        "repo_name_fingerprint": name_digest,
    }


def _latest_scale_rollup(project_root: Path) -> dict[str, Any] | None:
    """Most recent scale roll-up for this workspace, if one was produced."""
    scale_dir = project_root.resolve() / ".reason" / "runs" / "scale"
    if not scale_dir.exists():
        return None
    rollups = sorted(scale_dir.glob("scale-rollup-*.json"))
    if not rollups:
        return None
    try:
        return json.loads(rollups[-1].read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def _observed_metrics(project_root: Path, window_days: int) -> dict[str, Any]:
    """Real measured window KPIs for this session via the metrics report."""
    report = build_metrics_report(project_root=project_root, window_days=window_days).to_dict()
    totals = report.get("totals", {}) if isinstance(report.get("totals"), dict) else {}
    return {
        "window_days": report.get("window_days", window_days),
        "runs_in_window": report.get("runs_in_window", 0),
        "metric_source": report.get("metric_source"),
        "projected_saved_ratio": totals.get("projected_saved_ratio"),
        "projected_saved_tokens_total": totals.get("projected_saved_tokens_total"),
        "measured_provider_tokens_total": totals.get("measured_provider_tokens_total"),
        "measured_saved_tokens_total": totals.get("measured_saved_tokens_total"),
        "measured_run_count": totals.get("measured_run_count"),
        "semantic_average_similarity": totals.get("semantic_average_similarity"),
        "semantic_pass_count": totals.get("semantic_pass_count"),
        "semantic_scored_pair_count": totals.get("semantic_scored_pair_count"),
    }


def build_session_metrics_payload(
    project_root: Path,
    session_id: str | None = None,
    window_days: int = 7,
) -> dict[str, Any]:
    """Assemble the full (scrubbed) session metric payload."""
    resolved = project_root.resolve()
    ledger = load_claims_ledger(resolved)
    claims_summary = summarize_claims(ledger)

    payload: dict[str, Any] = {
        "manifest": {
            "schema_version": EXPORT_SCHEMA_VERSION,
            "generated_utc": _now_iso(),
            "session_id": session_id,
            "engine_build": claims_summary.get("build", {}),
        },
        "environment": {
            **_repo_fingerprint(resolved),
            "platform": platform.system(),
            "python_version": platform.python_version(),
        },
        "observed": _observed_metrics(resolved, window_days),
        "claims_baseline": {
            "note": "Reference claims ledger (committed baseline) -- not this session's measurement. See 'observed' for this session's metrics.",
            "generated_utc": claims_summary.get("generated_utc"),
            "done_count": claims_summary.get("done_count", 0),
            "total_count": claims_summary.get("total_count", 0),
            "headline": {
                "session_start_savings_vs_fullrepo_pct": claim_ratio(ledger, "1"),
                "session_start_savings_vs_rag_pct": claim_ratio(ledger, "1b"),
            },
            "claims": claims_summary.get("claims", []),
        },
    }

    scale = _latest_scale_rollup(resolved)
    if scale is not None:
        payload["scale"] = scale

    return payload


def export_session_bundle(
    project_root: Path,
    session_id: str | None = None,
    window_days: int = 7,
) -> dict[str, Any]:
    """Build the metric payload and write a privacy-scrubbed zip + JSON manifest.

    The zip also embeds a freshly exported ``.reason`` bundle (cards + graph
    shards + manifest), and the payload carries a ``reason_bundle`` proof that
    re-hashes every shard against the manifest so a recipient can confirm the
    bundle is internally consistent.

    Returns a dict with ``status`` (``ok`` on success), the written paths, and
    the metric payload itself so callers/tests can inspect it without unzipping.
    """
    resolved = project_root.resolve()
    try:
        payload = build_session_metrics_payload(
            project_root=resolved,
            session_id=session_id,
            window_days=window_days,
        )
    except Exception as exc:  # noqa: BLE001 -- surface as a structured error, never crash the CLI
        return {"status": "error", "error": f"{type(exc).__name__}: {exc}"}

    stamp = session_id.strip() if session_id and session_id.strip() else _utc_stamp()
    safe_stamp = "".join(ch for ch in stamp if ch.isalnum() or ch in {"-", "_"}) or _utc_stamp()

    out_dir = resolved / ".reason" / "runs" / "exports"
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = out_dir / f"session-export-{safe_stamp}.json"
    bundle_path = out_dir / f"session-export-{safe_stamp}.zip"

    # Build + verify the reason bundle so its shards/manifest ship inside the zip.
    bundle_dir = out_dir / f"reason-bundle-{safe_stamp}"
    reason_files = _build_and_verify_reason_bundle(resolved, bundle_dir, payload)

    serialized = json.dumps(payload, indent=2)
    manifest_path.write_text(serialized, encoding="utf-8")
    with zipfile.ZipFile(bundle_path, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
        bundle.writestr("session-metrics.json", serialized)
        for arcname, file_path in reason_files:
            bundle.write(file_path, arcname)
        egress_path = resolved / ".reason" / "runs" / "egress" / "session-egress-live.jsonl"
        if egress_path.exists():
            bundle.write(egress_path, "session-egress-live.jsonl")

    # The on-disk staging copy is redundant once embedded in the zip.
    shutil.rmtree(bundle_dir, ignore_errors=True)

    return {
        "status": "ok",
        "manifest_path": str(manifest_path),
        "bundle_path": str(bundle_path),
        "session_id": session_id,
        "window_days": window_days,
        "metrics": payload,
    }


def _build_and_verify_reason_bundle(
    project_root: Path,
    bundle_dir: Path,
    payload: dict[str, Any],
) -> list[tuple[str, Path]]:
    """Export a .reason bundle, verify its hashes, and record the proof in *payload*.

    Returns a list of ``(arcname, file_path)`` pairs to embed under
    ``reason_bundle/`` in the session zip. On any failure the payload still gets
    a structured ``reason_bundle`` block (``packaged: False``) and no files.
    """
    try:
        summary = export_reason_bundle(out_dir=bundle_dir, project_root=project_root)
        proof = verify_reason_bundle(bundle_dir)
    except Exception as exc:  # noqa: BLE001 -- never let bundle export break the session export
        payload["reason_bundle"] = {"packaged": False, "error": f"{type(exc).__name__}: {exc}"}
        return []

    payload["reason_bundle"] = {
        "packaged": True,
        "verified": bool(proof.get("verified")),
        "bundle_id": proof.get("bundle_id"),
        "schema_version": proof.get("schema_version"),
        "card_count": summary.get("card_count"),
        "reason_shard_count": summary.get("reason_shard_count"),
        "graph_shard_count": summary.get("graph_shard_count"),
        "verification_error": proof.get("error"),
    }

    files: list[tuple[str, Path]] = []
    for file_path in sorted(bundle_dir.rglob("*")):
        if file_path.is_file():
            arcname = "reason_bundle/" + file_path.relative_to(bundle_dir).as_posix()
            files.append((arcname, file_path))
    return files

