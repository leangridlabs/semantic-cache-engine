"""
directed_query.py
=================
Directed Query Actions (DQA) for the DRQS near-miss resolution path.

``DirectedQueryRouter`` exposes 8 typed graph-lookup functions.  Each returns
a ``DQAResult`` with a status code, the raw data payload, and an optional
reason string.  No function raises — callers always get a DQAResult back.

Status codes
------------
``NOT_FOUND``   Node does not exist in the graph store.
``STALE``       Node exists but has stale/missing dependency fingerprint.
``UNTRUSTED``   Node exists but validation_state is not "trusted" or "accepted".
``PARTIAL``     Data returned but some fields are missing or incomplete.
``OK``          Full clean result.

Public API
----------
``DirectedQueryRouter(graph_store)``

``get_chunk_artifact(chunk_id) -> DQAResult``
    Return the artifact for a chunk (dependency metadata).

``get_chunk_dependencies(chunk_id) -> DQAResult``
    Return all chunk→chunk edges for a chunk.

``get_reasoning_card(card_id) -> DQAResult``
    Return a single card node by card_id.

``get_cards_for_scope(scope_fingerprint, limit=5) -> DQAResult``
    Return all cards matching a scope_fingerprint.

``get_cards_for_chunk(chunk_id, limit=5) -> DQAResult``
    Return all cards that have a card→chunk edge to this chunk.

``get_dependency_edges(chunk_id) -> DQAResult``
    Return dependency edges (imports/calls) for a chunk.

``get_supersession_chain(card_id, max_depth=10) -> DQAResult``
    Follow supersession edges to build the full history chain.

``get_related_cards(card_id, hops=1) -> DQAResult``
    Return cards reachable from card_id within N hops.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .graph_store import GraphStore


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------

@dataclass
class DQAResult:
    status: str  # "OK" | "PARTIAL" | "NOT_FOUND" | "STALE" | "UNTRUSTED"
    data: Any = None
    reason: str = ""
    target_id: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.status == "OK"

    @property
    def has_data(self) -> bool:
        return self.data is not None and self.data != [] and self.data != {}


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

class DirectedQueryRouter:
    """8 directed graph-lookup functions with typed DQAResult responses.

    Never raises.  If the graph store is unavailable all calls return
    NOT_FOUND gracefully.
    """

    def __init__(self, graph_store: GraphStore) -> None:
        self._gs = graph_store

    # --- 1 ----------------------------------------------------------------
    def get_chunk_artifact(self, chunk_id: str) -> DQAResult:
        """Return the artifact for a chunk (dependency metadata)."""
        try:
            artifact = self._gs.get_artifact_for_chunk(chunk_id)
            if not artifact:
                return DQAResult(
                    status="NOT_FOUND",
                    target_id=chunk_id,
                    reason=f"No artifact found for chunk {chunk_id[:20]}.",
                )
            dep = str(artifact.get("dependency_fingerprint", "")).strip()
            if not dep:
                return DQAResult(
                    status="STALE",
                    data=artifact,
                    target_id=chunk_id,
                    reason=f"Artifact for chunk {chunk_id[:20]} has no dependency fingerprint.",
                )
            return DQAResult(status="OK", data=artifact, target_id=chunk_id)
        except Exception as exc:
            return DQAResult(
                status="NOT_FOUND",
                target_id=chunk_id,
                reason=f"Graph store error: {exc}",
            )

    # --- 2 ----------------------------------------------------------------
    def get_chunk_dependencies(self, chunk_id: str) -> DQAResult:
        """Return chunk→chunk dependency edges for a chunk."""
        try:
            chunk = self._gs.get_chunk(chunk_id)
            if not chunk:
                return DQAResult(
                    status="NOT_FOUND",
                    target_id=chunk_id,
                    reason=f"Chunk {chunk_id[:20]} not found in graph.",
                )
            edges = self._gs.get_chunk_chunk_edges(chunk_id)
            if not edges:
                return DQAResult(
                    status="PARTIAL",
                    data=[],
                    target_id=chunk_id,
                    reason=f"Chunk {chunk_id[:20]} exists but has no dependency edges.",
                )
            return DQAResult(status="OK", data=edges, target_id=chunk_id)
        except Exception as exc:
            return DQAResult(
                status="NOT_FOUND",
                target_id=chunk_id,
                reason=f"Graph store error: {exc}",
            )

    # --- 3 ----------------------------------------------------------------
    def get_reasoning_card(self, card_id: str) -> DQAResult:
        """Return a single card node by card_id."""
        try:
            card = self._gs.get_card(card_id)
            if not card:
                return DQAResult(
                    status="NOT_FOUND",
                    target_id=card_id,
                    reason=f"Card {card_id[:20]} not found in graph.",
                )
            validation = str(card.get("validation_state", "")).strip()
            if validation not in ("trusted", "accepted", ""):
                return DQAResult(
                    status="UNTRUSTED",
                    data=card,
                    target_id=card_id,
                    reason=f"Card {card_id[:20]} has validation_state='{validation}'.",
                )
            dep = str(card.get("dependency_fingerprint", "")).strip()
            if not dep:
                return DQAResult(
                    status="STALE",
                    data=card,
                    target_id=card_id,
                    reason=f"Card {card_id[:20]} has no dependency fingerprint.",
                )
            return DQAResult(status="OK", data=card, target_id=card_id)
        except Exception as exc:
            return DQAResult(
                status="NOT_FOUND",
                target_id=card_id,
                reason=f"Graph store error: {exc}",
            )

    # --- 4 ----------------------------------------------------------------
    def get_cards_for_scope(self, scope_fingerprint: str, limit: int = 5) -> DQAResult:
        """Return all cards matching a scope_fingerprint."""
        try:
            cards = self._gs.get_cards_for_scope(scope_fingerprint)[:limit]
            if not cards:
                return DQAResult(
                    status="NOT_FOUND",
                    target_id=scope_fingerprint,
                    reason=f"No cards found for scope '{scope_fingerprint}'.",
                )
            return DQAResult(
                status="OK",
                data=cards,
                target_id=scope_fingerprint,
                metadata={"count": len(cards)},
            )
        except Exception as exc:
            return DQAResult(
                status="NOT_FOUND",
                target_id=scope_fingerprint,
                reason=f"Graph store error: {exc}",
            )

    # --- 5 ----------------------------------------------------------------
    def get_cards_for_chunk(self, chunk_id: str, limit: int = 5) -> DQAResult:
        """Return all cards that have a card→chunk edge to this chunk."""
        try:
            cards = self._gs.get_cards_for_chunk(chunk_id)[:limit]
            if not cards:
                return DQAResult(
                    status="NOT_FOUND",
                    target_id=chunk_id,
                    reason=f"No cards found for chunk {chunk_id[:20]}.",
                )
            return DQAResult(
                status="OK",
                data=cards,
                target_id=chunk_id,
                metadata={"count": len(cards)},
            )
        except Exception as exc:
            return DQAResult(
                status="NOT_FOUND",
                target_id=chunk_id,
                reason=f"Graph store error: {exc}",
            )

    # --- 6 ----------------------------------------------------------------
    def get_dependency_edges(self, chunk_id: str) -> DQAResult:
        """Return all dependency edges (imports/calls) for a chunk."""
        # Alias for get_chunk_dependencies with clearer semantics in MCP context.
        return self.get_chunk_dependencies(chunk_id)

    # --- 7 ----------------------------------------------------------------
    def get_supersession_chain(self, card_id: str, max_depth: int = 10) -> DQAResult:
        """Follow supersession edges to build the full history chain.

        Returns a list of card nodes from newest to oldest.
        Stops at max_depth or when a superseded card is not found.
        """
        try:
            chain = self._gs.get_supersession_chain(card_id, max_hops=max_depth)
            if not chain:
                return DQAResult(
                    status="NOT_FOUND",
                    target_id=card_id,
                    reason=f"No supersession chain found for card {card_id[:20]}.",
                )
            return DQAResult(
                status="OK",
                data=chain,
                target_id=card_id,
                metadata={"chain_length": len(chain)},
            )
        except Exception as exc:
            return DQAResult(
                status="NOT_FOUND",
                target_id=card_id,
                reason=f"Graph store error: {exc}",
            )

    # --- 8 ----------------------------------------------------------------
    def get_related_cards(self, card_id: str, hops: int = 1) -> DQAResult:
        """Return cards reachable from card_id within N card→card hops.

        Uses card_card_edges only (shared_scope, semantic_neighbor, etc.).
        Does NOT follow card→chunk or chunk→chunk — use expand() for that.
        """
        try:
            card = self._gs.get_card(card_id)
            if not card:
                return DQAResult(
                    status="NOT_FOUND",
                    target_id=card_id,
                    reason=f"Card {card_id[:20]} not found in graph.",
                )

            visited: set[str] = {card_id}
            frontier: list[str] = [card_id]
            related_cards: list[dict[str, Any]] = []

            for _ in range(max(1, hops)):
                next_frontier: list[str] = []
                for fid in frontier:
                    for edge in self._gs.get_card_card_edges(fid):
                        neighbor_id = (
                            edge["to_card_id"]
                            if edge.get("from_card_id") == fid
                            else edge.get("from_card_id", "")
                        )
                        if neighbor_id and neighbor_id not in visited:
                            visited.add(neighbor_id)
                            next_frontier.append(neighbor_id)
                            n_card = self._gs.get_card(neighbor_id)
                            if n_card:
                                related_cards.append(n_card)
                frontier = next_frontier

            if not related_cards:
                return DQAResult(
                    status="PARTIAL",
                    data=[],
                    target_id=card_id,
                    reason=f"Card {card_id[:20]} has no related cards within {hops} hop(s).",
                )
            return DQAResult(
                status="OK",
                data=related_cards,
                target_id=card_id,
                metadata={"related_count": len(related_cards), "hops": hops},
            )
        except Exception as exc:
            return DQAResult(
                status="NOT_FOUND",
                target_id=card_id,
                reason=f"Graph store error: {exc}",
            )
