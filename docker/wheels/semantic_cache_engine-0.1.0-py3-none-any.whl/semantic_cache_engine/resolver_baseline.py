from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
import os
from pathlib import Path
from time import perf_counter
from typing import Any

from .resolver import resolve_developer_question


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _extract_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _extract_token_metrics(response: dict[str, Any]) -> dict[str, Any]:
    route_payload = response.get("route_payload", {}) if isinstance(response, dict) else {}
    summary = route_payload.get("summary", {}) if isinstance(route_payload, dict) else {}
    debug = route_payload.get("debug", {}) if isinstance(route_payload, dict) else {}
    provider_usage = debug.get("provider_usage", {}) if isinstance(debug, dict) else {}
    provider_hydration_mode = debug.get("provider_hydration_mode") if isinstance(debug, dict) else None

    projected_actual_tokens = _extract_int(summary.get("actual_tokens"))
    projected_saved_tokens = _extract_int(summary.get("saved_tokens"))
    provider_actual_tokens = _extract_int(provider_usage.get("actual_provider_tokens"))
    if provider_actual_tokens is None:
        provider_actual_tokens = _extract_int(provider_usage.get("total_tokens"))
    provider_prompt_tokens = _extract_int(provider_usage.get("prompt_tokens"))
    provider_completion_tokens = _extract_int(provider_usage.get("completion_tokens"))
    provider_captured = bool(provider_usage.get("captured", False))

    measured_provider_tokens = provider_actual_tokens if provider_actual_tokens is not None else 0
    llm_calls_executed = 1 if provider_captured else 0
    measurement_note = "captured_from_provider_usage" if provider_captured else "no_provider_call_observed"

    if response.get("route") == "recall":
        projected_actual_tokens = projected_actual_tokens if projected_actual_tokens is not None else 0
        provider_actual_tokens = provider_actual_tokens if provider_actual_tokens is not None else 0

    return {
        "measured_provider_tokens": measured_provider_tokens,
        "measured_provider_prompt_tokens": provider_prompt_tokens,
        "measured_provider_completion_tokens": provider_completion_tokens,
        "llm_calls_executed": llm_calls_executed,
        "measurement_note": measurement_note,
        "provider_hydration_mode": provider_hydration_mode,
        "projected_actual_tokens": projected_actual_tokens,
        "projected_saved_tokens": projected_saved_tokens,
        "provider_actual_tokens": provider_actual_tokens,
    }


# Per-question timeout for the CLI baseline runner.  The MCP server has its
# own 45-second timeout, but the CLI path has none — on a cold cache with
# thousands of changed files, fresh_delta can run indefinitely.
_BASELINE_QUESTION_TIMEOUT_S = 120.0


def _run_once(
    *,
    project_root: Path,
    question: str,
    against_snapshot_id: str | None,
    trace_id: str,
    timeout_seconds: float = _BASELINE_QUESTION_TIMEOUT_S,
) -> dict[str, Any]:
    started = perf_counter()
    with ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(
            resolve_developer_question,
            project_root=project_root,
            question=question,
            against_snapshot_id=against_snapshot_id,
            trace_id=trace_id,
        )
        try:
            response = future.result(timeout=timeout_seconds)
        except FuturesTimeoutError:
            elapsed_seconds = perf_counter() - started
            return {
                "elapsed_seconds": round(elapsed_seconds, 6),
                "token_metrics": {},
                "response": {
                    "route": "timeout",
                    "error": f"resolver-baseline timed out after {timeout_seconds:.0f}s",
                },
            }
    elapsed_seconds = perf_counter() - started

    return {
        "elapsed_seconds": round(elapsed_seconds, 6),
        "token_metrics": _extract_token_metrics(response),
        "response": response,
    }


@dataclass(frozen=True)
class ResolverBaselineComparison:
    run_id: str
    created_utc: str
    question: str
    against_snapshot_id: str | None
    provider_hydration_mode: str
    checks: dict[str, bool]
    forced_true_agent: dict[str, Any]
    normal_mode: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def run_resolver_baseline_comparison(
    project_root: Path,
    *,
    question: str,
    against_snapshot_id: str | None = None,
    provider_hydration: str = "probe",
) -> ResolverBaselineComparison:
    resolved_root = project_root.resolve()
    run_id = f"resolver-baseline-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"

    hydration_mode = provider_hydration if provider_hydration in {"probe", "full-repo"} else "probe"

    previous_override = os.environ.get("SEMANTIC_RESOLVER_FORCE_TRUE_AGENT_SESSION")
    previous_hydration = os.environ.get("SEMANTIC_RESOLVER_PROVIDER_HYDRATION")
    try:
        os.environ["SEMANTIC_RESOLVER_FORCE_TRUE_AGENT_SESSION"] = "1"
        os.environ["SEMANTIC_RESOLVER_PROVIDER_HYDRATION"] = hydration_mode
        forced = _run_once(
            project_root=resolved_root,
            question=question,
            against_snapshot_id=against_snapshot_id,
            trace_id=f"{run_id}-forced",
        )
    finally:
        if previous_override is None:
            os.environ.pop("SEMANTIC_RESOLVER_FORCE_TRUE_AGENT_SESSION", None)
        else:
            os.environ["SEMANTIC_RESOLVER_FORCE_TRUE_AGENT_SESSION"] = previous_override
        if previous_hydration is None:
            os.environ.pop("SEMANTIC_RESOLVER_PROVIDER_HYDRATION", None)
        else:
            os.environ["SEMANTIC_RESOLVER_PROVIDER_HYDRATION"] = previous_hydration

    normal = _run_once(
        project_root=resolved_root,
        question=question,
        against_snapshot_id=against_snapshot_id,
        trace_id=f"{run_id}-normal",
    )

    forced_response = forced["response"]
    normal_response = normal["response"]
    normal_recall = normal_response.get("recall", {}) if isinstance(normal_response, dict) else {}
    normal_trace = normal_response.get("decision_trace", []) if isinstance(normal_response, dict) else []

    forced_memory_commit = forced_response.get("memory_commit", {}) if isinstance(forced_response, dict) else {}
    forced_reasoning_saved = (
        isinstance(forced_memory_commit, dict)
        and forced_memory_commit.get("status") == "committed"
        and forced_memory_commit.get("entry_type") == "reasoning-card"
    )
    normal_local_memory_first = (
        isinstance(normal_recall, dict)
        and int(normal_recall.get("candidate_count", 0)) > 0
        and any(item.get("step") == "recall" for item in normal_trace if isinstance(item, dict))
    )

    checks = {
        "forced_mode_enabled": bool(forced_response.get("route_payload", {}).get("forced_true_agent_session", False)),
        "forced_mode_not_handoff": forced_response.get("route") != "agent_handoff",
        "forced_mode_reasoning_saved": forced_reasoning_saved,
        "normal_mode_memory_first": normal_local_memory_first,
    }

    return ResolverBaselineComparison(
        run_id=run_id,
        created_utc=_utc_now(),
        question=question,
        against_snapshot_id=against_snapshot_id,
        provider_hydration_mode=hydration_mode,
        checks=checks,
        forced_true_agent=forced,
        normal_mode=normal,
    )


def resolver_baseline_comparison_to_json(
    project_root: Path,
    *,
    question: str,
    against_snapshot_id: str | None = None,
    provider_hydration: str = "probe",
) -> str:
    result = run_resolver_baseline_comparison(
        project_root,
        question=question,
        against_snapshot_id=against_snapshot_id,
        provider_hydration=provider_hydration,
    )
    return json.dumps(result.to_dict(), indent=2)
