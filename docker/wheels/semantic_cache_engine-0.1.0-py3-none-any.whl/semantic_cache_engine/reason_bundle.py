"""
reason_bundle.py
================
Import pipeline and warm-start hook for .reason v1 bundles.

Public API
----------
``import_reason_bundle(bundle_dir, project_root)``
    Reads a .reason bundle, verifies shard hashes, and commits every card into
    the local cache via ``commit_reasoning_card``.  Fully idempotent — safe to
    re-import the same bundle; existing cards are updated in place using the
    same chunk_id derivation as the original commit path.

``warm_start_if_bundle_exists(project_root)``
    Convenience wrapper for engine startup.  Detects a bundle under
    ``<project_root>/reason_bundle/`` and imports it if present; no-ops on cold
    starts.  Returns the import summary or ``None``.
"""

from __future__ import annotations

import hashlib
import json
import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from .reasoning_memory import commit_reasoning_card
from .settings import load_settings

logger = logging.getLogger(__name__)

MANIFEST_FILENAME = "reason.manifest.json"
DEFAULT_BUNDLE_SUBDIR = ".reason/bundle"

REASONING_CARD_ENTRY_TYPE = "reasoning-card"
ENGINE_VERSION = "alpha.36"
IDENTITY_MODEL_VERSION = "module::symbol-v1"


# ---------------------------------------------------------------------------
# Hash verification helpers
# ---------------------------------------------------------------------------

def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        h.update(fh.read())
    return h.hexdigest()


def _verify_shards(manifest: dict, bundle_dir: Path) -> None:
    """Raise ValueError / FileNotFoundError on any shard hash mismatch."""
    for shard in manifest.get("shards", []):
        shard_path = bundle_dir / shard["filename"]
        if not shard_path.exists():
            raise FileNotFoundError(f"Shard file missing: {shard_path}")
        actual = _sha256_file(shard_path)
        expected = shard["shard_hash"]
        if actual != expected:
            raise ValueError(
                f"Hash mismatch for {shard['filename']}: "
                f"expected {expected}, got {actual}"
            )


def verify_reason_bundle(bundle_dir: Path) -> dict:
    """Re-hash every reason + graph shard and confirm it matches the manifest.

    Returns a structured proof dict (never raises) so callers can attach the
    result to an export payload. ``verified`` is True only when the manifest is
    present and every shard hash matches.
    """
    bundle_dir = Path(bundle_dir)
    manifest_path = bundle_dir / MANIFEST_FILENAME
    if not manifest_path.exists():
        return {"verified": False, "error": "manifest missing"}
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        return {"verified": False, "error": f"manifest unreadable: {exc}"}

    all_shards = list(manifest.get("shards", [])) + list(manifest.get("graph_shards", []))
    for shard in all_shards:
        shard_path = bundle_dir / shard["filename"]
        if not shard_path.exists():
            return {"verified": False, "error": f"shard missing: {shard['filename']}"}
        if _sha256_file(shard_path) != shard["shard_hash"]:
            return {"verified": False, "error": f"hash mismatch: {shard['filename']}"}

    return {
        "verified": True,
        "bundle_id": manifest.get("bundle_id"),
        "schema_version": manifest.get("schema_version"),
        "reason_shard_count": len(manifest.get("shards", [])),
        "graph_shard_count": len(manifest.get("graph_shards", [])),
        "card_count": sum(int(s.get("card_count", 0)) for s in manifest.get("shards", [])),
    }


# ---------------------------------------------------------------------------
# Export pipeline (single source of truth for the .reason v1 bundle format)
# ---------------------------------------------------------------------------

def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _canonical_json(obj: object) -> str:
    return json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False)


def _extract_module(scope_fingerprint: str) -> str:
    """Return the module segment of a ``module::symbol`` identity."""
    return scope_fingerprint.split("::")[0].strip() or "unknown"


def _safe_json(raw: object) -> object:
    if isinstance(raw, str):
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            return None
    return raw


def _read_reasoning_cards(db_path: Path) -> list[dict]:
    """Return all exportable reason-v2 cards from the local SQLite cache."""
    if not db_path.exists():
        raise FileNotFoundError(f"SQLite DB not found at {db_path!s}.")

    conn = sqlite3.connect(str(db_path), timeout=10.0)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """
            SELECT metadata_json
            FROM cache_entries
            WHERE type = ?
            ORDER BY timestamp_utc ASC
            """,
            (REASONING_CARD_ENTRY_TYPE,),
        ).fetchall()
    finally:
        conn.close()

    cards: list[dict] = []
    for row in rows:
        meta = _safe_json(row["metadata_json"])
        if not isinstance(meta, dict):
            continue
        card = meta.get("card")
        if not isinstance(card, dict):
            continue
        if card.get("schema_version", "") != "reason-v2":
            continue
        validation = card.get("validation", {})
        status = validation.get("status", "") if isinstance(validation, dict) else ""
        if status not in ("captured", "verified", ""):
            continue
        cards.append(card)
    return cards


def _build_shards(cards: list[dict]) -> dict[str, dict]:
    """Group cards by module and build shard objects."""
    shard_map: dict[str, dict] = {}
    for card in cards:
        scope = card.get("scope_fingerprint", "unknown")
        module = _extract_module(scope)
        if module not in shard_map:
            shard_map[module] = {
                "schema_version": "reason-shard-v1",
                "shard_id": module,
                "created_utc": _utc_now(),
                "identity_model_version": IDENTITY_MODEL_VERSION,
                "cards": [],
                "dependency_fingerprints": {},
                "staleness_summary": {"fresh_count": 0, "stale_count": 0},
            }
        shard = shard_map[module]
        staleness = card.get("staleness")
        if isinstance(staleness, dict) and staleness.get("status") == "fresh":
            shard["staleness_summary"]["fresh_count"] += 1
        else:
            shard["staleness_summary"]["stale_count"] += 1
        dep_fp = card.get("dependency_fingerprint") or ""
        shard["dependency_fingerprints"].setdefault(scope, [])
        if dep_fp and dep_fp not in shard["dependency_fingerprints"][scope]:
            shard["dependency_fingerprints"][scope].append(dep_fp)
        shard["cards"].append(card)
    return shard_map


def _export_graph_shards(bundle_dir: Path, project_root: Path) -> list[dict]:
    """Export DRQS graph edges and artifacts into ``bundle_dir/graph/``.

    Best-effort: returns an empty list (never raises) if the graph store is
    unavailable, so a cold cache still produces a valid bundle.
    """
    try:
        graph_db = load_settings(project_root.resolve()).sqlite_path.with_name(
            "reasoning_graph.sqlite"
        )
        if not graph_db.exists():
            return []
        graph_dir = bundle_dir / "graph"
        graph_dir.mkdir(parents=True, exist_ok=True)

        exports = (
            ("card_card_edges", "SELECT from_card_id, to_card_id, edge_type, weight FROM card_card_edges"),
            ("chunk_chunk_edges", "SELECT from_chunk_id, to_chunk_id, edge_type, weight FROM chunk_chunk_edges"),
            (
                "reasoning_artifacts",
                "SELECT artifact_id, chunk_id, summary, dependency_notes, validation_state "
                "FROM reasoning_artifacts",
            ),
        )

        descriptors: list[dict] = []
        with sqlite3.connect(str(graph_db), timeout=10.0) as conn:
            conn.row_factory = sqlite3.Row
            for shard_type, query in exports:
                try:
                    rows = conn.execute(query).fetchall()
                except sqlite3.Error:
                    continue
                data = [dict(r) for r in rows]
                path = graph_dir / f"{shard_type}.json"
                path.write_text(_canonical_json(data), encoding="utf-8")
                descriptors.append(
                    {
                        "filename": f"graph/{shard_type}.json",
                        "shard_hash": _sha256_file(path),
                        "record_count": len(data),
                        "shard_type": shard_type,
                    }
                )
        return descriptors
    except Exception as exc:  # noqa: BLE001 -- graph export is optional
        logger.warning("Graph shard export skipped: %s", exc)
        return []


def _write_bundle(
    shard_map: dict[str, dict],
    bundle_dir: Path,
    project_root: Path,
    engine_version: str,
) -> dict:
    """Serialise shards + manifest to ``bundle_dir``. Returns the manifest dict."""
    shard_dir = bundle_dir / "shards"
    shard_dir.mkdir(parents=True, exist_ok=True)

    shard_descriptors: list[dict] = []
    for module, shard_obj in sorted(shard_map.items()):
        shard_path = shard_dir / f"{module}.reasonshard.json"
        shard_path.write_text(_canonical_json(shard_obj), encoding="utf-8")
        shard_descriptors.append(
            {
                "shard_id": module,
                "filename": f"shards/{module}.reasonshard.json",
                "shard_hash": _sha256_file(shard_path),
                "card_count": len(shard_obj["cards"]),
            }
        )

    graph_shards = _export_graph_shards(bundle_dir, project_root)

    manifest: dict = {
        "schema_version": "reason-manifest-v1",
        "bundle_id": f"bundle-{uuid4()}",
        "created_utc": _utc_now(),
        "engine_version": engine_version,
        "identity_model_version": IDENTITY_MODEL_VERSION,
        "trust_state": "untrusted",
        "source_context": {
            "repo_root": str(project_root.resolve()),
            "snapshot_id": f"snapshot-{uuid4()}",
            "policy_bundle_version": "bundle-1",
        },
        "shards": shard_descriptors,
        "graph_shards": graph_shards,
    }
    (bundle_dir / MANIFEST_FILENAME).write_text(_canonical_json(manifest), encoding="utf-8")
    return manifest


def export_reason_bundle(
    out_dir: Path,
    project_root: Path,
    db_path: Path | None = None,
    engine_version: str = ENGINE_VERSION,
) -> dict:
    """Read v2 reasoning cards from the local cache and write a ``.reason`` v1 bundle.

    This is the single source of truth for the bundle format; both the
    ``scripts/export_reason_bundle.py`` CLI and the session exporter call it.

    Returns a summary dict with the written ``bundle_dir`` and the manifest.
    """
    project_root = Path(project_root).resolve()
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if db_path is None:
        db_path = load_settings(project_root).sqlite_path
    db_path = Path(db_path)

    cards = _read_reasoning_cards(db_path)
    shard_map = _build_shards(cards)
    manifest = _write_bundle(shard_map, out_dir, project_root, engine_version)

    return {
        "bundle_dir": str(out_dir),
        "manifest": manifest,
        "card_count": len(cards),
        "reason_shard_count": len(manifest.get("shards", [])),
        "graph_shard_count": len(manifest.get("graph_shards", [])),
    }


# ---------------------------------------------------------------------------
# Core import
# ---------------------------------------------------------------------------

def _import_graph_shards(manifest: dict, bundle_dir: Path, project_root: Path) -> dict:
    """Import DRQS graph edges and artifacts from a bundle's graph/ directory.

    Best-effort: if the graph store or any shard file is unavailable,
    returns stats with whatever was imported.  Never raises.
    """
    stats = {"card_card_edges": 0, "chunk_chunk_edges": 0, "artifacts": 0, "errors": []}
    graph_shards = manifest.get("graph_shards", [])
    if not graph_shards:
        return stats
    try:
        from .graph_store import GraphStore
        gs = GraphStore(project_root.resolve())

        for shard_desc in graph_shards:
            shard_type = shard_desc.get("shard_type", "")
            shard_path = bundle_dir / shard_desc["filename"]
            if not shard_path.exists():
                stats["errors"].append(f"graph shard not found: {shard_desc['filename']}")
                continue
            try:
                records = json.loads(shard_path.read_text(encoding="utf-8"))
            except Exception as exc:
                stats["errors"].append(f"parse error {shard_desc['filename']}: {exc}")
                continue

            if shard_type == "card_card_edges":
                for rec in records:
                    try:
                        gs.upsert_card_card_edge(
                            from_card_id=rec["from_card_id"],
                            to_card_id=rec["to_card_id"],
                            edge_type=rec.get("edge_type", "bundle"),
                            weight=float(rec.get("weight", 1.0)),
                        )
                        stats["card_card_edges"] += 1
                    except Exception:
                        pass

            elif shard_type == "chunk_chunk_edges":
                for rec in records:
                    try:
                        gs.upsert_chunk_chunk_edge(
                            from_chunk_id=rec["from_chunk_id"],
                            to_chunk_id=rec["to_chunk_id"],
                            edge_type=rec.get("edge_type", "bundle"),
                            weight=float(rec.get("weight", 1.0)),
                        )
                        stats["chunk_chunk_edges"] += 1
                    except Exception:
                        pass

            elif shard_type == "reasoning_artifacts":
                for rec in records:
                    try:
                        gs.upsert_artifact(
                            artifact_id=rec["artifact_id"],
                            chunk_id=rec["chunk_id"],
                            summary=rec.get("summary", ""),
                            dependency_notes=rec.get("dependency_notes"),
                        )
                        stats["artifacts"] += 1
                    except Exception:
                        pass

    except Exception as exc:
        stats["errors"].append(f"graph import failed: {exc}")

    return stats


def import_reason_bundle(
    bundle_dir: str | Path,
    project_root: str | Path,
    source: str = "bundle-import",
    skip_verify: bool = False,
) -> dict:
    """Import all cards from a .reason v1 bundle into the local cache.

    Uses ``commit_reasoning_card`` for every card so that:
    - The chunk_id derivation is identical to the original write path.
    - The FTS5 index is kept in sync automatically.
    - Existing cards are superseded in place (idempotent upsert).

    Cards with deprecated path/hash-based ``scope_fingerprint`` values are
    skipped with a warning rather than aborting the entire import.

    Parameters
    ----------
    bundle_dir:
        Path to the bundle directory (contains ``reason.manifest.json``).
    project_root:
        Workspace root used by ``load_settings`` to locate the SQLite DB.
    source:
        Provenance label written into each committed card's metadata.
    skip_verify:
        When ``True``, shard hash verification is bypassed.  Use only for
        development or when the bundle integrity is already guaranteed by the
        delivery mechanism (e.g. signed archive).

    Returns
    -------
    dict with keys: bundle_id, engine_version, shard_count, committed,
    skipped, errors.
    """
    bundle_path = Path(bundle_dir).resolve()
    root = Path(project_root).resolve()

    manifest_path = bundle_path / MANIFEST_FILENAME
    if not manifest_path.exists():
        raise FileNotFoundError(f"Manifest not found: {manifest_path}")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

    if not skip_verify:
        _verify_shards(manifest, bundle_path)

    committed = 0
    skipped = 0
    errors: list[str] = []

    for shard_desc in manifest.get("shards", []):
        shard_path = bundle_path / shard_desc["filename"]
        shard_obj = json.loads(shard_path.read_text(encoding="utf-8"))

        for card in shard_obj.get("cards", []):
            scope = card.get("scope_fingerprint", "<unknown>")
            try:
                commit_reasoning_card(root, card, source=source)
                committed += 1
            except ValueError as exc:
                # Deprecated identity (path/hash-based scope) or bad payload.
                errors.append(f"{scope}: {exc}")
                skipped += 1
                logger.warning("Skipped card with scope %r during import: %s", scope, exc)

    # --- Import graph shards (Phase 9: DRQS bundle portability) ---
    graph_import_stats = _import_graph_shards(manifest, bundle_path, root)

    return {
        "bundle_id": manifest.get("bundle_id"),
        "engine_version": manifest.get("engine_version"),
        "shard_count": len(manifest.get("shards", [])),
        "committed": committed,
        "skipped": skipped,
        "errors": errors,
        "graph_import": graph_import_stats,
    }


# ---------------------------------------------------------------------------
# Warm-start hook
# ---------------------------------------------------------------------------

def warm_start_if_bundle_exists(
    project_root: str | Path,
    bundle_subdir: str = DEFAULT_BUNDLE_SUBDIR,
    skip_verify: bool = False,
) -> dict | None:
    """Hydrate the engine from a .reason bundle if one is present.

    Designed to be called at server startup, before the first recall or
    routing operation.  Safe and idempotent — calling this multiple times
    or with an unchanged bundle has no side-effects beyond a small DB write
    per card (supersedes chain is maintained automatically).

    Parameters
    ----------
    project_root:
        Workspace root to search for the bundle.
    bundle_subdir:
        Subdirectory name under ``project_root`` where the bundle lives.
        Default: ``"reason_bundle"``.
    skip_verify:
        Pass ``True`` to skip shard hash checks (not recommended in production).

    Returns
    -------
    Import summary dict if a bundle was found and imported, or ``None`` on a
    cold start (no bundle present).
    """
    root = Path(project_root).resolve()
    bundle_dir = root / bundle_subdir
    manifest_path = bundle_dir / MANIFEST_FILENAME

    if not manifest_path.exists():
        logger.debug(
            "[warm-start] No reasoning bundle at %s — cold start.", bundle_dir
        )
        return None

    logger.info("[warm-start] Found reasoning bundle at %s", bundle_dir)

    result = import_reason_bundle(
        bundle_dir=bundle_dir,
        project_root=root,
        skip_verify=skip_verify,
    )

    logger.info(
        "[warm-start] Hydration complete — committed=%d skipped=%d",
        result["committed"],
        result["skipped"],
    )

    return result
