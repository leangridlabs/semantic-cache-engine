from __future__ import annotations

from dataclasses import asdict, dataclass
import json
import os
from pathlib import Path
from typing import Any

from .delta import DeltaRunReport

RUN_REPORT_DIR = Path(os.environ.get("SEMANTIC_CACHE_BASE_DIR", ".reason")) / "runs"


@dataclass(frozen=True)
class RunSummary:
    run_id: str
    baseline_snapshot_id: str
    current_snapshot_id: str
    changed_chunk_count: int
    affected_chunk_count: int
    regenerated_artifact_count: int
    baseline_equivalent_tokens: int
    actual_tokens: int
    saved_tokens: int
    saved_ratio: float
    provider_tokens_captured: bool
    provider_actual_tokens: int | None
    provider_saved_tokens: int | None
    provider_saved_ratio: float | None
    semantic_similarity_method: str | None
    semantic_similarity_threshold: float | None
    semantic_similarity_compared_modified_chunks: int
    semantic_similarity_scored_pairs: int
    semantic_similarity_pass_count: int
    semantic_similarity_pass_rate: float | None
    semantic_similarity_average: float | None
    semantic_similarity_min: float | None
    semantic_similarity_max: float | None
    semantic_similarity_drift: float | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def save_delta_run_report(report: DeltaRunReport, report_dir: Path = RUN_REPORT_DIR) -> Path:
    report_dir.mkdir(parents=True, exist_ok=True)
    output = report_dir / f"{report.run_id}.json"
    output.write_text(json.dumps(report.to_dict(), indent=2), encoding="utf-8")
    return output


def load_delta_run_report(run_id: str, report_dir: Path = RUN_REPORT_DIR) -> dict[str, Any]:
    path = report_dir / f"{run_id}.json"
    if not path.exists():
        raise FileNotFoundError(f"Run report not found: {path}")

    return json.loads(path.read_text(encoding="utf-8"))


def summarize_run_report(payload: dict[str, Any]) -> RunSummary:
    cost = payload.get("cost_metrics", {})
    baseline_tokens = int(cost.get("baseline_equivalent_tokens", 0))
    actual_tokens = int(cost.get("actual_tokens", 0))
    saved_tokens = int(cost.get("saved_tokens", 0))
    saved_ratio = (saved_tokens / baseline_tokens) if baseline_tokens else 0.0
    provider_cost = payload.get("provider_cost_metrics", {})
    provider_tokens_captured = bool(provider_cost.get("captured", 0))

    provider_actual_tokens_raw = provider_cost.get("actual_provider_tokens")
    provider_saved_tokens_raw = provider_cost.get("saved_tokens_vs_baseline")
    provider_saved_ratio_raw = provider_cost.get("saved_ratio_vs_baseline")

    provider_actual_tokens = int(provider_actual_tokens_raw) if provider_actual_tokens_raw is not None else None
    provider_saved_tokens = int(provider_saved_tokens_raw) if provider_saved_tokens_raw is not None else None
    provider_saved_ratio = float(provider_saved_ratio_raw) if provider_saved_ratio_raw is not None else None
    semantic = payload.get("semantic_similarity_metrics", {})
    semantic_similarity_method = str(semantic.get("method")) if semantic.get("method") is not None else None
    threshold_raw = semantic.get("threshold")
    semantic_similarity_threshold = float(threshold_raw) if threshold_raw is not None else None
    pass_rate_raw = semantic.get("pass_rate")
    avg_raw = semantic.get("average_similarity")
    min_raw = semantic.get("min_similarity")
    max_raw = semantic.get("max_similarity")
    drift_raw = semantic.get("semantic_drift")

    dependency = payload.get("dependency_metrics", {})

    return RunSummary(
        run_id=payload.get("run_id", "unknown"),
        baseline_snapshot_id=payload.get("baseline_snapshot_id", "unknown"),
        current_snapshot_id=payload.get("current_snapshot_id", "unknown"),
        changed_chunk_count=int(dependency.get("changed_chunk_count", 0)),
        affected_chunk_count=int(dependency.get("affected_chunk_count", 0)),
        regenerated_artifact_count=len(payload.get("regenerated_artifacts", [])),
        baseline_equivalent_tokens=baseline_tokens,
        actual_tokens=actual_tokens,
        saved_tokens=saved_tokens,
        saved_ratio=saved_ratio,
        provider_tokens_captured=provider_tokens_captured,
        provider_actual_tokens=provider_actual_tokens,
        provider_saved_tokens=provider_saved_tokens,
        provider_saved_ratio=provider_saved_ratio,
        semantic_similarity_method=semantic_similarity_method,
        semantic_similarity_threshold=semantic_similarity_threshold,
        semantic_similarity_compared_modified_chunks=int(semantic.get("compared_modified_chunk_count", 0)),
        semantic_similarity_scored_pairs=int(semantic.get("scored_pair_count", 0)),
        semantic_similarity_pass_count=int(semantic.get("pass_count", 0)),
        semantic_similarity_pass_rate=float(pass_rate_raw) if pass_rate_raw is not None else None,
        semantic_similarity_average=float(avg_raw) if avg_raw is not None else None,
        semantic_similarity_min=float(min_raw) if min_raw is not None else None,
        semantic_similarity_max=float(max_raw) if max_raw is not None else None,
        semantic_similarity_drift=float(drift_raw) if drift_raw is not None else None,
    )
