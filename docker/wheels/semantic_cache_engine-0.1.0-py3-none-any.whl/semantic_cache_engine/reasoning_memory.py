from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sqlite3
from typing import Any

from .cache import build_cache_entry, create_operation_cache_backend
from .intent_identity import canonical_intent as _canonical_intent_fn
from .intent_identity import derive_verb_class as derive_verb_class  # re-export for back-compat
from .scope_identity import canonical_scope, _scope_token_set
from .settings import load_settings

REASONING_CARD_ENTRY_TYPE = "reasoning-card"
REASONING_CARD_VERSION = "phase-11"

# ---------------------------------------------------------------------------
# Canonical intent — deterministic verb-class taxonomy (Phase 6A)
# ---------------------------------------------------------------------------
# The verb-class taxonomy and the deterministic, phrasing-invariant classifier
# now live in the `intent_identity` leaf module so the QUERY, WRITE and COMPARE
# sites share a single source of truth.  `derive_verb_class` is re-exported
# above (for existing importers) and `derive_canonical_intent` wraps the shared
# `canonical_intent` builder to preserve the existing public name used by the
# resolver.


def derive_canonical_intent(task_intent: str, scope_fingerprint: str) -> str | None:
    """Return 'module::verb_class' for the given intent + scope, or None.

    Thin wrapper over `intent_identity.canonical_intent` that preserves the
    historical public name imported by the resolver.  Returns None when
    scope_fingerprint is generic ('repo' or empty).
    """
    return _canonical_intent_fn(task_intent, scope_fingerprint)


# ---------------------------------------------------------------------------
# FTS5 index helpers — fast pre-filter for recall without a full table scan
# ---------------------------------------------------------------------------
# The FTS table lives in the same SQLite file as cache_entries.  We open it
# directly (read-only-friendly path from settings) so we stay decoupled from
# the backend abstraction layer (which may use SQLCipher).  When the database
# is encrypted we gracefully fall back to the legacy full-scan path.

_FTS_TABLE = "reasoning_cards_fts"


def _fts_db_path(project_root: Path) -> Path:
    """Return path to the plain-SQLite FTS sidecar file.

    This is always a separate, unencrypted file next to the main DB so the
    FTS index works even when the main cache is SQLCipher-encrypted.  The
    sidecar contains only text metadata (intent, scope, answer summary) that
    is not sensitive.  If it is missing or corrupt it is recreated on the
    next commit, and recall falls back to a full linear scan in the meantime.
    """
    settings = load_settings(project_root.resolve())
    return settings.sqlite_path.with_name("reasoning_fts.sqlite")


def _fts_journal_mode(db_path: Path) -> str:
    """Use DELETE journal mode on cloud-synced paths (same policy as cache.py)."""
    path_str = str(db_path).lower()
    if "onedrive" in path_str or "dropbox" in path_str or "google drive" in path_str:
        return "DELETE"
    return "WAL"


def _fts_connect(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path), timeout=15.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout=15000")
    conn.execute(f"PRAGMA journal_mode={_fts_journal_mode(db_path)}")
    return conn


def _ensure_fts_schema(db_path: Path) -> bool:
    """Create the FTS5 virtual table if it doesn't exist.  Returns False if FTS5
    is unavailable (encrypted DB, missing extension, etc.) so callers can fall back."""
    try:
        with _fts_connect(db_path) as conn:
            conn.execute(
                f"""
                create virtual table if not exists {_FTS_TABLE}
                using fts5(
                    chunk_id unindexed,
                    task_intent,
                    scope_fingerprint,
                    answer_text,
                    tokenize='porter unicode61'
                )
                """
            )
        return True
    except Exception:
        return False


def _fts_upsert(db_path: Path, chunk_id: str, task_intent: str, scope_fingerprint: str, answer_text: str) -> None:
    """Insert or replace an FTS5 row for a reasoning card.  Best-effort — never raises."""
    try:
        with _fts_connect(db_path) as conn:
            # FTS5 doesn't support ON CONFLICT; delete first then insert.
            conn.execute(f"delete from {_FTS_TABLE} where chunk_id = ?", (chunk_id,))
            conn.execute(
                f"insert into {_FTS_TABLE}(chunk_id, task_intent, scope_fingerprint, answer_text) values(?,?,?,?)",
                (chunk_id, task_intent, scope_fingerprint, answer_text),
            )
    except Exception:
        pass  # Fall back to full-scan recall if FTS write fails


def _fts_candidate_chunk_ids(db_path: Path, query_tokens: str) -> dict[str, float] | None:
    """Run a BM25-ordered FTS5 MATCH query and return ``{chunk_id: reciprocal_rank}``,
    or None when FTS is unavailable/empty (caller falls back to a full scan).

    Reciprocal rank: position 0 → 1.0, position 1 → 0.5, position 2 → 0.33, …
    ``ORDER BY rank`` uses FTS5's built-in BM25 column (more-negative = better),
    so the first result is always the strongest Porter-stemmed match.  The RR
    score is used downstream to lift strong BM25 matches that have low Jaccard
    (e.g. paraphrases bridged by Porter stemming) into the DRQS near-miss band.
    """
    if not query_tokens.strip():
        return None
    try:
        with _fts_connect(db_path) as conn:
            rows = conn.execute(
                f"select chunk_id from {_FTS_TABLE} where {_FTS_TABLE} match ? order by rank limit 200",
                (query_tokens,),
            ).fetchall()
        if not rows:
            return None  # No FTS hits — fall back so full scan can still find partial matches
        return {row["chunk_id"]: 1.0 / (1.0 + i) for i, row in enumerate(rows)}
    except Exception:
        return None  # FTS unavailable — degrade gracefully


def _build_fts_query(task_intent: str, scope_fingerprint: str) -> str:
    """Build an FTS5 MATCH query string from intent + scope tokens.
    Strips punctuation, deduplicates, and OR-joins so partial matches surface."""
    tokens: list[str] = []
    for text in (task_intent, scope_fingerprint):
        for tok in re.findall(r"[a-z0-9]{3,}", _normalize_text(text)):
            if tok not in tokens:
                tokens.append(tok)
    return " OR ".join(tokens) if tokens else ""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _normalize_text(value: str) -> str:
    return re.sub(r"\s+", " ", value.strip().lower())


def _stable_key(value: str) -> str:
    normalized = _normalize_text(value)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:16]


def _stable_payload_hash(payload: dict[str, Any]) -> str:
    material = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(material.encode("utf-8")).hexdigest()[:16]


def _token_set(value: str) -> set[str]:
    return {token for token in re.findall(r"[a-z0-9]+", _normalize_text(value)) if token}


def _jaccard(left: set[str], right: set[str]) -> float:
    if not left or not right:
        return 0.0
    union = left | right
    if not union:
        return 0.0
    return len(left & right) / len(union)


def _parse_timestamp(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    normalized = text[:-1] + "+00:00" if text.endswith("Z") else text
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _age_hours(timestamp_utc: Any) -> float | None:
    parsed = _parse_timestamp(timestamp_utc)
    if parsed is None:
        return None
    delta = datetime.now(timezone.utc) - parsed
    return max(0.0, delta.total_seconds() / 3600.0)


def _schema_rank(schema_version: Any) -> int:
    schema = _coerce_schema_version(schema_version)
    if schema == "reason-v2":
        return 2
    if schema == "reason-v1":
        return 1
    return 0


def _validation_rank(validation_payload: Any) -> int:
    if not isinstance(validation_payload, dict):
        return 0
    status = str(validation_payload.get("status", "")).strip().lower()
    if status == "verified":
        return 3
    if status == "captured":
        return 2
    if status:
        return 1
    return 0


def _extract_policy_mode(card_payload: dict[str, Any]) -> str:
    constraints = card_payload.get("constraints") if isinstance(card_payload.get("constraints"), dict) else {}
    mode = str(constraints.get("policy_mode", "")).strip().lower()
    return mode or "standard"


@dataclass(frozen=True)
class ReasoningCard:
    card_id: str
    schema_version: str
    task_intent: str
    scope_fingerprint: str
    chosen_plan: list[str]
    assumptions: list[str]
    constraints: dict[str, Any]
    validation_evidence: list[str]
    outcome_summary: str
    confidence: float
    reuse_guardrails: list[str]
    evidence_anchors: list[dict[str, Any]]
    validation: dict[str, Any]
    dependency_fingerprint: str | None
    supersedes_card_id: str | None
    source_run_id: str | None
    created_utc: str
    updated_utc: str
    agent_scope_hint: str | None = None
    origin_provider_tokens: int | None = None
    # v3 fields — empty/None for migrated v2 cards; populated on new commits
    graph_metadata: dict[str, Any] | None = None
    provenance: dict[str, Any] | None = None
    semantic_delta: dict[str, Any] | None = None
    freshness: dict[str, Any] | None = None
    # Phase 6A — canonical intent cluster key: 'module::verb_class'.
    # Optional so all existing cards remain valid without migration.
    canonical_intent: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _coerce_str_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(item).strip() for item in value if str(item).strip()]


def _coerce_constraints(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    result: dict[str, Any] = {}
    for key, item in value.items():
        text_key = str(key).strip()
        if not text_key:
            continue
        result[text_key] = item
    return result


def _coerce_dict(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    return dict(value)


def _coerce_validation(value: Any, now: str) -> dict[str, Any]:
    """Coerce a validation payload, defaulting status to 'captured' when absent.

    An explicitly set status (including 'unverified') is always preserved.
    Only a missing or empty status is filled in so that every agent-committed
    card is immediately eligible for the strict-path direct-reuse gate without
    requiring the committer to set validation manually.
    """
    result = _coerce_dict(value)
    if not result.get("status"):
        return {"status": "captured", "method": "agent-commit", "validated_at": now}
    return result


def _coerce_anchor_list(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    anchors: list[dict[str, Any]] = []
    for item in value:
        if isinstance(item, dict):
            anchors.append(dict(item))
    return anchors


def _coerce_schema_version(value: Any) -> str:
    schema = str(value or "").strip()
    return schema or "reason-v1"


def _coerce_confidence(value: Any) -> float:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return 0.0
    return max(0.0, min(parsed, 1.0))


def _coerce_optional_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        result = int(value)
        return result if result >= 0 else None
    except (TypeError, ValueError):
        return None


def _build_dependency_fingerprint(payload: dict[str, Any]) -> str:
    explicit = str(payload.get("dependency_fingerprint", "")).strip()
    if explicit:
        return explicit

    basis = {
        "task_intent_norm": _normalize_text(str(payload.get("task_intent", ""))),
        "scope_fingerprint_norm": _normalize_text(str(payload.get("scope_fingerprint", ""))),
        "constraints": _coerce_constraints(payload.get("constraints")),
        "chosen_plan": _coerce_str_list(payload.get("chosen_plan")),
        "evidence_anchors": _coerce_anchor_list(payload.get("evidence_anchors")),
    }
    return f"dep-{_stable_payload_hash(basis)}"


def _build_card_id(task_intent: str, scope_fingerprint: str, dependency_fingerprint: str) -> str:
    digest = hashlib.sha256(
        f"{_normalize_text(task_intent)}::{_normalize_text(scope_fingerprint)}::{_normalize_text(dependency_fingerprint)}".encode(
            "utf-8"
        )
    ).hexdigest()
    return f"reasoning-card-{digest[:16]}"


def build_reasoning_card(payload: dict[str, Any]) -> ReasoningCard:
    task_intent = str(payload.get("task_intent", "")).strip()
    scope_fingerprint = canonical_scope(str(payload.get("scope_fingerprint", "")).strip())
    if not task_intent:
        raise ValueError("reasoning card requires non-empty task_intent")
    if not scope_fingerprint:
        raise ValueError("reasoning card requires non-empty scope_fingerprint")
    # Reject deprecated path/hash-based identities.
    if (
        "/" in scope_fingerprint
        or "\\" in scope_fingerprint
        or scope_fingerprint.endswith(".py")
        or scope_fingerprint.startswith("scope-")
    ):
        raise ValueError(
            f"scope_fingerprint '{scope_fingerprint}' uses a deprecated path or hash identity. "
            "Use '<module>' or '<module>::<symbol>' format instead."
        )

    now = _utc_now()
    dependency_fingerprint = _build_dependency_fingerprint(payload)
    card_id = str(payload.get("card_id", "")).strip() or _build_card_id(
        task_intent,
        scope_fingerprint,
        dependency_fingerprint,
    )
    created_utc = str(payload.get("created_utc", "")).strip() or now
    updated_utc = str(payload.get("updated_utc", "")).strip() or now

    outcome_summary = (
        str(payload.get("outcome_summary", "")).strip()
        or str(payload.get("answer", "")).strip()
    )
    chosen_plan = _coerce_str_list(payload.get("chosen_plan"))

    # Auto-promote to reason-v2 when the payload contains v2 fields, even if
    # schema_version was not explicitly set.  Agents writing via reasoning_commit
    # do not include schema_version; promoting here ensures cards are immediately
    # eligible for direct recall reuse without a separate migration step.
    explicit_schema = _coerce_schema_version(payload.get("schema_version"))
    if explicit_schema == "reason-v1" and (outcome_summary or chosen_plan):
        schema_version = "reason-v2"
    else:
        schema_version = explicit_schema

    # canonical_intent: use explicit value from payload if provided; otherwise
    # auto-derive from task_intent + scope_fingerprint.  Auto-derivation ensures
    # all new cards get a cluster key even when the committer does not set it.
    _raw_ci = str(payload.get("canonical_intent", "")).strip()
    _canonical_intent = _raw_ci or derive_canonical_intent(task_intent, scope_fingerprint)

    return ReasoningCard(
        card_id=card_id,
        schema_version=schema_version,
        task_intent=task_intent,
        scope_fingerprint=scope_fingerprint,
        chosen_plan=chosen_plan,
        assumptions=_coerce_str_list(payload.get("assumptions")),
        constraints=_coerce_constraints(payload.get("constraints")),
        validation_evidence=_coerce_str_list(payload.get("validation_evidence")),
        outcome_summary=outcome_summary,
        confidence=_coerce_confidence(payload.get("confidence", 0.0)),
        reuse_guardrails=_coerce_str_list(payload.get("reuse_guardrails")),
        evidence_anchors=_coerce_anchor_list(payload.get("evidence_anchors")),
        validation=_coerce_validation(payload.get("validation"), now),
        dependency_fingerprint=dependency_fingerprint,
        supersedes_card_id=(str(payload.get("supersedes_card_id", "")).strip() or None),
        source_run_id=(str(payload.get("source_run_id", "")).strip() or None),
        created_utc=created_utc,
        updated_utc=updated_utc,
        agent_scope_hint=(str(payload.get("agent_scope_hint", "")).strip() or None),
        origin_provider_tokens=(_coerce_optional_int(payload.get("origin_provider_tokens"))),
        graph_metadata=(_coerce_dict(payload.get("graph_metadata")) or None),
        provenance=(_coerce_dict(payload.get("provenance")) or None),
        semantic_delta=(_coerce_dict(payload.get("semantic_delta")) or None),
        freshness=(_coerce_dict(payload.get("freshness")) or None),
        canonical_intent=_canonical_intent,
    )


def _graph_store_upsert_card(project_root: Path, card: "ReasoningCard", chunk_id: str = "") -> None:
    """Best-effort write of a committed card into the DRQS graph store.

    Never raises.  If the graph store is unavailable the main cache commit
    is already done and recall continues to work normally.
    """
    try:
        from .graph_store import GraphStore
        gs = GraphStore(project_root)
        gs.ensure_schema()
        validation_state = str(
            (card.validation or {}).get("status", "")
        ).strip() or "captured"
        gs.upsert_card(
            card_id=card.card_id,
            scope_fingerprint=card.scope_fingerprint,
            task_intent=card.task_intent,
            dependency_fingerprint=card.dependency_fingerprint or "",
            validation_state=validation_state,
            supersedes_card_id=card.supersedes_card_id,
            chunk_id=chunk_id,
        )
        # Wire card → superseded card edge if lineage exists
        if card.supersedes_card_id:
            gs.upsert_card_card_edge(
                from_card_id=card.card_id,
                to_card_id=card.supersedes_card_id,
                edge_type="supersession",
                weight=1.0,
            )
        # Wire card → evidence anchor chunks
        for anchor in (card.evidence_anchors or []):
            if isinstance(anchor, dict):
                anchor_chunk_id = str(anchor.get("chunk_id", "")).strip()
                if anchor_chunk_id:
                    gs.upsert_card_chunk_edge(
                        from_card_id=card.card_id,
                        to_chunk_id=anchor_chunk_id,
                        edge_type="evidence",
                        weight=1.0,
                    )
        # Build card-card edges (shared_scope / contains / semantic_neighbor).
        gs._build_card_edges_batch(card.card_id, card.scope_fingerprint, chunk_id)
        # Rebuild edges for any existing parent cards so they gain a downward
        # edge to this newly committed child (e.g. resolver → resolver::func).
        gs._rebuild_parent_edges(card.card_id, card.scope_fingerprint)
    except Exception:
        import logging
        logging.getLogger(__name__).debug(
            "reasoning_memory: graph store write failed for card %s", card.card_id, exc_info=True
        )


def commit_reasoning_card(
    project_root: Path,
    card_payload: dict[str, Any],
    source: str = "manual",
) -> dict[str, Any]:
    card = build_reasoning_card(card_payload)
    settings = load_settings(project_root.resolve())
    backend = create_operation_cache_backend(settings)
    backend.ensure_schema()

    chunk_id = f"reasoning-card::{_stable_key(card.task_intent)}::{_stable_key(card.scope_fingerprint)}"
    chunk_hash = hashlib.sha256(chunk_id.encode("utf-8")).hexdigest()

    if not card.supersedes_card_id:
        existing_entries = backend.get_entries_by_chunk_id(chunk_id)
        previous_card_id = None
        for entry in existing_entries:
            if entry.type != REASONING_CARD_ENTRY_TYPE:
                continue
            candidate = entry.metadata.get("card") if isinstance(entry.metadata, dict) else None
            if not isinstance(candidate, dict):
                continue
            previous_card_id = str(candidate.get("card_id", "")).strip() or None
            if previous_card_id:
                break
        if previous_card_id and previous_card_id != card.card_id:
            card = build_reasoning_card(
                {
                    **card.to_dict(),
                    "supersedes_card_id": previous_card_id,
                    "updated_utc": _utc_now(),
                }
            )

    metadata = {
        "task_intent": card.task_intent,
        "scope_fingerprint": card.scope_fingerprint,
        "task_intent_norm": _normalize_text(card.task_intent),
        "scope_fingerprint_norm": _normalize_text(card.scope_fingerprint),
        "source": source,
        "card": card.to_dict(),
    }
    backend.upsert_cache_entry(
        build_cache_entry(
            chunk_id=chunk_id,
            chunk_hash=chunk_hash,
            entry_type=REASONING_CARD_ENTRY_TYPE,
            version=REASONING_CARD_VERSION,
            metadata=metadata,
        )
    )

    # Keep FTS5 index in sync for fast recall pre-filtering.
    db_path = _fts_db_path(project_root.resolve())
    _ensure_fts_schema(db_path)
    answer_text = " ".join(filter(None, [
        card.outcome_summary,
        " ".join(card.chosen_plan),
        " ".join(card.assumptions),
    ]))
    # Normalize intent and scope so FTS tokens match what _build_fts_query produces at recall time.
    _fts_upsert(
        db_path,
        chunk_id,
        _normalize_text(card.task_intent),
        _normalize_text(card.scope_fingerprint),
        answer_text,
    )

    # Write graph store entry — best-effort, never raises.
    _graph_store_upsert_card(project_root.resolve(), card, chunk_id=chunk_id)

    return {
        "status": "committed",
        "entry_type": REASONING_CARD_ENTRY_TYPE,
        "version": REASONING_CARD_VERSION,
        "chunk_id": chunk_id,
        "hash": chunk_hash,
        "card": card.to_dict(),
    }


def _match_score(
    requested_intent: str,
    requested_scope: str,
    candidate_intent: str,
    candidate_scope: str,
) -> tuple[float, str]:
    requested_intent_norm = _normalize_text(requested_intent)
    requested_scope_norm = _normalize_text(requested_scope)
    candidate_intent_norm = _normalize_text(candidate_intent)
    candidate_scope_norm = _normalize_text(candidate_scope)

    intent_jaccard = _jaccard(_token_set(requested_intent), _token_set(candidate_intent))
    scope_jaccard = _jaccard(_scope_token_set(canonical_scope(requested_scope)), _scope_token_set(canonical_scope(candidate_scope)))

    # Intent is the primary signal (75/65); scope is a ranking boost only (25/15).
    # exact+exact = 0.75+0.25 = 1.00, satisfying the "exact" threshold at 0.95.
    # exact intent alone = 0.75, always surfaces regardless of scope mismatch.
    score = 0.0
    if requested_intent_norm == candidate_intent_norm:
        score += 0.75
    else:
        score += 0.65 * intent_jaccard

    if requested_scope_norm == candidate_scope_norm:
        score += 0.25
    else:
        # Module-prefix fallback: if requested scope is "module::symbol", also treat
        # a card scoped to just "module" as a partial scope match (weight 0.18).
        # This lets module-level cards surface when a narrower symbol-level query is made.
        _module_prefix = requested_scope_norm.split("::")[0].strip() if "::" in requested_scope_norm else None
        if _module_prefix and _module_prefix == candidate_scope_norm:
            score += 0.18
        else:
            score += 0.15 * scope_jaccard

    # Intent floor: when enough intent tokens match, surface the card regardless of
    # scope mismatch.  Handles cross-file recall — the user may have a different file
    # open than the file the card is about, but the question is clearly the same subject.
    # A 0.35 intent-token Jaccard (>1/3 of tokens shared) is a meaningful overlap,
    # so we guarantee a score above the default min_score gate (0.35) in that case.
    if intent_jaccard >= 0.35 and score < 0.40:
        score = 0.40

    rounded = round(min(score, 1.0), 5)
    if rounded >= 0.95:
        return rounded, "exact"
    if rounded >= 0.45:
        return rounded, "semantic"
    return rounded, "weak"


def recall_reasoning_cards(
    project_root: Path,
    task_intent: str,
    scope_fingerprint: str,
    limit: int = 5,
    *,
    min_score: float = 0.35,
    require_intent_overlap: float | None = None,
    require_scope_overlap: float | None = None,
    max_age_hours: float | None = None,
    allowed_policy_modes: list[str] | None = None,
) -> dict[str, Any]:
    requested_intent = task_intent.strip()
    requested_scope = scope_fingerprint.strip()
    if not requested_intent:
        raise ValueError("reasoning recall requires non-empty task_intent")
    if not requested_scope:
        raise ValueError("reasoning recall requires non-empty scope_fingerprint")

    # Canonical intent for exact-match boost (Phase 6A).
    # When both the question and the candidate share the same canonical_intent
    # (same module + same verb class) the card is an unambiguous semantic hit —
    # override _match_score to 1.0 rather than relying on Jaccard.
    requested_canonical_intent = derive_canonical_intent(requested_intent, requested_scope)

    settings = load_settings(project_root.resolve())
    backend = create_operation_cache_backend(settings)
    backend.ensure_schema()

    # FTS5 pre-filter: find candidate chunk_ids in microseconds before the full scan.
    db_path = _fts_db_path(project_root.resolve())
    fts_query = _build_fts_query(task_intent, scope_fingerprint)
    fts_hits: dict[str, float] | None = _fts_candidate_chunk_ids(db_path, fts_query)
    # fts_hits=None  → FTS unavailable or no hits — fall back to full scan.
    # fts_hits=dict  → {chunk_id: reciprocal_rank}; only score those chunk_ids.
    #                  The RR score (1.0=top BM25 hit) is used in the scoring
    #                  loop to lift strong FTS matches above the DRQS floor.

    entries = backend.list_cache_entries(entry_type=REASONING_CARD_ENTRY_TYPE)

    bounded_min_score = max(0.0, min(float(min_score), 1.0))
    bounded_intent_overlap = (
        None if require_intent_overlap is None else max(0.0, min(float(require_intent_overlap), 1.0))
    )
    bounded_scope_overlap = (
        None if require_scope_overlap is None else max(0.0, min(float(require_scope_overlap), 1.0))
    )
    bounded_age_hours = None if max_age_hours is None else max(0.0, float(max_age_hours))
    allowed_modes = (
        {str(mode).strip().lower() for mode in allowed_policy_modes if str(mode).strip()}
        if isinstance(allowed_policy_modes, list)
        else set()
    )

    candidates: list[dict[str, Any]] = []
    for entry in entries:
        card_payload = entry.metadata.get("card")
        if not isinstance(card_payload, dict):
            continue
        candidate_intent = str(card_payload.get("task_intent", "")).strip()
        candidate_scope = str(card_payload.get("scope_fingerprint", "")).strip()
        if not candidate_intent or not candidate_scope:
            continue

        # FTS pre-filter: skip entries not in the FTS hit set (when FTS returned results).
        # Same-scope cards bypass this filter — a paraphrase may use different vocabulary
        # than the original question, so its FTS results may not contain the card's
        # chunk_id even when the card is semantically the right answer.  Filtering those
        # out here would produce zero candidates for valid paraphrases (Bug: FTS kills
        # same-scope paraphrase recall).  Cross-scope cards still benefit from the filter.
        if fts_hits is not None and entry.chunk_id not in fts_hits and candidate_scope != requested_scope:
            continue

        score, match_type = _match_score(
            requested_intent,
            requested_scope,
            candidate_intent,
            candidate_scope,
        )

        # Canonical intent exact-match boost: same module + same verb class is a
        # definitive semantic hit regardless of Jaccard.  Override score to 1.0
        # so this card sorts to the top and passes direct-reuse safety gates.
        card_canonical_intent = str(card_payload.get("canonical_intent") or "").strip()
        _canonical_intent_matched = (
            bool(requested_canonical_intent)
            and bool(card_canonical_intent)
            and requested_canonical_intent == card_canonical_intent
        )
        if _canonical_intent_matched:
            score = 1.0
            match_type = "exact"

        # BM25 lift: if FTS (Porter-stemmed) ranked this card highly for the
        # query, lift score to the DRQS near-miss floor (0.40) so vocabulary-
        # divergent paraphrases can enter graph_assisted evaluation.  The Porter
        # tokenizer bridges morphological variants ("prioritize"/"priority",
        # "schedules"/"schedule") that raw Jaccard misses.  fts_rr is the
        # reciprocal rank from the BM25-ordered FTS result set (1.0 = top hit).
        # Canonical-intent hits skip this — their score is already 1.0.
        fts_rr = 0.0
        if not _canonical_intent_matched:
            fts_rr = (fts_hits or {}).get(entry.chunk_id, 0.0)
            if fts_rr >= 0.70 and score < 0.40:
                score = 0.40
                match_type = "semantic"

        if score < bounded_min_score:
            continue

        intent_overlap = _jaccard(_token_set(requested_intent), _token_set(candidate_intent))
        # Canonical intent match is a reliable semantic hit — same module::verb_class
        # means the two questions cover the same concept regardless of surface wording.
        # Override Jaccard intent_overlap to 1.0 so the recall decision paths
        # (which gate on intent_overlap >= 0.65 / 0.80 / 0.99) correctly treat
        # a canonical match as a full hit instead of blocking on low word overlap.
        if _canonical_intent_matched:
            intent_overlap = 1.0
        scope_overlap = _jaccard(_scope_token_set(canonical_scope(requested_scope)), _scope_token_set(canonical_scope(candidate_scope)))
        if not _canonical_intent_matched:
            if bounded_intent_overlap is not None and intent_overlap < bounded_intent_overlap:
                continue
        if bounded_scope_overlap is not None and scope_overlap < bounded_scope_overlap:
            continue

        updated_utc = card_payload.get("updated_utc", entry.timestamp_utc)
        age_hours = _age_hours(updated_utc)
        if bounded_age_hours is not None and age_hours is not None and age_hours > bounded_age_hours:
            continue

        policy_mode = _extract_policy_mode(card_payload)
        if allowed_modes and policy_mode not in allowed_modes:
            continue

        updated_ts = _parse_timestamp(updated_utc)
        updated_epoch = updated_ts.timestamp() if updated_ts is not None else 0.0
        validation_payload = card_payload.get("validation", {})

        candidates.append(
            {
                "card_id": card_payload.get("card_id"),
                "task_intent": candidate_intent,
                "scope_fingerprint": candidate_scope,
                "score": score,
                "match_type": match_type,
                "intent_overlap": round(intent_overlap, 6),
                "scope_overlap": round(scope_overlap, 6),
                "confidence": card_payload.get("confidence", 0.0),
                "outcome_summary": card_payload.get("outcome_summary", ""),
                "chosen_plan": card_payload.get("chosen_plan", []),
                "schema_version": card_payload.get("schema_version", "reason-v1"),
                "validation": validation_payload,
                "validation_status": (
                    str(validation_payload.get("status", "")).strip().lower()
                    if isinstance(validation_payload, dict)
                    else ""
                ),
                "evidence_anchors": card_payload.get("evidence_anchors", []),
                "dependency_fingerprint": card_payload.get("dependency_fingerprint"),
                "supersedes_card_id": card_payload.get("supersedes_card_id"),
                "updated_utc": updated_utc,
                "age_hours": round(age_hours, 6) if age_hours is not None else None,
                "fts_rr": round(fts_rr, 4),
                "policy_mode": policy_mode,
                "constraints": card_payload.get("constraints", {}),
                "updated_epoch": updated_epoch,
                "entry_timestamp_utc": entry.timestamp_utc,
                "agent_scope_hint": card_payload.get("agent_scope_hint"),
                "source": str(entry.metadata.get("source", "")).strip() if isinstance(entry.metadata, dict) else "",
                "canonical_intent": card_canonical_intent,
            }
        )

    candidates.sort(
        key=lambda item: (
            float(item.get("score", 0.0)),
            _schema_rank(item.get("schema_version")),
            _validation_rank(item.get("validation")),
            float(item.get("intent_overlap", 0.0)),
            float(item.get("scope_overlap", 0.0)),
            float(item.get("updated_epoch", 0.0)),
            float(item.get("confidence", 0.0)),
            str(item.get("entry_timestamp_utc", "")),
        ),
        reverse=True,
    )

    bounded_limit = max(1, limit)
    top_candidates = candidates[:bounded_limit]
    top_match_mode = top_candidates[0]["match_type"] if top_candidates else "none"
    return {
        "task_intent": requested_intent,
        "scope_fingerprint": requested_scope,
        "entry_type": REASONING_CARD_ENTRY_TYPE,
        "candidate_count": len(candidates),
        "match_mode": top_match_mode,
        "candidates": [{k: v for k, v in candidate.items() if k != "updated_epoch"} for candidate in top_candidates],
    }


def purge_stale_cards_for_paths(
    project_root: Path,
    changed_chunk_keys: list[str] | set[str],
) -> dict[str, Any]:
    """Delete reasoning cards whose scope module matches any modified file path.

    Called by the delta pipeline after classifying changed chunks.  Bridges the
    architectural gap where agent-committed cards (via reasoning_commit MCP tool)
    have ``evidence_anchors: []`` and are therefore invisible to the artifact-
    index-based staleness check in ``hydrate_reasoning_artifacts``.

    Parameters
    ----------
    project_root:
        Workspace root used to locate the SQLite cache (same as the rest of the
        reasoning_memory API).
    changed_chunk_keys:
        Set/list of ``"path::anchor"`` chunk key strings from the delta pipeline's
        ``changed`` output.  Covers MODIFIED, NEW and DELETED chunks.

    Returns
    -------
    dict with keys ``purged`` (int), ``modules_checked`` (list[str]).
    """
    if not changed_chunk_keys:
        return {"purged": 0, "modules_checked": []}

    # Extract file paths from "path::anchor" keys and reduce each to a bare
    # alphanumeric module token for comparison.  Uses _bare_module() rather than
    # canonical_scope() directly because scope fingerprints on cards (e.g.
    # "reactfiberhooks.new") use a different capitalisation convention than
    # CamelCase filenames ("ReactFiberHooks"), and .new/.old variant suffixes
    # survive canonical_scope but must be stripped for the match to succeed.
    def _bare_module(name: str) -> str:
        """Bare lowercase alphanumeric token — strips .new/.old and punctuation."""
        import re as _re
        name = _re.sub(r'[._-](?:new|old)$', '', name, flags=_re.IGNORECASE)
        return _re.sub(r'[^a-z0-9]', '', name.lower())

    modified_modules: set[str] = set()
    for key in changed_chunk_keys:
        path_part = key.split("::")[0]
        # Strip all extensions (e.g. "ReactFiberHooks.new.js" → "ReactFiberHooks").
        stem = Path(path_part).stem
        base = stem.split(".")[0]
        token = _bare_module(base)
        if token:
            modified_modules.add(token)

    if not modified_modules:
        return {"purged": 0, "modules_checked": []}

    settings = load_settings(project_root.resolve())
    db_path = settings.sqlite_path
    fts_db = _fts_db_path(project_root.resolve())

    if not db_path.exists():
        return {"purged": 0, "modules_checked": sorted(modified_modules)}

    chunk_ids_to_purge: set[str] = set()
    entry_ids_to_purge: list[str] = []

    try:
        conn = sqlite3.connect(str(db_path), timeout=15.0)
        conn.row_factory = sqlite3.Row
        try:
            cur = conn.cursor()
            cur.execute(
                "SELECT entry_id, chunk_id, metadata_json FROM cache_entries WHERE type = ?",
                (REASONING_CARD_ENTRY_TYPE,),
            )
            rows = cur.fetchall()

            for row in rows:
                try:
                    meta = json.loads(row["metadata_json"])
                    card = meta.get("card") if isinstance(meta, dict) else None
                    if not isinstance(card, dict):
                        continue
                    scope = str(card.get("scope_fingerprint", "")).strip()
                    if not scope:
                        continue
                    # Extract the module component (left of "::") and reduce
                    # to the same bare token used when building modified_modules.
                    card_module = _bare_module(scope.split("::")[0])
                    if card_module in modified_modules:
                        entry_ids_to_purge.append(str(row["entry_id"]))
                        chunk_ids_to_purge.add(str(row["chunk_id"]))
                except Exception:  # noqa: BLE001
                    continue

            if entry_ids_to_purge:
                for entry_id in entry_ids_to_purge:
                    cur.execute("DELETE FROM cache_entries WHERE entry_id = ?", (entry_id,))
                conn.commit()
        finally:
            conn.close()
    except Exception:  # noqa: BLE001
        # Best-effort — never let a purge failure abort the delta run.
        return {"purged": 0, "modules_checked": sorted(modified_modules)}

    # Purge matching FTS5 index entries (best-effort; sidecar may not exist yet).
    if chunk_ids_to_purge and fts_db.exists():
        try:
            fts_conn = sqlite3.connect(str(fts_db), timeout=15.0)
            fts_cur = fts_conn.cursor()
            for chunk_id in chunk_ids_to_purge:
                fts_cur.execute(
                    "DELETE FROM reasoning_cards_fts WHERE chunk_id = ?",
                    (chunk_id,),
                )
            fts_conn.commit()
            fts_conn.close()
        except Exception:  # noqa: BLE001
            pass

    return {
        "purged": len(entry_ids_to_purge),
        "modules_checked": sorted(modified_modules),
    }


def migrate_reasoning_cards_to_v2(
    project_root: Path,
    *,
    dry_run: bool = True,
    limit: int | None = None,
) -> dict[str, Any]:
    settings = load_settings(project_root.resolve())
    backend = create_operation_cache_backend(settings)
    backend.ensure_schema()
    entries = backend.list_cache_entries(entry_type=REASONING_CARD_ENTRY_TYPE)

    bounded_limit = None if limit is None else max(1, int(limit))
    scanned = 0
    migrated = 0
    skipped = 0
    migrated_card_ids: list[str] = []

    for entry in entries:
        card_payload = entry.metadata.get("card") if isinstance(entry.metadata, dict) else None
        if not isinstance(card_payload, dict):
            skipped += 1
            continue

        scanned += 1
        if bounded_limit is not None and migrated >= bounded_limit:
            skipped += 1
            continue

        schema_version = str(card_payload.get("schema_version", "reason-v1") or "reason-v1").strip()
        has_validation = isinstance(card_payload.get("validation"), dict)
        has_anchors = isinstance(card_payload.get("evidence_anchors"), list)
        has_dependency = bool(str(card_payload.get("dependency_fingerprint", "")).strip())

        needs_upgrade = schema_version != "reason-v2" or not has_validation or not has_anchors or not has_dependency
        if not needs_upgrade:
            skipped += 1
            continue

        card_id = str(card_payload.get("card_id", "")).strip()
        if card_id:
            migrated_card_ids.append(card_id)

        if dry_run:
            migrated += 1
            continue

        upgraded = dict(card_payload)
        upgraded["schema_version"] = "reason-v2"
        upgraded["validation"] = (
            card_payload.get("validation")
            if isinstance(card_payload.get("validation"), dict)
            else {
                "status": "migrated",
                "method": "legacy-backfill",
                "validated_at": _utc_now(),
            }
        )
        upgraded["evidence_anchors"] = (
            card_payload.get("evidence_anchors")
            if isinstance(card_payload.get("evidence_anchors"), list)
            else []
        )
        if not str(upgraded.get("dependency_fingerprint", "")).strip():
            upgraded["dependency_fingerprint"] = _build_dependency_fingerprint(upgraded)
        upgraded["updated_utc"] = _utc_now()

        commit_reasoning_card(
            project_root=project_root,
            card_payload=upgraded,
            source="migration-v2",
        )
        migrated += 1

    return {
        "status": "dry-run" if dry_run else "applied",
        "entry_type": REASONING_CARD_ENTRY_TYPE,
        "scanned": scanned,
        "migrated": migrated,
        "skipped": skipped,
        "migrated_card_ids": migrated_card_ids,
    }