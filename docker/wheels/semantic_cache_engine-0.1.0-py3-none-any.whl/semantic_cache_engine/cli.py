import argparse
import json
from pathlib import Path
import sys

from .benchmark import benchmark_to_json
from .bootstrap import bootstrap_to_json
from .direct_chat import run_direct_chat_turn
from .delta import compute_delta_report
from .familiarization_packs import familiarization_pack_to_json
from .ingest import ingest_to_json
from .onboarding import onboarding_manifest_to_json, write_onboarding_artifacts
from .regeneration import regeneration_to_json
from .run_report import load_delta_run_report, save_delta_run_report, summarize_run_report
from .mcp_server import mcp_server_status, run_mcp_server, stop_mcp_server, verify_mcp_closed
from .phase13_metrics import metrics_report_to_json
from .reasoning_memory import commit_reasoning_card, migrate_reasoning_cards_to_v2, recall_reasoning_cards
from .resolver_baseline import resolver_baseline_comparison_to_json
from .settings import load_settings
from .snapshot import build_snapshot_manifest, save_snapshot_manifest
from .snapshot import latest_snapshot_id
from .sync import sync_to_json
from .ingest import ingest_project


def _print_progress(message: str) -> None:
    print(f"[progress] {message}", flush=True)


def _reveal_in_file_explorer(target: Path) -> bool:
    """Open the OS file explorer at *target*'s containing folder (best-effort).

    On Windows this selects the file in Explorer; on macOS it reveals the file;
    on Linux it opens the parent folder. Returns True if a reveal command was
    launched. Never raises -- revealing is a convenience, not a hard step.
    """
    import os
    import subprocess

    folder = target.parent
    try:
        if os.name == "nt":
            # /select, highlights the exact file inside the folder.
            subprocess.Popen(["explorer", "/select,", str(target)])
            return True
        if sys.platform == "darwin":
            subprocess.Popen(["open", "-R", str(target)])
            return True
        subprocess.Popen(["xdg-open", str(folder)])
        return True
    except Exception:  # noqa: BLE001 -- reveal is a convenience, never fatal
        return False


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="engine",
        description="Semantic Cache + Incremental Reasoning Engine CLI",
    )
    subparsers = parser.add_subparsers(dest="command")

    ingest = subparsers.add_parser("ingest", help="Scan and chunk a project path")
    ingest.add_argument("--path", required=True, help="Project path to ingest")
    ingest.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write ingest JSON output",
    )
    ingest.add_argument(
        "--write-snapshot",
        action="store_true",
        help="Persist a baseline snapshot manifest under data/baselines",
    )
    ingest.add_argument(
        "--snapshot-id",
        required=False,
        help="Optional snapshot ID override when using --write-snapshot",
    )

    delta = subparsers.add_parser("delta", help="Compute delta against a snapshot")
    delta.add_argument("--path", required=True, help="Project path to compare")
    delta.add_argument("--against", required=False, default=None, help="Snapshot ID to compare against (default: latest in data/baselines)")
    delta.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write delta JSON report",
    )
    delta.add_argument(
        "--live-provider",
        required=False,
        help="Optional live provider mode override (none, mock, openai-compatible)",
    )
    delta.add_argument(
        "--playbook",
        required=False,
        help="Optional playbook profile (for example: full-repo, session-readiness)",
    )
    delta.add_argument(
        "--provider-hydration",
        required=False,
        choices=["probe", "full-repo"],
        default="probe",
        help="Provider usage capture mode: lightweight probe or full-repo hydration",
    )

    regenerate = subparsers.add_parser("regenerate", help="Regenerate invalidated artifacts")
    regenerate.add_argument("--path", required=True, help="Project path to regenerate")
    regenerate.add_argument(
        "--against",
        required=False,
        help="Optional snapshot ID to regenerate against; defaults to latest baseline",
    )
    regenerate.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write regeneration JSON output",
    )

    bootstrap = subparsers.add_parser("bootstrap", help="Hydrate startup context from cache")
    bootstrap.add_argument("--path", required=True, help="Project path to bootstrap")
    bootstrap.add_argument(
        "--against",
        required=False,
        help="Optional snapshot ID to bootstrap against; defaults to latest baseline",
    )
    bootstrap.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write bootstrap JSON output",
    )

    report = subparsers.add_parser("report", help="Show run report")
    report.add_argument("--run", required=True, help="Run ID to report")
    report.add_argument(
        "--raw",
        action="store_true",
        help="Return raw run payload instead of summary",
    )

    benchmark = subparsers.add_parser("benchmark", help="Run baseline/rerun/change token benchmark")
    benchmark.add_argument("--path", required=True, help="Project path to benchmark")
    benchmark.add_argument(
        "--against",
        required=False,
        help="Optional snapshot ID to benchmark against; defaults to latest baseline",
    )
    benchmark.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write benchmark JSON output",
    )
    benchmark.add_argument(
        "--live-provider",
        required=False,
        help="Optional live provider mode override (none, mock, openai-compatible)",
    )
    benchmark.add_argument(
        "--playbook",
        required=False,
        help="Optional playbook profile (for example: full-repo, session-readiness)",
    )
    benchmark.add_argument(
        "--include-changed-rerun",
        action="store_true",
        help="Include changed-rerun pass (disabled by default for faster benchmark runs)",
    )
    benchmark.add_argument(
        "--provider-hydration",
        required=False,
        choices=["probe", "full-repo"],
        default="probe",
        help="Provider usage capture mode: lightweight probe or full-repo hydration",
    )

    sync = subparsers.add_parser("sync", help="Sync local reasoning cache entries to central storage")
    sync.add_argument(
        "--entry-type",
        required=False,
        default="reasoning",
        help="Cache entry type to sync (default: reasoning)",
    )
    sync.add_argument(
        "--max-entries",
        required=False,
        type=int,
        help="Optional max number of entries to sync in one run",
    )
    sync.add_argument(
        "--no-checkpoint",
        action="store_true",
        help="Disable incremental checkpoint and rescan all local entries",
    )
    sync.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write sync JSON output",
    )

    setup = subparsers.add_parser("setup", help="Write onboarding templates for a new repository")
    setup.add_argument("--path", required=True, help="Repository path to initialize")
    setup.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing onboarding template files",
    )
    setup.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write onboarding JSON output",
    )

    mcp = subparsers.add_parser(
        "mcp",
        help="Run legacy-compatible local stdio MCP server (direct chat is default)",
    )
    mcp.add_argument("--path", required=True, help="Repository path for local semantic cache context")
    mcp.add_argument(
        "--status",
        action="store_true",
        help="Return current MCP server status and PID metadata",
    )
    mcp.add_argument(
        "--stop",
        action="store_true",
        help="Stop the currently tracked MCP server PID for this project",
    )
    mcp.add_argument(
        "--verify-closed",
        action="store_true",
        help="Verify no tracked MCP server is running for this project",
    )

    pack = subparsers.add_parser(
        "familiarization-pack",
        help="Generate a familiarization pack (scout, route, or drill)",
    )
    pack.add_argument("--path", required=True, help="Project path to analyze")
    pack.add_argument(
        "--mode",
        required=False,
        choices=["scout", "route", "drill"],
        default="scout",
        help="Pack mode to generate",
    )
    pack.add_argument(
        "--against",
        required=False,
        help="Optional snapshot ID to compare against; defaults to latest baseline",
    )
    pack.add_argument(
        "--query",
        required=False,
        help="Optional query used for drill pack evidence targeting",
    )
    pack.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write familiarization pack JSON output",
    )

    seed_topology = subparsers.add_parser(
        "seed-topology",
        help="Seed a workspace topology reasoning card from the latest scout pack output",
    )
    seed_topology.add_argument("--path", required=True, help="Repository path for local semantic cache context")
    seed_topology.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write commit result JSON output",
    )

    reasoning_recall = subparsers.add_parser(
        "reasoning-recall",
        help="Recall cached task-level reasoning cards by intent and scope",
    )
    reasoning_recall.add_argument("--path", required=True, help="Repository path for local semantic cache context")
    reasoning_recall.add_argument("--intent", required=True, help="Task intent to recall")
    reasoning_recall.add_argument("--scope", required=True, help="Scope fingerprint for recall")
    reasoning_recall.add_argument(
        "--limit",
        required=False,
        type=int,
        default=5,
        help="Maximum number of reasoning candidates to return",
    )
    reasoning_recall.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write recall JSON output",
    )

    reasoning_commit = subparsers.add_parser(
        "reasoning-commit",
        help="Commit a task-level reasoning card into local cache",
    )
    reasoning_commit.add_argument("--path", required=True, help="Repository path for local semantic cache context")
    reasoning_commit.add_argument(
        "--json-in",
        required=True,
        help="Path to reasoning card JSON payload",
    )
    reasoning_commit.add_argument(
        "--source",
        required=False,
        default="cli",
        help="Source label for the reasoning card commit",
    )
    reasoning_commit.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write commit JSON output",
    )

    reasoning_migrate = subparsers.add_parser(
        "reasoning-migrate-v2",
        help="Backfill legacy reasoning cards to reason-v2 metadata",
    )
    reasoning_migrate.add_argument("--path", required=True, help="Repository path for local semantic cache context")
    reasoning_migrate.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview migrated card count without writing updates",
    )
    reasoning_migrate.add_argument(
        "--limit",
        required=False,
        type=int,
        help="Optional maximum number of cards to migrate",
    )
    reasoning_migrate.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write migration JSON output",
    )

    metrics_report = subparsers.add_parser(
        "metrics-report",
        help="Summarize phase-13 token and runtime metrics by operation category",
    )
    metrics_report.add_argument("--path", required=True, help="Repository path for run report metrics")
    metrics_report.add_argument(
        "--window-days",
        required=False,
        type=int,
        default=7,
        help="Rolling window size in days",
    )
    metrics_report.add_argument(
        "--top-n",
        required=False,
        type=int,
        default=3,
        help="Number of top token-spend operations to include",
    )
    metrics_report.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write metrics report JSON output",
    )

    resolver_baseline = subparsers.add_parser(
        "resolver-baseline",
        help="Run forced true-agent baseline then normal resolver run for the same question",
    )
    resolver_baseline.add_argument("--path", required=True, help="Repository path for local semantic cache context")
    resolver_baseline.add_argument("--question", required=True, help="Question to run in both baseline and normal modes")
    resolver_baseline.add_argument(
        "--against",
        required=False,
        help="Optional snapshot ID used when resolver route executes fresh delta",
    )
    resolver_baseline.add_argument(
        "--provider-hydration",
        required=False,
        choices=["probe", "full-repo"],
        default="probe",
        help="Provider usage capture mode for forced true-agent pass (default: probe for warm tests)",
    )
    resolver_baseline.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write resolver baseline comparison JSON output",
    )

    chat = subparsers.add_parser(
        "chat",
        help="Run direct resolver-first chat turn without MCP transport (default integration path)",
    )
    chat.add_argument("--path", required=True, help="Repository path for local semantic cache context")
    chat.add_argument("--question", required=True, help="User question for resolver-first chat")
    chat.add_argument("--file-path", required=False, help="Optional relative file path in editor context")
    chat.add_argument("--symbol", required=False, help="Optional symbol in editor context")
    chat.add_argument("--selection", required=False, help="Optional selected text excerpt")
    chat.add_argument(
        "--against",
        required=False,
        help="Optional snapshot ID used when resolver route executes fresh delta",
    )
    chat.add_argument(
        "--confidence-threshold",
        required=False,
        type=float,
        default=0.8,
        help="Quick-return threshold between 0.0 and 1.0 (default: 0.8)",
    )
    chat.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write direct chat JSON output",
    )
    chat.add_argument(
        "--use-sidecar-mock",
        action="store_true",
        help="Route via sidecar mock adapter for contract/integration validation",
    )

    resolve = subparsers.add_parser(
        "resolve",
        help="Alias for direct resolver-first chat path (preferred over MCP resolve tool)",
    )
    resolve.add_argument("--path", required=True, help="Repository path for local semantic cache context")
    resolve.add_argument("--question", required=True, help="User question for resolver-first chat")
    resolve.add_argument("--file-path", required=False, help="Optional relative file path in editor context")
    resolve.add_argument("--symbol", required=False, help="Optional symbol in editor context")
    resolve.add_argument("--selection", required=False, help="Optional selected text excerpt")
    resolve.add_argument(
        "--against",
        required=False,
        help="Optional snapshot ID used when resolver route executes fresh delta",
    )
    resolve.add_argument(
        "--confidence-threshold",
        required=False,
        type=float,
        default=0.8,
        help="Quick-return threshold between 0.0 and 1.0 (default: 0.8)",
    )
    resolve.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write direct chat JSON output",
    )
    resolve.add_argument(
        "--use-sidecar-mock",
        action="store_true",
        help="Route via sidecar mock adapter for contract/integration validation",
    )

    seed_edges = subparsers.add_parser(
        "seed-edges",
        help="Build chunk-chunk import edges via AST parsing (zero LLM cost)",
    )
    seed_edges.add_argument("--path", required=True, help="Project path to parse")
    seed_edges.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write edge-seeding result JSON",
    )

    export_session = subparsers.add_parser(
        "export-session",
        help="Bundle session artifacts into a shareable zip (privacy-scrubbed)",
    )
    export_session.add_argument("--path", required=True, help="Project path")
    export_session.add_argument(
        "--session-id",
        required=False,
        help="Optional session ID label embedded in the zip filename",
    )
    export_session.add_argument(
        "--window-days",
        required=False,
        type=int,
        default=7,
        help="Metrics window in days (default: 7)",
    )
    export_session.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write export manifest JSON",
    )
    export_session.add_argument(
        "--no-reveal",
        action="store_true",
        help="Do not open the containing folder in the OS file explorer after export",
    )

    import_bundle = subparsers.add_parser(
        "import-bundle",
        help="Import a shared .reason bundle (zip or directory) into the local cache",
    )
    import_bundle.add_argument("--path", required=True, help="Project path to import into")
    import_bundle.add_argument(
        "--bundle",
        required=True,
        help="Path to an export-session .zip or a reason bundle directory",
    )
    import_bundle.add_argument(
        "--skip-verify",
        action="store_true",
        help="Bypass shard hash verification (development only)",
    )
    import_bundle.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write the import summary JSON",
    )

    measure = subparsers.add_parser(
        "measure",
        help="Run a fixed question set through the engine and report route/token metrics",
    )
    measure.add_argument("--path", required=True, help="Project path to measure against")
    measure.add_argument(
        "--question-set",
        required=False,
        choices=["flask", "requests"],
        help="Built-in alpha question set (matches the alpha test protocol)",
    )
    measure.add_argument(
        "--questions",
        required=False,
        help="Path to a text file with one question per line (overrides --question-set)",
    )
    measure.add_argument(
        "--against",
        required=False,
        help="Optional snapshot ID to resolve questions against",
    )
    measure.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write the measurement report JSON",
    )

    session_start_ab = subparsers.add_parser(
        "session-start-ab",
        help="Measure scout-pack (engine on) vs full-repo (engine off) session-start token cost via live provider",
    )
    session_start_ab.add_argument(
        "--path",
        required=True,
        help="Project path to measure (run from the repo root so data/baselines resolves)",
    )
    session_start_ab.add_argument(
        "--against",
        required=False,
        help="Snapshot ID to measure against (default: latest in data/baselines)",
    )
    session_start_ab.add_argument(
        "--engine-off-tokens",
        required=False,
        type=int,
        help="Reuse a previously measured full-repo token count and skip the live full-repo run",
    )
    session_start_ab.add_argument(
        "--topk-k",
        required=False,
        type=int,
        default=12,
        help="K for the top-K retrieval baseline arm (default: 12, matches Jun 22 evidence artifact)",
    )
    session_start_ab.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write the measurement report JSON",
    )

    net_egress = subparsers.add_parser(
        "network-egress-check",
        help="Check A: verify zero outbound connections during local operations + telemetry schema (alpha test)",
    )
    net_egress.add_argument(
        "--path",
        required=True,
        help="Project path to ingest and probe",
    )
    net_egress.add_argument(
        "--json-out",
        required=False,
        help="Optional path to write the check result JSON",
    )

    return parser


def _print_not_implemented(command: str, target: str) -> None:
    print(f"[phase-0] '{command}' scaffold is active. Target: {target}")
    print("Implementation arrives in Phases 1-8.")


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    settings = load_settings()

    if not args.command:
        parser.print_help()
        return 0

    if args.command == "ingest":
        project_path = Path(args.path).resolve()
        payload = ingest_to_json(project_path)

        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[phase-1] ingest output written to {output_path}")
        else:
            print(payload)

        if args.write_snapshot:
            ingest_result = ingest_project(project_path)
            snapshot = build_snapshot_manifest(
                ingest=ingest_result,
                snapshot_id=args.snapshot_id,
            )
            snapshot_path = save_snapshot_manifest(snapshot)
            print(f"[phase-2] snapshot written to {snapshot_path}")
            print(f"[phase-2] snapshot_id={snapshot.snapshot_id}")
        return 0

    if args.command == "delta":
        project_path = Path(args.path).resolve()
        selected_playbook = args.playbook or settings.default_playbook
        against_id = args.against or latest_snapshot_id(project_path / "data" / "baselines")
        report = compute_delta_report(
            project_path,
            against_id,
            live_provider=args.live_provider,
            playbook=selected_playbook,
            provider_hydration=args.provider_hydration,
            progress=_print_progress,
        )
        save_delta_run_report(report)
        payload = json.dumps(report.to_dict(), indent=2)

        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[phase-2] delta output written to {output_path}")
        else:
            print(payload)
        return 0

    if args.command == "regenerate":
        project_path = Path(args.path).resolve()
        against_snapshot_id = args.against or latest_snapshot_id()
        payload = regeneration_to_json(project_path, against_snapshot_id)

        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[phase-6] regeneration output written to {output_path}")
        else:
            print(payload)
        return 0

    if args.command == "bootstrap":
        project_path = Path(args.path).resolve()
        payload = bootstrap_to_json(project_path, against_snapshot_id=args.against)

        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[phase-8] bootstrap output written to {output_path}")
        else:
            print(payload)
        return 0

    if args.command == "report":
        payload = load_delta_run_report(args.run)
        if args.raw:
            print(json.dumps(payload, indent=2))
            return 0

        summary = summarize_run_report(payload)
        print(json.dumps(summary.to_dict(), indent=2))
        return 0

    if args.command == "benchmark":
        project_path = Path(args.path).resolve()
        selected_playbook = args.playbook or settings.default_playbook
        payload = benchmark_to_json(
            project_path,
            against_snapshot_id=args.against,
            live_provider=args.live_provider,
            playbook=selected_playbook,
            include_changed_rerun=args.include_changed_rerun,
            provider_hydration=args.provider_hydration,
            progress=_print_progress,
        )

        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[phase-9] benchmark output written to {output_path}")
        else:
            print(payload)
        return 0

    if args.command == "sync":
        payload = sync_to_json(
            settings=settings,
            entry_type=args.entry_type,
            max_entries=args.max_entries,
            use_checkpoint=not args.no_checkpoint,
        )

        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[phase-9] sync output written to {output_path}")
        else:
            print(payload)
        return 0

    if args.command == "setup":
        project_path = Path(args.path).resolve()
        write_onboarding_artifacts(project_path, force=args.force)
        payload = onboarding_manifest_to_json(project_path)

        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[phase-10] setup output written to {output_path}")
        else:
            print(payload)
        return 0

    if args.command == "mcp":
        print(
            "[compatibility] MCP transport remains available for legacy/operator workflows. "
            "Default user path is direct resolver-first chat (`engine chat` / `engine resolve`).",
            file=sys.stderr,
        )
        project_path = Path(args.path).resolve()
        if args.status:
            print(json.dumps(mcp_server_status(project_path), indent=2))
            return 0
        if args.stop:
            print(json.dumps(stop_mcp_server(project_path), indent=2))
            return 0
        if args.verify_closed:
            print(json.dumps(verify_mcp_closed(project_path), indent=2))
            return 0
        run_mcp_server(project_path)
        return 0

    if args.command == "familiarization-pack":
        project_path = Path(args.path).resolve()
        payload = familiarization_pack_to_json(
            project_path=project_path,
            mode=args.mode,
            against_snapshot_id=args.against,
            query=args.query,
        )
        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[phase-12] familiarization pack output written to {output_path}")
        else:
            print(payload)
        return 0

    if args.command == "seed-topology":
        project_path = Path(args.path).resolve()
        scout_pack_path = project_path / "data" / "runs" / "shadow" / "scout-pack-latest.json"
        if not scout_pack_path.exists():
            print(f"[seed-topology] scout pack not found at {scout_pack_path}", file=sys.stderr)
            return 1
        scout_data = json.loads(scout_pack_path.read_text(encoding="utf-8"))
        read_order = scout_data.get("suggested_read_order", []) or []
        if not read_order:
            print("[seed-topology] no suggested_read_order in scout pack — skipping", file=sys.stderr)
            return 0
        top_entries = read_order[:10]
        lines = []
        for entry in top_entries:
            if isinstance(entry, dict):
                p = str(entry.get("path", ""))
                r = str(entry.get("reason", ""))
                lines.append(f"{p} — {r}" if r else p)
            else:
                lines.append(str(entry))
        outcome = "Workspace key files by importance:\n" + "\n".join(f"  {line}" for line in lines)
        chosen = lines[:4]
        card_payload = {
            "task_intent": "workspace topology: key modules, entry points, and package structure",
            "scope_fingerprint": "workspace",
            "outcome_summary": outcome,
            "chosen_plan": chosen,
        }
        result = commit_reasoning_card(
            project_root=project_path,
            card_payload=card_payload,
            source="topology_seed",
        )
        payload = json.dumps(result, indent=2)
        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[seed-topology] topology card committed, output written to {output_path}")
        else:
            print(payload)
        return 0

    if args.command == "reasoning-recall":
        project_path = Path(args.path).resolve()
        payload = json.dumps(
            recall_reasoning_cards(
                project_root=project_path,
                task_intent=args.intent,
                scope_fingerprint=args.scope,
                limit=args.limit,
            ),
            indent=2,
        )
        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[phase-11] reasoning recall output written to {output_path}")
        else:
            print(payload)
        return 0

    if args.command == "reasoning-commit":
        project_path = Path(args.path).resolve()
        payload_path = Path(args.json_in).resolve()
        card_payload = json.loads(payload_path.read_text(encoding="utf-8"))
        payload = json.dumps(
            commit_reasoning_card(
                project_root=project_path,
                card_payload=card_payload,
                source=args.source,
            ),
            indent=2,
        )
        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[phase-11] reasoning commit output written to {output_path}")
        else:
            print(payload)
        return 0

    if args.command == "reasoning-migrate-v2":
        project_path = Path(args.path).resolve()
        payload = json.dumps(
            migrate_reasoning_cards_to_v2(
                project_root=project_path,
                dry_run=bool(args.dry_run),
                limit=args.limit,
            ),
            indent=2,
        )
        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[phase-v2] reasoning migration output written to {output_path}")
        else:
            print(payload)
        return 0

    if args.command == "metrics-report":
        project_path = Path(args.path).resolve()
        payload = metrics_report_to_json(
            project_root=project_path,
            window_days=args.window_days,
            top_n=args.top_n,
        )
        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[phase-13] metrics report output written to {output_path}")
        else:
            print(payload)
        return 0

    if args.command == "resolver-baseline":
        project_path = Path(args.path).resolve()
        payload = resolver_baseline_comparison_to_json(
            project_root=project_path,
            question=args.question,
            against_snapshot_id=args.against,
            provider_hydration=args.provider_hydration,
        )
        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[phase-13b] resolver baseline output written to {output_path}")
        else:
            print(payload)
        return 0

    if args.command in {"chat", "resolve"}:
        project_path = Path(args.path).resolve()
        payload = json.dumps(
            run_direct_chat_turn(
                project_root=project_path,
                question=args.question,
                file_path=args.file_path,
                symbol=args.symbol,
                selection=args.selection,
                against_snapshot_id=args.against,
                confidence_threshold=args.confidence_threshold,
                sidecar_mock_mode=args.use_sidecar_mock,
            ),
            indent=2,
        )
        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[phase-14] direct chat output written to {output_path}")
        else:
            print(payload)
        return 0

    if args.command == "seed-edges":
        from .ast_edge_seeder import seed_edges_from_ast  # noqa: PLC0415 — lazy import
        from .graph_store import GraphStore
        project_path = Path(args.path).resolve()
        gs = GraphStore(project_path)
        result = seed_edges_from_ast(project_path, gs)
        payload = json.dumps(result, indent=2)
        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[seed-edges] output written to {output_path}")
        else:
            print(payload)
        return 0

    if args.command == "export-session":
        from .export_session import export_session_bundle  # noqa: PLC0415 — lazy import
        project_path = Path(args.path).resolve()
        result = export_session_bundle(
            project_root=project_path,
            session_id=args.session_id if args.session_id else None,
            window_days=args.window_days,
        )
        payload = json.dumps(result, indent=2)
        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[export] manifest written to {output_path}")
        else:
            print(payload)

        if result.get("status") == "ok":
            bundle_path = result.get("bundle_path")
            if bundle_path:
                print(f"[export] bundle written to {bundle_path}")
                if not args.no_reveal and _reveal_in_file_explorer(Path(bundle_path)):
                    print("[export] opened containing folder in file explorer")
        return 0 if result.get("status") == "ok" else 1

    if args.command == "import-bundle":
        from .import_session import import_session_bundle  # noqa: PLC0415 — lazy import
        project_path = Path(args.path).resolve()
        result = import_session_bundle(
            project_root=project_path,
            bundle=args.bundle,
            skip_verify=args.skip_verify,
        )
        payload = json.dumps(result, indent=2)
        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[import] summary written to {output_path}")
        else:
            print(payload)

        if result.get("status") == "ok":
            print(
                f"[import] committed={result.get('committed', 0)} "
                f"skipped={result.get('skipped', 0)} "
                f"bundle_id={result.get('bundle_id')}"
            )
            return 0
        print(f"[import] failed: {result.get('error')}")
        return 1

    if args.command == "measure":
        from .measure_session import measure_question_set  # noqa: PLC0415 — lazy import
        project_path = Path(args.path).resolve()
        result = measure_question_set(
            project_root=project_path,
            question_set=args.question_set,
            questions_file=args.questions,
            against_snapshot_id=args.against,
        )
        payload = json.dumps(result, indent=2)
        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[measure] report written to {output_path}")
        else:
            print(payload)
        return 0 if result.get("status") == "ok" else 1

    if args.command == "session-start-ab":
        from .session_start_ab import measure_session_start_ab  # noqa: PLC0415 — lazy import
        project_path = Path(args.path).resolve()
        result = measure_session_start_ab(
            project_path,
            snapshot_id=args.against,
            engine_off_tokens=args.engine_off_tokens,
            topk_k=args.topk_k,
            progress=lambda message: print(f"  [progress] {message}", file=sys.stderr),
        )
        payload = json.dumps(result, indent=2)
        if args.json_out:
            output_path = Path(args.json_out).resolve()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(payload, encoding="utf-8")
            print(f"[session-start-ab] report written to {output_path}")
        else:
            print(payload)
        return 0 if result.get("status") == "ok" else 1

    if args.command == "network-egress-check":
        from .network_egress_check import run_no_phone_home_check  # noqa: PLC0415
        project_path = Path(args.path).resolve()
        json_out = Path(args.json_out).resolve() if args.json_out else None
        result = run_no_phone_home_check(
            project_path,
            json_out=json_out,
            progress=lambda msg: print(f"  [progress] {msg}", file=sys.stderr),
        )
        payload = json.dumps(result, indent=2)
        if not args.json_out:
            print(payload)
        else:
            print(f"[network-egress-check] overall_pass={result['overall_pass']} report written to {args.json_out}")
        return 0 if result.get("overall_pass") else 1

    parser.print_help()
    return 1
