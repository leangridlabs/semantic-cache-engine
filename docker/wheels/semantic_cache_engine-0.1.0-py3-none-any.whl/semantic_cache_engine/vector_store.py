from __future__ import annotations

from abc import ABC, abstractmethod

from .cache import CacheBackend, create_cache_backend
from .settings import EngineSettings


class VectorStore(ABC):
    @abstractmethod
    def upsert_reference(
        self,
        chunk_id: str,
        chunk_hash: str,
        provider: str,
        model: str,
        vector_ref: str,
    ) -> None:
        raise NotImplementedError

    @abstractmethod
    def get_reference(
        self,
        chunk_id: str,
        chunk_hash: str,
        provider: str,
        model: str,
    ) -> str | None:
        raise NotImplementedError

    @abstractmethod
    def upsert_embedding(
        self,
        chunk_id: str,
        chunk_hash: str,
        values: list[float],
        provider: str,
        model: str,
    ) -> None:
        raise NotImplementedError

    @abstractmethod
    def get_embedding(
        self,
        chunk_id: str,
        chunk_hash: str,
        provider: str,
        model: str,
    ) -> list[float] | None:
        raise NotImplementedError


class CacheBackedVectorStore(VectorStore):
    def __init__(self, cache_backend: CacheBackend) -> None:
        self.cache_backend = cache_backend

    def upsert_reference(
        self,
        chunk_id: str,
        chunk_hash: str,
        provider: str,
        model: str,
        vector_ref: str,
    ) -> None:
        from .cache import build_vector_reference

        self.cache_backend.upsert_vector_reference(
            build_vector_reference(
                chunk_id=chunk_id,
                chunk_hash=chunk_hash,
                provider=provider,
                model=model,
                vector_ref=vector_ref,
            )
        )

    def get_reference(
        self,
        chunk_id: str,
        chunk_hash: str,
        provider: str,
        model: str,
    ) -> str | None:
        reference = self.cache_backend.get_vector_reference(
            chunk_id=chunk_id,
            chunk_hash=chunk_hash,
            provider=provider,
            model=model,
        )
        return reference.vector_ref if reference else None

    def upsert_embedding(
        self,
        chunk_id: str,
        chunk_hash: str,
        values: list[float],
        provider: str,
        model: str,
    ) -> None:
        from .cache import build_vector_embedding

        self.cache_backend.upsert_vector_embedding(
            build_vector_embedding(
                chunk_id=chunk_id,
                chunk_hash=chunk_hash,
                values=values,
                provider=provider,
                model=model,
            )
        )

    def get_embedding(
        self,
        chunk_id: str,
        chunk_hash: str,
        provider: str,
        model: str,
    ) -> list[float] | None:
        embedding = self.cache_backend.get_vector_embedding(
            chunk_id=chunk_id,
            chunk_hash=chunk_hash,
            provider=provider,
            model=model,
        )
        return embedding.values if embedding else None


def create_vector_store(settings: EngineSettings | None = None) -> VectorStore:
    backend = create_cache_backend(settings)
    backend.ensure_schema()
    return CacheBackedVectorStore(backend)
