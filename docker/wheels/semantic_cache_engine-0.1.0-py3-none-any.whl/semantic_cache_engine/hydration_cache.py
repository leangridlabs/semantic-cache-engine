"""
hydration_cache.py
==================
Per-turn hydration fragment cache for the DRQS near-miss resolution path.

Assembles a ``TurnContext`` from graph-walk results, deduplicates nodes
and edges, and runs a ``ValidationGate`` pass to classify the overall
trustworthiness of the context before it is handed to the resolver.

Public API
----------
``TurnContext``
    Dataclass holding primary_card, related_cards, artifacts, chunks,
    edges, lineage, gaps, validation, and an optional workflow_context
    hook (Phase 10 placeholder).

``HydrationCache(graph_store, settings)``
    ``build(top_candidates, question_intent, question_scope) -> TurnContext``
    Runs the full graph walk + DQA fill + gap detection pass and
    returns a hydrated TurnContext.

``ValidationGate``
    ``verify(turn_context) -> "trusted" | "partial" | "untrusted"``
    Classifies the TurnContext quality based on thresholds.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from .directed_query import DirectedQueryRouter
from .gap_detector import GapDetector, Gap
from .graph_navigator import GraphNavigator, GraphNeighborhood
from .graph_store import GraphStore
from .settings import EngineSettings


# ---------------------------------------------------------------------------
# TurnContext
# ---------------------------------------------------------------------------

@dataclass
class TurnContext:
    """All graph-derived context assembled for a single question turn."""

    primary_card: dict[str, Any] | None = None
    """The highest-scoring near-miss card node."""

    related_cards: list[dict[str, Any]] = field(default_factory=list)
    """Cards reachable from primary_card within the configured hop limit."""

    artifacts: list[dict[str, Any]] = field(default_factory=list)
    """Artifact nodes for chunks referenced by cards in this context."""

    chunks: list[dict[str, Any]] = field(default_factory=list)
    """Chunk nodes referenced by evidence anchor edges."""

    edges: list[dict[str, Any]] = field(default_factory=list)
    """All edges collected during the graph walk."""

    lineage: list[dict[str, Any]] = field(default_factory=list)
    """Supersession chain for primary_card (newest→oldest)."""

    gaps: list[Gap] = field(default_factory=list)
    """Gaps detected in the neighbourhood by GapDetector."""

    validation: str = "untrusted"
    """ValidationGate result: "trusted" | "partial" | "untrusted"."""

    node_count: int = 0
    """Total card + chunk node count across the neighbourhood."""

    scope_fingerprints: list[str] = field(default_factory=list)
    """Unique scope_fingerprints of all cards in context (for resolver routing hints)."""

    workflow_context: dict[str, Any] | None = None
    """Phase 10 hook — SCP workflow context.  None until portrait.py is built."""

    build_duration_ms: float = 0.0
    """Wall-clock time to build this context."""

    def is_useful(self, min_nodes: int = 2) -> bool:
        """True if the context has enough nodes to be worth returning."""
        return self.node_count >= min_nodes and self.validation != "untrusted"

    def to_dict(self) -> dict[str, Any]:
        return {
            "primary_card": self.primary_card,
            "related_cards": self.related_cards,
            "artifacts": self.artifacts,
            "chunks": self.chunks,
            "edges": self.edges,
            "lineage": self.lineage,
            "gaps": [
                {
                    "gap_type": g.gap_type,
                    "target_id": g.target_id,
                    "reason": g.reason,
                }
                for g in self.gaps
            ],
            "validation": self.validation,
            "node_count": self.node_count,
            "scope_fingerprints": self.scope_fingerprints,
            "workflow_context": self.workflow_context,
            "build_duration_ms": round(self.build_duration_ms, 1),
        }


# ---------------------------------------------------------------------------
# ValidationGate
# ---------------------------------------------------------------------------

class ValidationGate:
    """Classifies the trustworthiness of a TurnContext.

    Trusted:
      - At least 1 card with validation_state in ("trusted", "accepted", "captured", "verified", "")
      - At least 1 artifact  OR  primary_card has non-empty dependency_fingerprint
      - < 50% of cards are "unverified" or explicitly untrusted

    Partial:
      - At least 1 card but no dependency data
      - OR no artifacts but at least 1 chunk

    Untrusted:
      - Everything else
    """

    # States that indicate a card was committed via a legitimate workflow.
    # Includes schema version tags that the early migration stored as validation_state.
    _VALID_STATES = frozenset((
        "trusted", "accepted", "captured", "verified",
        "preliminary", "reason-v2", "reason-v1", "",
    ))

    def verify(self, ctx: TurnContext) -> str:
        if not ctx.primary_card:
            return "untrusted"

        all_cards = [ctx.primary_card] + ctx.related_cards
        trusted_cards = [
            c for c in all_cards
            if str(c.get("validation_state", "")).strip().lower() in self._VALID_STATES
        ]
        stale_or_bad = len(all_cards) - len(trusted_cards)

        has_artifacts = bool(ctx.artifacts)
        primary_dep = str((ctx.primary_card or {}).get("dependency_fingerprint", "")).strip()
        has_dependency_data = has_artifacts or bool(primary_dep)

        if (
            trusted_cards
            and has_dependency_data
            and (stale_or_bad / max(1, len(all_cards))) < 0.5
        ):
            return "trusted"

        if trusted_cards or ctx.chunks:
            return "partial"

        return "untrusted"


# ---------------------------------------------------------------------------
# HydrationCache
# ---------------------------------------------------------------------------

class HydrationCache:
    """Builds a TurnContext from near-miss candidates.

    Called by the resolver when a question falls in the near-miss score band.
    Runs within `drqs_graph_walk_timeout_ms` and returns whatever it has
    collected on timeout.
    """

    def __init__(self, graph_store: GraphStore, settings: EngineSettings) -> None:
        self._gs = graph_store
        self._settings = settings
        self._nav = GraphNavigator(graph_store)
        self._det = GapDetector(graph_store)
        self._dqa = DirectedQueryRouter(graph_store)
        self._gate = ValidationGate()

    def build(
        self,
        top_candidates: list[dict[str, Any]],
        question_intent: str = "",
        question_scope: str = "",
    ) -> TurnContext:
        """Build a TurnContext from a list of near-miss candidate cards.

        Each candidate dict must have at least ``card_id`` and ``score``.
        Returns within ``drqs_graph_walk_timeout_ms`` by bailing early.
        """
        ctx = TurnContext()
        t0 = time.monotonic()
        timeout_s = self._settings.drqs_graph_walk_timeout_ms / 1000.0

        try:
            if not top_candidates:
                return ctx

            # Sort by score descending
            candidates = sorted(
                top_candidates, key=lambda c: float(c.get("score", 0.0)), reverse=True
            )
            primary_card_id = candidates[0].get("card_id", "")
            if not primary_card_id:
                return ctx

            # --- Primary card ---
            ctx.primary_card = self._gs.get_card(primary_card_id)

            # --- Neighbourhood walk ---
            card_ids = [c["card_id"] for c in candidates if c.get("card_id")]
            neighborhood: GraphNeighborhood = self._nav.expand_multi(
                card_ids, hops=1
            )

            if (time.monotonic() - t0) > timeout_s:
                ctx.build_duration_ms = (time.monotonic() - t0) * 1000
                return self._finalise(ctx, neighborhood)

            # --- DQA gap-fill: fetch full card data for any cards only partially known ---
            seen_card_ids: set[str] = set()
            for card in neighborhood.cards:
                cid = card.get("card_id", "")
                if cid:
                    seen_card_ids.add(cid)
                    if cid == primary_card_id:
                        ctx.primary_card = card
                    else:
                        ctx.related_cards.append(card)

            ctx.chunks = neighborhood.chunks
            ctx.artifacts = neighborhood.artifacts
            ctx.edges = neighborhood.edges

            if (time.monotonic() - t0) > timeout_s:
                ctx.build_duration_ms = (time.monotonic() - t0) * 1000
                return self._finalise(ctx, neighborhood)

            # --- Lineage chain for primary card ---
            lineage_result = self._dqa.get_supersession_chain(primary_card_id)
            if lineage_result.has_data and isinstance(lineage_result.data, list):
                ctx.lineage = lineage_result.data

            if (time.monotonic() - t0) > timeout_s:
                ctx.build_duration_ms = (time.monotonic() - t0) * 1000
                return self._finalise(ctx, neighborhood)

            # --- Gap detection ---
            ctx.gaps = self._det.find_gaps(neighborhood)

        except Exception:
            pass

        ctx.build_duration_ms = (time.monotonic() - t0) * 1000
        return self._finalise(ctx, neighborhood if 'neighborhood' in dir() else GraphNeighborhood())

    def _finalise(self, ctx: TurnContext, neighborhood: GraphNeighborhood) -> TurnContext:
        """Compute derived fields and run ValidationGate."""
        # Scope fingerprints
        all_cards = ([ctx.primary_card] if ctx.primary_card else []) + ctx.related_cards
        seen_scopes: list[str] = []
        seen_scope_set: set[str] = set()
        for card in all_cards:
            sf = str(card.get("scope_fingerprint", "")).strip() if card else ""
            if sf and sf not in seen_scope_set:
                seen_scope_set.add(sf)
                seen_scopes.append(sf)
        ctx.scope_fingerprints = seen_scopes

        # Node count
        ctx.node_count = neighborhood.node_count or (
            (1 if ctx.primary_card else 0)
            + len(ctx.related_cards)
            + len(ctx.chunks)
        )

        # Validation
        ctx.validation = self._gate.verify(ctx)

        return ctx
