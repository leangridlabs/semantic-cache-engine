from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
import uuid

TELEMETRY_SCHEMA_VERSION = "telemetry-event/v1"
FORBIDDEN_PAYLOAD_KEYS = {
    "code",
    "source_code",
    "file_contents",
    "prompt",
    "selection_text",
    "raw_text",
    "embedding_text",
}


@dataclass(frozen=True)
class TelemetryIdentity:
    tenant_id: str
    install_id: str
    session_id: str
    run_id: str
    app_version: str
    sidecar_version: str
    policy_bundle_version: str


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def build_telemetry_event(
    *,
    event_name: str,
    identity: TelemetryIdentity,
    metrics: dict[str, Any],
    event_id: str | None = None,
) -> dict[str, Any]:
    payload = {
        "schema": TELEMETRY_SCHEMA_VERSION,
        "event_id": event_id or f"telemetry-{uuid.uuid4().hex[:12]}",
        "event_name": event_name,
        "event_time_utc": utc_now_iso(),
        "identity": {
            "tenant_id": identity.tenant_id,
            "install_id": identity.install_id,
            "session_id": identity.session_id,
            "run_id": identity.run_id,
            "app_version": identity.app_version,
            "sidecar_version": identity.sidecar_version,
            "policy_bundle_version": identity.policy_bundle_version,
        },
        "metrics": metrics,
    }
    return payload


def validate_telemetry_event(event: dict[str, Any]) -> tuple[bool, list[str]]:
    errors: list[str] = []
    if not isinstance(event, dict):
        return False, ["event must be an object"]

    if event.get("schema") != TELEMETRY_SCHEMA_VERSION:
        errors.append("schema mismatch")

    for field in ("event_id", "event_name", "event_time_utc", "identity", "metrics"):
        if field not in event:
            errors.append(f"missing field: {field}")

    identity = event.get("identity", {})
    if isinstance(identity, dict):
        for field in (
            "tenant_id",
            "install_id",
            "session_id",
            "run_id",
            "app_version",
            "sidecar_version",
            "policy_bundle_version",
        ):
            if field not in identity:
                errors.append(f"missing identity field: {field}")
    else:
        errors.append("identity must be an object")

    metrics = event.get("metrics", {})
    if not isinstance(metrics, dict):
        errors.append("metrics must be an object")
    else:
        forbidden = _find_forbidden_keys(metrics)
        if forbidden:
            for key in forbidden:
                errors.append(f"forbidden telemetry key: {key}")

    return len(errors) == 0, errors


def _find_forbidden_keys(payload: dict[str, Any]) -> list[str]:
    found: list[str] = []

    def _walk(value: Any) -> None:
        if isinstance(value, dict):
            for key, nested in value.items():
                if str(key).strip().lower() in FORBIDDEN_PAYLOAD_KEYS:
                    found.append(str(key))
                _walk(nested)
            return
        if isinstance(value, list):
            for item in value:
                _walk(item)

    _walk(payload)
    return found
