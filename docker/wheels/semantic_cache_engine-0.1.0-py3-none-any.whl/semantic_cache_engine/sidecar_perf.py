from __future__ import annotations

from dataclasses import dataclass
import statistics
import time
from typing import Any

from .sidecar_adapter import MockSidecarAdapter


@dataclass(frozen=True)
class SidecarPerfSample:
    handshake_ms: float
    resolve_ms: float


def _quantile(values: list[float], q: float) -> float:
    if not values:
        return 0.0
    if len(values) == 1:
        return values[0]
    values = sorted(values)
    index = max(0, min(len(values) - 1, round((len(values) - 1) * q)))
    return values[index]


def run_sidecar_perf_benchmark(
    *,
    iterations: int = 200,
    question: str = "Build a scout familiarization pack",
) -> dict[str, Any]:
    adapter = MockSidecarAdapter()

    handshake_samples: list[float] = []
    resolve_samples: list[float] = []

    count = max(1, int(iterations))
    for idx in range(count):
        t0 = time.perf_counter()
        adapter.handshake(
            client_name="semantic-cache-engine",
            client_version="phase-14",
            requested_capabilities=["resolve_question"],
        )
        t1 = time.perf_counter()
        adapter.resolve(
            trace_id=f"perf-{idx}",
            question=question,
            workspace_root="C:/repo",
            editor_context={},
        )
        t2 = time.perf_counter()

        handshake_samples.append((t1 - t0) * 1000.0)
        resolve_samples.append((t2 - t1) * 1000.0)

    return {
        "iterations": count,
        "handshake_ms": {
            "p50": round(_quantile(handshake_samples, 0.5), 6),
            "p95": round(_quantile(handshake_samples, 0.95), 6),
            "p99": round(_quantile(handshake_samples, 0.99), 6),
            "mean": round(statistics.fmean(handshake_samples), 6),
        },
        "resolve_ms": {
            "p50": round(_quantile(resolve_samples, 0.5), 6),
            "p95": round(_quantile(resolve_samples, 0.95), 6),
            "p99": round(_quantile(resolve_samples, 0.99), 6),
            "mean": round(statistics.fmean(resolve_samples), 6),
        },
    }
