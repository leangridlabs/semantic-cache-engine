"""
portrait.py
===========
Semantic Coverage Portrait (SCP) — Phase 10 of the DRQS build.

Generates a zero-LLM-call structured portrait of the workspace reasoning
coverage, built entirely from existing reasoning cards and the dependency
graph stored in ``GraphStore``.

A portrait answers: "Which modules are well-covered by reasoning cards,
which are weak, and what are the top-level workflow chains?"

Public API
----------
``generate(project_root) -> Portrait``
    Build the full portrait for the workspace.  Returns a ``Portrait``
    dataclass suitable for inclusion in resolver handoff payloads or
    MCP tool responses.

``Portrait``
    Dataclass: module_portraits, workflow_chains, coverage_map,
    generated_at, node_count, coverage_score.

``ModulePortrait``
    Per-module summary: scope, card_count, top_card_id, gap_count,
    has_artifact, importance_rank.

``WorkflowChain``
    A sequence of module scopes connected by supersession or dependency edges.

``CoverageMap``
    Dict[scope_fingerprint → coverage level: "strong"|"partial"|"weak"|"missing"]
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from .graph_store import GraphStore


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class ModulePortrait:
    scope: str
    card_count: int = 0
    top_card_id: str | None = None
    top_card_intent: str | None = None
    gap_count: int = 0
    has_artifact: bool = False
    importance_rank: int = 9999

    def coverage_level(self) -> str:
        if self.card_count >= 3 and not self.gap_count:
            return "strong"
        if self.card_count >= 1:
            return "partial"
        return "weak"


@dataclass
class WorkflowChain:
    chain_id: str
    scopes: list[str]
    edge_type: str  # "supersession" | "shared_scope" | "dependency"
    depth: int


@dataclass
class Portrait:
    module_portraits: list[ModulePortrait] = field(default_factory=list)
    workflow_chains: list[WorkflowChain] = field(default_factory=list)
    coverage_map: dict[str, str] = field(default_factory=dict)
    """scope_fingerprint → "strong" | "partial" | "weak" | "missing" """
    generated_at: str = ""
    node_count: int = 0
    coverage_score: float = 0.0
    """Fraction of known modules with at least "partial" coverage."""
    build_duration_ms: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "module_portraits": [
                {
                    "scope": mp.scope,
                    "card_count": mp.card_count,
                    "top_card_id": mp.top_card_id,
                    "top_card_intent": mp.top_card_intent,
                    "gap_count": mp.gap_count,
                    "has_artifact": mp.has_artifact,
                    "importance_rank": mp.importance_rank,
                    "coverage_level": mp.coverage_level(),
                }
                for mp in self.module_portraits
            ],
            "workflow_chains": [
                {
                    "chain_id": wc.chain_id,
                    "scopes": wc.scopes,
                    "edge_type": wc.edge_type,
                    "depth": wc.depth,
                }
                for wc in self.workflow_chains
            ],
            "coverage_map": self.coverage_map,
            "generated_at": self.generated_at,
            "node_count": self.node_count,
            "coverage_score": round(self.coverage_score, 3),
            "build_duration_ms": round(self.build_duration_ms, 1),
        }


# ---------------------------------------------------------------------------
# Generator
# ---------------------------------------------------------------------------

class PortraitGenerator:
    """Builds a Portrait from the reasoning graph.  Zero LLM calls."""

    def __init__(self, graph_store: GraphStore) -> None:
        self._gs = graph_store

    def generate(self) -> Portrait:
        t0 = time.monotonic()
        portrait = Portrait(generated_at=datetime.now(timezone.utc).isoformat())

        try:
            import sqlite3
            db_path = self._gs._db_path

            with sqlite3.connect(str(db_path), timeout=10.0) as conn:
                conn.row_factory = sqlite3.Row

                # --- Module portraits from reasoning_cards ---
                cards = conn.execute(
                    """
                    SELECT card_id, scope_fingerprint, task_intent,
                           dependency_fingerprint
                    FROM reasoning_cards
                    ORDER BY scope_fingerprint ASC, rowid ASC
                    """
                ).fetchall()

                # Group by module (first segment of scope_fingerprint)
                scope_map: dict[str, list[dict]] = {}
                for card in cards:
                    scope = str(card["scope_fingerprint"]).strip()
                    if scope not in scope_map:
                        scope_map[scope] = []
                    scope_map[scope].append(dict(card))

                # Chunk importance ranks
                chunk_ranks: dict[str, int] = {}
                for row in conn.execute("SELECT chunk_id, importance_rank FROM chunks"):
                    chunk_ranks[row["chunk_id"]] = row["importance_rank"]

                # Artifact chunk set
                artifact_chunk_ids: set[str] = set(
                    row["chunk_id"]
                    for row in conn.execute("SELECT chunk_id FROM reasoning_artifacts")
                )

                # card→chunk edges for artifact lookup
                card_chunk_map: dict[str, list[str]] = {}
                for row in conn.execute("SELECT from_card_id, to_chunk_id FROM card_chunk_edges"):
                    card_chunk_map.setdefault(row["from_card_id"], []).append(row["to_chunk_id"])

                # card→card edges for workflow chains
                card_card_edges = [
                    dict(row)
                    for row in conn.execute(
                        "SELECT from_card_id, to_card_id, edge_type FROM card_card_edges"
                    )
                ]

                # Build module portraits
                module_portraits: list[ModulePortrait] = []
                coverage_map: dict[str, str] = {}
                for scope, scope_cards in sorted(scope_map.items()):
                    top = scope_cards[0]
                    # Check if any card for this scope has an artifact-linked chunk
                    has_artifact = any(
                        chunk_id in artifact_chunk_ids
                        for card in scope_cards
                        for chunk_id in card_chunk_map.get(card["card_id"], [])
                    )
                    # Gaps: cards with empty dependency_fingerprint
                    gap_count = sum(
                        1 for c in scope_cards
                        if not str(c.get("dependency_fingerprint", "")).strip()
                    )
                    # Importance rank from chunk ranks (use best/lowest rank)
                    importance_rank = min(
                        (
                            chunk_ranks.get(chunk_id, 9999)
                            for card in scope_cards
                            for chunk_id in card_chunk_map.get(card["card_id"], [])
                        ),
                        default=9999,
                    )
                    mp = ModulePortrait(
                        scope=scope,
                        card_count=len(scope_cards),
                        top_card_id=top["card_id"],
                        top_card_intent=top["task_intent"][:100],
                        gap_count=gap_count,
                        has_artifact=has_artifact,
                        importance_rank=importance_rank,
                    )
                    module_portraits.append(mp)
                    coverage_map[scope] = mp.coverage_level()

                portrait.module_portraits = module_portraits
                portrait.coverage_map = coverage_map
                portrait.node_count = len(cards)

                # Coverage score: % of scopes with "partial" or "strong"
                if coverage_map:
                    covered = sum(
                        1 for lvl in coverage_map.values()
                        if lvl in ("strong", "partial")
                    )
                    portrait.coverage_score = covered / len(coverage_map)

                # --- Workflow chains from card→card edges ---
                portrait.workflow_chains = self._build_workflow_chains(
                    card_card_edges, scope_map
                )

        except Exception:
            pass

        portrait.build_duration_ms = (time.monotonic() - t0) * 1000
        return portrait

    def _build_workflow_chains(
        self,
        edges: list[dict],
        scope_map: dict[str, list[dict]],
    ) -> list[WorkflowChain]:
        """Build workflow chains from card→card edges.

        Groups edges by edge_type and finds connected scope sequences.
        Returns chains with depth >= 2 only (trivial single-scope not useful).
        """
        chains: list[WorkflowChain] = []

        # Build adjacency: card_id → set of connected card_ids
        adj: dict[str, set[str]] = {}
        edge_types: dict[tuple[str, str], str] = {}
        for edge in edges:
            f = edge["from_card_id"]
            t = edge["to_card_id"]
            adj.setdefault(f, set()).add(t)
            adj.setdefault(t, set()).add(f)
            edge_types[(f, t)] = edge.get("edge_type", "")
            edge_types[(t, f)] = edge.get("edge_type", "")

        # Find card → scope mapping
        card_scope: dict[str, str] = {}
        for scope, cards in scope_map.items():
            for card in cards:
                card_scope[card["card_id"]] = scope

        # Connected components (scope-level)
        visited_cards: set[str] = set()
        chain_idx = 0

        for start_card in list(adj.keys()):
            if start_card in visited_cards:
                continue

            # BFS from start_card
            component_cards: list[str] = []
            component_scopes: list[str] = []
            seen_scopes: set[str] = set()
            queue = [start_card]
            local_visited: set[str] = {start_card}

            while queue:
                current = queue.pop(0)
                component_cards.append(current)
                scope = card_scope.get(current, "unknown")
                if scope not in seen_scopes:
                    seen_scopes.add(scope)
                    component_scopes.append(scope)

                for neighbor in adj.get(current, set()):
                    if neighbor not in local_visited:
                        local_visited.add(neighbor)
                        queue.append(neighbor)

            visited_cards.update(local_visited)

            if len(component_scopes) >= 2:
                # Determine dominant edge type
                dominant_type = "supersession"
                for card in component_cards:
                    for neighbor in adj.get(card, set()):
                        et = edge_types.get((card, neighbor), "")
                        if et in ("shared_scope", "semantic_neighbor"):
                            dominant_type = et
                            break

                chain_idx += 1
                chains.append(WorkflowChain(
                    chain_id=f"chain-{chain_idx:03d}",
                    scopes=component_scopes,
                    edge_type=dominant_type,
                    depth=len(component_scopes),
                ))

        # Sort by depth descending
        chains.sort(key=lambda c: c.depth, reverse=True)
        return chains[:20]  # Top 20 chains


# ---------------------------------------------------------------------------
# Public generate() shortcut
# ---------------------------------------------------------------------------

def generate(project_root: "Path") -> Portrait:
    """Build a Portrait for the workspace at project_root.  Never raises."""
    try:
        from pathlib import Path
        gs = GraphStore(Path(project_root).resolve())
        gen = PortraitGenerator(gs)
        return gen.generate()
    except Exception:
        return Portrait(generated_at=datetime.now(timezone.utc).isoformat())
