from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import fnmatch
import json
import os
import sys
from pathlib import Path
from typing import Callable

# On Windows, OneDrive placeholder files (cloud-only, not locally available)
# will block os.stat() indefinitely waiting for download.
# FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS (0x400000) and
# FILE_ATTRIBUTE_RECALL_ON_OPEN (0x40000) identify these files.
# GetFileAttributesW returns instantly even for placeholder files.
_ONEDRIVE_RECALL_FLAGS = 0x400000 | 0x40000
if sys.platform == "win32":
    import ctypes
    _GetFileAttributesW = ctypes.windll.kernel32.GetFileAttributesW
    _GetFileAttributesW.restype = ctypes.c_uint32

    def _is_onedrive_placeholder(path: Path) -> bool:
        attrs = _GetFileAttributesW(str(path))
        if attrs == 0xFFFFFFFF:  # INVALID_FILE_ATTRIBUTES — unreadable, skip to avoid hang
            return True
        return bool(attrs & _ONEDRIVE_RECALL_FLAGS)
else:
    def _is_onedrive_placeholder(path: Path) -> bool:
        return False

from .chunking.dispatcher import dispatch_chunk, is_supported_path
from .chunking.models import Chunk
from .chunking.normalization import normalize_text
from .hashing.sha256 import sha256_hex

IGNORED_DIRS = {
    ".git",
    "__pycache__",
    ".venv",
    "venv",
    "node_modules",
    ".pytest_cache",
    "baselines",
    "cache",
    "deltas",
    "runs",
    "dist",
    "build",
    "runtime",
}


@dataclass(frozen=True)
class IngestResult:
    run_utc: str
    project_root: str
    file_count: int
    chunk_count: int
    estimated_tokens: int
    token_budget_exhausted: bool
    chunks: list[Chunk]

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["chunks"] = [asdict(chunk) for chunk in self.chunks]
        return payload


def _walk_files(root: Path) -> "Generator[Path, None, None]":
    """Walk root yielding files, pruning IGNORED_DIRS directories without descending into them."""
    from typing import Generator
    import os

    for dirpath, dirnames, filenames in os.walk(root):
        # Prune ignored dirs in-place so os.walk won't descend into them
        dirnames[:] = [d for d in dirnames if d not in IGNORED_DIRS]
        dp = Path(dirpath)
        for fname in filenames:
            yield dp / fname


def _iter_files(
    project_path: Path,
    include_patterns: list[str] | None = None,
    exclude_patterns: list[str] | None = None,
    max_file_bytes: int | None = None,
) -> list[Path]:
    include_patterns = include_patterns or ["**"]
    exclude_patterns = exclude_patterns or []

    files: list[Path] = []
    for file_path in _walk_files(project_path):
        # Skip OneDrive cloud-only placeholders before calling is_file() —
        # os.stat() on these blocks indefinitely waiting for download.
        if _is_onedrive_placeholder(file_path):
            continue

        if not file_path.is_file():
            continue

        relative_path = file_path.relative_to(project_path).as_posix()
        if not is_supported_path(relative_path):
            continue

        if not _matches_any(relative_path, include_patterns):
            continue

        if _matches_any(relative_path, exclude_patterns):
            continue

        if max_file_bytes is not None and file_path.stat().st_size > max_file_bytes:
            continue

        files.append(file_path)

    files.sort(key=lambda p: str(p).lower())
    return files


def ingest_project(
    project_path: Path,
    progress: Callable[[str], None] | None = None,
    heartbeat_every: int = 100,
    include_patterns: list[str] | None = None,
    exclude_patterns: list[str] | None = None,
    max_file_bytes: int | None = None,
    token_budget: int | None = None,
) -> IngestResult:
    # Windows console host can fire spurious KeyboardInterrupt at any bytecode
    # boundary (codec init, hashing, etc.). Retry once before propagating.
    try:
        return _ingest_project_inner(
            project_path, progress, heartbeat_every,
            include_patterns, exclude_patterns, max_file_bytes, token_budget,
        )
    except KeyboardInterrupt:
        return _ingest_project_inner(
            project_path, progress, heartbeat_every,
            include_patterns, exclude_patterns, max_file_bytes, token_budget,
        )


def _ingest_project_inner(
    project_path: Path,
    progress: Callable[[str], None] | None = None,
    heartbeat_every: int = 100,
    include_patterns: list[str] | None = None,
    exclude_patterns: list[str] | None = None,
    max_file_bytes: int | None = None,
    token_budget: int | None = None,
) -> IngestResult:
    root = project_path.resolve()
    chunks: list[Chunk] = []
    file_count = 0
    scanned_count = 0
    estimated_tokens = 0
    token_budget_exhausted = False

    files = _iter_files(
        root,
        include_patterns=include_patterns,
        exclude_patterns=exclude_patterns,
        max_file_bytes=max_file_bytes,
    )
    if progress:
        progress(f"ingest: discovered {len(files)} supported file(s)")

    for file_path in files:
        scanned_count += 1
        try:
            text = file_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            text = file_path.read_text(encoding="utf-8", errors="ignore")
        except KeyboardInterrupt:
            raise
        except OSError:
            continue

        relative_path = file_path.relative_to(root).as_posix()
        seeds = dispatch_chunk(relative_path, text)
        if not seeds:
            continue

        file_count += 1
        for seed in seeds:
            normalized_content = normalize_text(seed.content)
            if not normalized_content:
                continue

            chunk_token_estimate = _estimate_tokens(normalized_content)
            if token_budget is not None and estimated_tokens + chunk_token_estimate > token_budget:
                token_budget_exhausted = True
                if progress:
                    progress(
                        f"ingest: token budget reached at ~{estimated_tokens} tokens; "
                        f"budget={token_budget}"
                    )
                break

            chunk_hash = sha256_hex(normalized_content)
            chunk_id = sha256_hex(f"{seed.path}::{seed.anchor}::{normalized_content}")
            chunks.append(
                Chunk(
                    chunk_id=chunk_id,
                    path=seed.path,
                    language=seed.language,
                    anchor=seed.anchor,
                    hash=chunk_hash,
                    char_count=len(normalized_content),
                    module_name=seed.module_name,
                    symbol_name=seed.symbol_name,
                    unit_id=seed.unit_id,
                )
            )
            estimated_tokens += chunk_token_estimate

        if token_budget_exhausted:
            break

        if progress and heartbeat_every > 0 and scanned_count % heartbeat_every == 0:
            progress(
                f"ingest: processed {scanned_count}/{len(files)} file(s); "
                f"chunk_count={len(chunks)}"
            )

    chunks.sort(key=lambda item: (item.path, item.anchor, item.chunk_id))

    result = IngestResult(
        run_utc=datetime.now(timezone.utc).isoformat(),
        project_root=str(root),
        file_count=file_count,
        chunk_count=len(chunks),
        estimated_tokens=estimated_tokens,
        token_budget_exhausted=token_budget_exhausted,
        chunks=chunks,
    )
    if progress:
        progress(
            f"ingest: complete file_count={result.file_count}, chunk_count={result.chunk_count}"
        )
    return result


def ingest_to_json(project_path: Path) -> str:
    try:
        result = ingest_project(project_path)
    except KeyboardInterrupt:
        # Windows console host can fire SIGINT spuriously during codec init;
        # retry once before propagating.
        result = ingest_project(project_path)
    return json.dumps(result.to_dict(), indent=2)


def collect_hydration_documents(
    project_path: Path,
    include_patterns: list[str] | None = None,
    exclude_patterns: list[str] | None = None,
    max_file_bytes: int | None = None,
) -> list[str]:
    root = project_path.resolve()
    documents: list[str] = []
    files = _iter_files(
        root,
        include_patterns=include_patterns,
        exclude_patterns=exclude_patterns,
        max_file_bytes=max_file_bytes,
    )

    for file_path in files:
        try:
            text = file_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            text = file_path.read_text(encoding="utf-8", errors="ignore")
        except KeyboardInterrupt:
            raise
        except OSError:
            continue

        relative_path = file_path.relative_to(root).as_posix()
        documents.append(f"FILE: {relative_path}\n{text}")

    return documents


def _matches_any(relative_path: str, patterns: list[str]) -> bool:
    for pattern in patterns:
        if fnmatch.fnmatch(relative_path, pattern):
            return True
    return False


def _estimate_tokens(text: str) -> int:
    # Conservative approximation for budget gating; avoids provider dependency.
    return max(len(text) // 4, 1)
