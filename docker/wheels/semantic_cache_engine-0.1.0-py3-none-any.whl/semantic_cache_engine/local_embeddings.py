from __future__ import annotations

import math
import re
from typing import Iterable

_TOKEN_PATTERN = re.compile(r"[a-zA-Z0-9_]+")


def build_local_embedding(text: str, dimensions: int = 256) -> list[float]:
    if dimensions <= 0:
        raise ValueError("Embedding dimensions must be positive")

    vector = [0.0] * dimensions
    token_count = 0

    for token in _iter_tokens(text):
        token_count += 1
        bucket = (hash(token) & 0x7FFFFFFF) % dimensions
        sign = 1.0 if ((hash(token + "::sign") & 1) == 0) else -1.0
        vector[bucket] += sign

    if token_count == 0:
        return vector

    norm = math.sqrt(sum(value * value for value in vector))
    if norm <= 0.0:
        return vector

    return [value / norm for value in vector]


def _iter_tokens(text: str) -> Iterable[str]:
    for match in _TOKEN_PATTERN.finditer(text.lower()):
        token = match.group(0)
        if token:
            yield token
