from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class OperationSpend:
    operation_type: str
    run_count: int
    runtime_seconds_total: float
    runtime_seconds_avg: float
    projected_actual_tokens_total: int
    projected_saved_tokens_total: int
    measured_provider_tokens_total: int
    measured_saved_tokens_total: int
    measured_run_count: int
    semantic_scored_pair_count: int
    semantic_pass_count: int
    semantic_average_similarity: float | None
    semantic_pass_rate: float | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ChurnGuardEpisode:
    """A single contiguous period in which the guard was not in FULL mode.

    An episode starts when a run exits FULL (mode becomes dry_run or passive)
    and ends when the mode returns to FULL.  Each episode records what happened
    during the suppressed stretch so you can tune thresholds and cooldowns.
    """

    start_run_id: str
    end_run_id: str | None
    """None if the episode has not yet closed within the report window."""
    start_utc: str
    end_utc: str | None
    peak_mode: str
    """Worst mode reached during the episode: 'dry_run' or 'passive'."""
    run_count: int
    """Number of consecutive runs that were not FULL."""
    self_edit_triggered: bool
    """True if any run in this episode was triggered by the self-edit fast path."""
    min_confidence: float | None
    max_confidence: float | None
    min_smoothed_hit_rate: float | None
    max_smoothed_churn_rate: float | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ChurnGuardTelemetry:
    """Aggregated churn-guard statistics over the report window.

    Intended for threshold tuning and support visibility.
    """

    total_runs: int
    full_runs: int
    dry_run_runs: int
    passive_runs: int
    guard_disabled_runs: int
    """Runs where the guard was explicitly disabled (guard_disabled reason)."""

    suppression_rate: float
    """(dry_run + passive) / total_runs.  High value → thresholds may be too sensitive."""

    episode_count: int
    """Number of distinct non-FULL episodes (contiguous stretches)."""
    episodes: list[ChurnGuardEpisode]
    open_episode: bool
    """True if the latest episode has not yet returned to FULL within the window."""

    avg_episode_run_length: float | None
    """Mean number of runs per episode.  Long episodes → cooldown may be too long,
    OR the cache genuinely isn't warming (tuning signal)."""
    max_episode_run_length: int | None

    self_edit_episode_count: int
    """Episodes that were triggered at least partly by self-edit detection."""

    avg_confidence_at_entry: float | None
    """Mean smoothed confidence score at the first run of each episode.
    Very low values confirm the guard is activating under genuinely poor conditions.
    Values near the threshold suggest borderline / false-positive risk."""
    avg_confidence_at_exit: float | None
    """Mean confidence at the last run before returning to FULL.
    Should be >= full_confidence_threshold; if lower, cooldown may have masked it."""

    avg_smoothed_hit_rate: float | None
    """Mean EMA hit rate across all window runs (any mode)."""
    avg_smoothed_churn_rate: float | None
    """Mean EMA active-churn rate across all window runs (any mode)."""

    tokens_skipped_dry_run: int
    """Runs in dry_run mode produce 0 provider tokens; this is the total projected
    baseline tokens for those runs — i.e., the lower bound of what was NOT spent."""
    tokens_skipped_passive: int
    """Same for passive-mode runs."""

    tuning_notes: list[str]
    """Human-readable observations derived from the numbers above."""

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["episodes"] = [e.to_dict() for e in self.episodes]
        return d


@dataclass(frozen=True)
class MetricsWindowReport:
    generated_utc: str
    window_days: int
    report_dir: str
    total_runs_discovered: int
    runs_in_window: int
    metric_source: str
    totals: dict[str, Any]
    operation_breakdown: list[OperationSpend]
    top_token_operations: list[OperationSpend]
    churn_guard_telemetry: ChurnGuardTelemetry | None

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["operation_breakdown"] = [item.to_dict() for item in self.operation_breakdown]
        payload["top_token_operations"] = [item.to_dict() for item in self.top_token_operations]
        payload["churn_guard_telemetry"] = (
            self.churn_guard_telemetry.to_dict() if self.churn_guard_telemetry else None
        )
        return payload


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _parse_utc(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    text = value.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _coerce_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _coerce_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _classify_operation(payload: dict[str, Any]) -> str:
    profile = payload.get("execution_profile", {})
    playbook = str(profile.get("playbook", "")).strip().lower()
    hydration = str(profile.get("provider_hydration_mode", "")).strip().lower()

    if playbook == "session-readiness" and hydration == "probe":
        return "scout"
    if playbook == "full-repo" and hydration == "full-repo":
        return "full_repo_audit"
    if hydration == "full-repo":
        return "full_repo_hydration"
    if playbook:
        return f"delta_{playbook.replace('-', '_')}"
    return "delta"


def _run_report_files(report_dir: Path) -> list[Path]:
    if not report_dir.exists():
        return []
    return sorted(report_dir.glob("delta-*.json"))


# ─── Churn-guard telemetry aggregation ───────────────────────────────────────

def _build_churn_guard_telemetry(
    run_records: list[dict[str, Any]],
) -> ChurnGuardTelemetry | None:
    """Aggregate churn-guard fields from a list of in-window run payloads.

    Run records must be ordered chronologically (oldest first).
    Returns None if no run has a churn_guard field (old run files).

    Episode detection
    -----------------
    We scan the runs in order and group consecutive non-FULL runs into
    episodes.  When a FULL run is encountered after a non-FULL stretch,
    the episode is closed.  An unclosed episode at the end of the window
    is recorded with end_run_id/end_utc = None and open_episode=True.

    Tuning notes
    ------------
    Observations are generated algorithmically from the aggregated numbers
    so you don't have to remember what each metric means when reading the
    report.  They are intentionally terse — just enough to flag actionable
    situations.
    """
    records_with_guard = [r for r in run_records if isinstance(r.get("churn_guard"), dict)]
    if not records_with_guard:
        return None

    total_runs = len(records_with_guard)
    full_count = 0
    dry_run_count = 0
    passive_count = 0
    disabled_count = 0
    tokens_skipped_dry: int = 0
    tokens_skipped_passive: int = 0

    smoothed_hit_sum = 0.0
    smoothed_churn_sum = 0.0
    smoothed_count = 0

    episodes: list[ChurnGuardEpisode] = []
    in_episode = False
    ep_start_run_id = ""
    ep_start_utc = ""
    ep_run_count = 0
    ep_peak_mode = "dry_run"
    ep_self_edit = False
    ep_confidences: list[float] = []
    ep_entry_confidence: float | None = None
    ep_min_conf: float | None = None
    ep_max_conf: float | None = None
    ep_min_hit: float | None = None
    ep_max_churn: float | None = None

    entry_confidences: list[float] = []
    exit_confidences: list[float] = []

    _mode_rank = {"full": 0, "dry_run": 1, "passive": 2}

    for rec in records_with_guard:
        guard = rec["churn_guard"]
        mode = str(guard.get("mode", "full")).lower()
        reason = str(guard.get("reason", ""))
        run_id = str(rec.get("run_id", ""))
        created_utc = str(rec.get("created_utc", ""))
        confidence_raw = guard.get("confidence")
        confidence = _coerce_float(confidence_raw) if confidence_raw is not None else None
        smoothed_hit_raw = guard.get("smoothed_hit_rate")
        smoothed_churn_raw = guard.get("smoothed_churn_rate")
        baseline_tokens = _coerce_int(rec.get("cost_metrics", {}).get("baseline_equivalent_tokens"))

        if smoothed_hit_raw is not None:
            smoothed_hit_sum += _coerce_float(smoothed_hit_raw)
            smoothed_count += 1
        if smoothed_churn_raw is not None:
            smoothed_churn_sum += _coerce_float(smoothed_churn_raw)

        if mode == "full":
            full_count += 1
            if in_episode:
                # Close the current episode
                exit_confidences.append(confidence) if confidence is not None else None
                episodes.append(ChurnGuardEpisode(
                    start_run_id=ep_start_run_id,
                    end_run_id=run_id,
                    start_utc=ep_start_utc,
                    end_utc=created_utc,
                    peak_mode=ep_peak_mode,
                    run_count=ep_run_count,
                    self_edit_triggered=ep_self_edit,
                    min_confidence=ep_min_conf,
                    max_confidence=ep_max_conf,
                    min_smoothed_hit_rate=ep_min_hit,
                    max_smoothed_churn_rate=ep_max_churn,
                ))
                in_episode = False
                ep_run_count = 0
                ep_confidences = []
        elif reason.startswith("guard_disabled"):
            disabled_count += 1
        else:
            if mode == "dry_run":
                dry_run_count += 1
                tokens_skipped_dry += baseline_tokens
            elif mode == "passive":
                passive_count += 1
                tokens_skipped_passive += baseline_tokens

            if not in_episode:
                in_episode = True
                ep_start_run_id = run_id
                ep_start_utc = created_utc
                ep_peak_mode = mode
                ep_self_edit = bool(guard.get("self_edit_detected", False))
                ep_entry_confidence = confidence
                if confidence is not None:
                    entry_confidences.append(confidence)
                ep_confidences = [confidence] if confidence is not None else []
                ep_min_conf = confidence
                ep_max_conf = confidence
                ep_min_hit = _coerce_float(smoothed_hit_raw) if smoothed_hit_raw is not None else None
                ep_max_churn = _coerce_float(smoothed_churn_raw) if smoothed_churn_raw is not None else None
            else:
                ep_run_count += 1
                if _mode_rank.get(mode, 0) > _mode_rank.get(ep_peak_mode, 0):
                    ep_peak_mode = mode
                if bool(guard.get("self_edit_detected", False)):
                    ep_self_edit = True
                if confidence is not None:
                    ep_confidences.append(confidence)
                    ep_min_conf = min(ep_min_conf, confidence) if ep_min_conf is not None else confidence
                    ep_max_conf = max(ep_max_conf, confidence) if ep_max_conf is not None else confidence
                if smoothed_hit_raw is not None:
                    v = _coerce_float(smoothed_hit_raw)
                    ep_min_hit = min(ep_min_hit, v) if ep_min_hit is not None else v
                if smoothed_churn_raw is not None:
                    v = _coerce_float(smoothed_churn_raw)
                    ep_max_churn = max(ep_max_churn, v) if ep_max_churn is not None else v

    # Close any open episode at the end of the window
    open_episode = False
    if in_episode:
        open_episode = True
        episodes.append(ChurnGuardEpisode(
            start_run_id=ep_start_run_id,
            end_run_id=None,
            start_utc=ep_start_utc,
            end_utc=None,
            peak_mode=ep_peak_mode,
            run_count=ep_run_count,
            self_edit_triggered=ep_self_edit,
            min_confidence=ep_min_conf,
            max_confidence=ep_max_conf,
            min_smoothed_hit_rate=ep_min_hit,
            max_smoothed_churn_rate=ep_max_churn,
        ))

    episode_lengths = [e.run_count for e in episodes]
    avg_ep_length = (sum(episode_lengths) / len(episode_lengths)) if episode_lengths else None
    max_ep_length = max(episode_lengths) if episode_lengths else None
    self_edit_episodes = sum(1 for e in episodes if e.self_edit_triggered)
    suppression_rate = round((dry_run_count + passive_count) / total_runs, 6) if total_runs else 0.0
    avg_entry_conf = round(sum(entry_confidences) / len(entry_confidences), 6) if entry_confidences else None
    avg_exit_conf = round(sum(exit_confidences) / len(exit_confidences), 6) if exit_confidences else None
    avg_smoothed_hit = round(smoothed_hit_sum / smoothed_count, 6) if smoothed_count else None
    avg_smoothed_churn = round(smoothed_churn_sum / smoothed_count, 6) if smoothed_count else None

    # ── Tuning notes ──────────────────────────────────────────────────────────
    notes: list[str] = []
    if suppression_rate > 0.5:
        notes.append(
            f"Suppression rate is {suppression_rate:.0%} — the guard is active more than half the time. "
            "Consider raising full_confidence_threshold or lowering ema_alpha to smooth more aggressively."
        )
    if suppression_rate == 0.0 and total_runs >= 3:
        notes.append(
            "Guard never activated in this window. If you are actively developing, "
            "consider lowering passive_confidence_threshold to be more protective."
        )
    if avg_ep_length is not None and avg_ep_length > 5:
        notes.append(
            f"Average episode length is {avg_ep_length:.1f} runs. "
            "Long episodes mean the cache is warming slowly OR cooldown_seconds is too high. "
            "Try reducing cooldown_seconds or ema_alpha."
        )
    if max_ep_length is not None and max_ep_length >= 10:
        notes.append(
            f"Longest episode was {max_ep_length} consecutive non-FULL runs. "
            "This may indicate persistent high churn — consider whether a new baseline snapshot is needed."
        )
    if self_edit_episodes > 0:
        notes.append(
            f"{self_edit_episodes} episode(s) triggered by self-edit detection. "
            "This means the engine detected you editing its own source files; passive mode was correct."
        )
    if avg_entry_conf is not None and avg_exit_conf is not None and avg_exit_conf < avg_entry_conf:
        notes.append(
            "Average confidence at episode exit is lower than at entry — this can indicate cooldown "
            "is releasing the guard before conditions have genuinely improved. "
            "Consider increasing cooldown_seconds."
        )
    if open_episode:
        notes.append(
            "The most recent episode is still open (engine has not returned to FULL mode yet). "
            "Check current EMA state in data/runs/churn-guard-state.json."
        )
    if not notes:
        notes.append("No threshold concerns detected in this window.")

    return ChurnGuardTelemetry(
        total_runs=total_runs,
        full_runs=full_count,
        dry_run_runs=dry_run_count,
        passive_runs=passive_count,
        guard_disabled_runs=disabled_count,
        suppression_rate=suppression_rate,
        episode_count=len(episodes),
        episodes=episodes,
        open_episode=open_episode,
        avg_episode_run_length=round(avg_ep_length, 2) if avg_ep_length is not None else None,
        max_episode_run_length=max_ep_length,
        self_edit_episode_count=self_edit_episodes,
        avg_confidence_at_entry=avg_entry_conf,
        avg_confidence_at_exit=avg_exit_conf,
        avg_smoothed_hit_rate=avg_smoothed_hit,
        avg_smoothed_churn_rate=avg_smoothed_churn,
        tokens_skipped_dry_run=tokens_skipped_dry,
        tokens_skipped_passive=tokens_skipped_passive,
        tuning_notes=notes,
    )


def build_metrics_report(
    project_root: Path,
    window_days: int = 7,
    top_n: int = 3,
) -> MetricsWindowReport:
    resolved_root = project_root.resolve()
    report_dir = resolved_root / "data" / "runs"
    files = _run_report_files(report_dir)

    bounded_window_days = max(1, int(window_days))
    cutoff = _now_utc() - timedelta(days=bounded_window_days)

    aggregates: dict[str, dict[str, Any]] = {}
    discovered = len(files)
    in_window = 0
    measured_run_count = 0
    in_window_payloads: list[dict[str, Any]] = []

    totals_projected_baseline = 0
    totals_projected_actual = 0
    totals_projected_saved = 0
    totals_measured_actual = 0
    totals_measured_saved = 0
    totals_runtime = 0.0
    totals_semantic_scored_pairs = 0
    totals_semantic_pass_count = 0
    totals_semantic_weighted_similarity = 0.0

    for path in files:
        payload = json.loads(path.read_text(encoding="utf-8"))
        created = _parse_utc(payload.get("created_utc"))
        if created is not None and created < cutoff:
            continue

        in_window += 1
        in_window_payloads.append(payload)
        operation_type = _classify_operation(payload)
        cost = payload.get("cost_metrics", {})
        provider_usage = payload.get("provider_usage", {})
        provider_cost = payload.get("provider_cost_metrics", {})
        semantic = payload.get("semantic_similarity_metrics", {})

        projected_baseline = _coerce_int(cost.get("baseline_equivalent_tokens"))
        projected_actual = _coerce_int(cost.get("actual_tokens"))
        projected_saved = _coerce_int(cost.get("saved_tokens"))
        runtime_seconds = _coerce_float(payload.get("runtime_seconds"))

        provider_captured = bool(provider_usage.get("captured"))
        provider_tokens_raw = provider_usage.get("total_tokens")
        measured_actual = _coerce_int(provider_tokens_raw) if provider_captured and provider_tokens_raw is not None else 0
        measured_saved_raw = provider_cost.get("saved_tokens_vs_baseline")
        measured_saved = _coerce_int(measured_saved_raw) if measured_saved_raw is not None else 0

        if provider_captured and provider_tokens_raw is not None:
            measured_run_count += 1

        semantic_scored_pairs = _coerce_int(semantic.get("scored_pair_count"))
        semantic_pass_count = _coerce_int(semantic.get("pass_count"))
        semantic_average_raw = semantic.get("average_similarity")
        semantic_average = _coerce_float(semantic_average_raw) if semantic_average_raw is not None else None

        totals_semantic_scored_pairs += semantic_scored_pairs
        totals_semantic_pass_count += semantic_pass_count
        if semantic_average is not None and semantic_scored_pairs > 0:
            totals_semantic_weighted_similarity += semantic_average * semantic_scored_pairs

        totals_projected_baseline += projected_baseline
        totals_projected_actual += projected_actual
        totals_projected_saved += projected_saved
        totals_measured_actual += measured_actual
        totals_measured_saved += measured_saved
        totals_runtime += runtime_seconds

        bucket = aggregates.setdefault(
            operation_type,
            {
                "run_count": 0,
                "runtime_seconds_total": 0.0,
                "projected_actual_tokens_total": 0,
                "projected_saved_tokens_total": 0,
                "measured_provider_tokens_total": 0,
                "measured_saved_tokens_total": 0,
                "measured_run_count": 0,
                "semantic_scored_pair_count": 0,
                "semantic_pass_count": 0,
                "semantic_weighted_similarity": 0.0,
            },
        )
        bucket["run_count"] += 1
        bucket["runtime_seconds_total"] += runtime_seconds
        bucket["projected_actual_tokens_total"] += projected_actual
        bucket["projected_saved_tokens_total"] += projected_saved
        bucket["measured_provider_tokens_total"] += measured_actual
        bucket["measured_saved_tokens_total"] += measured_saved
        if provider_captured and provider_tokens_raw is not None:
            bucket["measured_run_count"] += 1
        bucket["semantic_scored_pair_count"] += semantic_scored_pairs
        bucket["semantic_pass_count"] += semantic_pass_count
        if semantic_average is not None and semantic_scored_pairs > 0:
            bucket["semantic_weighted_similarity"] += semantic_average * semantic_scored_pairs

    breakdown: list[OperationSpend] = []
    for operation_type, stats in sorted(aggregates.items()):
        run_count = int(stats["run_count"])
        runtime_total = float(stats["runtime_seconds_total"])
        semantic_scored_pairs = int(stats["semantic_scored_pair_count"])
        semantic_pass_count = int(stats["semantic_pass_count"])
        semantic_average = (
            float(stats["semantic_weighted_similarity"]) / semantic_scored_pairs
            if semantic_scored_pairs > 0
            else None
        )
        semantic_pass_rate = (semantic_pass_count / semantic_scored_pairs) if semantic_scored_pairs > 0 else None
        breakdown.append(
            OperationSpend(
                operation_type=operation_type,
                run_count=run_count,
                runtime_seconds_total=round(runtime_total, 6),
                runtime_seconds_avg=round((runtime_total / run_count) if run_count else 0.0, 6),
                projected_actual_tokens_total=int(stats["projected_actual_tokens_total"]),
                projected_saved_tokens_total=int(stats["projected_saved_tokens_total"]),
                measured_provider_tokens_total=int(stats["measured_provider_tokens_total"]),
                measured_saved_tokens_total=int(stats["measured_saved_tokens_total"]),
                measured_run_count=int(stats["measured_run_count"]),
                semantic_scored_pair_count=semantic_scored_pairs,
                semantic_pass_count=semantic_pass_count,
                semantic_average_similarity=round(semantic_average, 6) if semantic_average is not None else None,
                semantic_pass_rate=round(semantic_pass_rate, 6) if semantic_pass_rate is not None else None,
            )
        )

    if in_window == 0:
        source = "projected"
    elif measured_run_count == in_window:
        source = "measured"
    elif measured_run_count > 0:
        source = "hybrid"
    else:
        source = "projected"

    prefer_measured = any(item.measured_provider_tokens_total > 0 for item in breakdown)
    sorted_ops = sorted(
        breakdown,
        key=(
            (lambda item: item.measured_provider_tokens_total)
            if prefer_measured
            else (lambda item: item.projected_actual_tokens_total)
        ),
        reverse=True,
    )
    top_items = sorted_ops[: max(1, int(top_n))]

    projected_ratio = (
        (totals_projected_saved / totals_projected_baseline) if totals_projected_baseline > 0 else 0.0
    )

    totals_payload = {
        "projected_baseline_tokens_total": totals_projected_baseline,
        "projected_actual_tokens_total": totals_projected_actual,
        "projected_saved_tokens_total": totals_projected_saved,
        "projected_saved_ratio": round(projected_ratio, 6),
        "measured_provider_tokens_total": totals_measured_actual,
        "measured_saved_tokens_total": totals_measured_saved,
        "measured_run_count": measured_run_count,
        "runtime_seconds_total": round(totals_runtime, 6),
        "runtime_seconds_avg": round((totals_runtime / in_window) if in_window else 0.0, 6),
        "semantic_scored_pair_count": totals_semantic_scored_pairs,
        "semantic_pass_count": totals_semantic_pass_count,
        "semantic_average_similarity": (
            round(totals_semantic_weighted_similarity / totals_semantic_scored_pairs, 6)
            if totals_semantic_scored_pairs > 0
            else None
        ),
        "semantic_pass_rate": (
            round(totals_semantic_pass_count / totals_semantic_scored_pairs, 6)
            if totals_semantic_scored_pairs > 0
            else None
        ),
    }

    return MetricsWindowReport(
        generated_utc=_now_utc().isoformat(),
        window_days=bounded_window_days,
        report_dir=str(report_dir),
        total_runs_discovered=discovered,
        runs_in_window=in_window,
        metric_source=source,
        totals=totals_payload,
        operation_breakdown=breakdown,
        top_token_operations=top_items,
        churn_guard_telemetry=_build_churn_guard_telemetry(in_window_payloads),
    )


def metrics_report_to_json(project_root: Path, window_days: int = 7, top_n: int = 3) -> str:
    report = build_metrics_report(project_root=project_root, window_days=window_days, top_n=top_n)
    return json.dumps(report.to_dict(), indent=2)
