"""Tester-facing import of a shared .reason bundle into the local cache.

The producer side ships a bundle in one of two shapes:

* a ``.zip`` produced by ``export-session`` (the reason bundle lives under a
  top-level ``reason_bundle/`` arc inside the zip), or
* a plain bundle *directory* containing ``reason.manifest.json`` directly, or
  one nested under a ``reason_bundle/`` subdirectory.

``import_session_bundle`` resolves any of those shapes to a concrete bundle
directory and delegates the actual hydration to
:func:`semantic_cache_engine.reason_bundle.import_reason_bundle`, which verifies
every shard hash and commits each card through the normal write path.

This is the engine capability behind the ``Semantic Cache Engine: Import Reason
Bundle`` Command Palette action; the CLI ``import-bundle`` subcommand is a thin
wrapper around it.
"""

from __future__ import annotations

import tempfile
import zipfile
from pathlib import Path
from typing import Any

from .reason_bundle import (
    DEFAULT_BUNDLE_SUBDIR,
    MANIFEST_FILENAME,
    import_reason_bundle,
)


def _locate_bundle_dir(root: Path) -> Path | None:
    """Return the directory containing ``reason.manifest.json`` under *root*.

    Checks *root* itself, then ``root/reason_bundle``, then a single-level
    recursive search (handles a zip that extracted into a nested folder).
    Returns ``None`` when no manifest is found.
    """
    if (root / MANIFEST_FILENAME).exists():
        return root
    nested = root / DEFAULT_BUNDLE_SUBDIR
    if (nested / MANIFEST_FILENAME).exists():
        return nested
    matches = sorted(root.rglob(MANIFEST_FILENAME))
    if matches:
        return matches[0].parent
    return None


def import_session_bundle(
    project_root: str | Path,
    bundle: str | Path,
    *,
    source: str = "bundle-import",
    skip_verify: bool = False,
) -> dict[str, Any]:
    """Import a shared reason bundle (zip or directory) into the local cache.

    Parameters
    ----------
    project_root:
        Workspace root whose SQLite cache receives the imported cards.
    bundle:
        Path to either an ``export-session`` ``.zip`` or a bundle directory.
    source:
        Provenance label written into every committed card's metadata.
    skip_verify:
        When ``True``, shard hash verification is bypassed (development only).

    Returns
    -------
    dict with ``status`` (``ok``/``error``). On success it also carries the
    ``import_reason_bundle`` summary fields (``committed``, ``skipped``,
    ``errors``, ``bundle_id`` ...) plus the resolved ``bundle_source``.
    """
    root = Path(project_root).resolve()
    bundle_path = Path(bundle).resolve()

    if not bundle_path.exists():
        return {"status": "error", "error": f"Bundle path not found: {bundle_path}"}

    if zipfile.is_zipfile(bundle_path):
        with tempfile.TemporaryDirectory(prefix="reason-import-") as tmp:
            tmp_dir = Path(tmp)
            with zipfile.ZipFile(bundle_path) as archive:
                # Reject path-traversal entries before extracting.
                for name in archive.namelist():
                    target = (tmp_dir / name).resolve()
                    if not str(target).startswith(str(tmp_dir.resolve())):
                        return {
                            "status": "error",
                            "error": f"Unsafe path in archive: {name}",
                        }
                archive.extractall(tmp_dir)
            return _import_from_dir(root, tmp_dir, bundle_path, source, skip_verify)

    if bundle_path.is_dir():
        return _import_from_dir(root, bundle_path, bundle_path, source, skip_verify)

    return {
        "status": "error",
        "error": f"Bundle must be a .zip or a directory: {bundle_path}",
    }


def _import_from_dir(
    project_root: Path,
    search_root: Path,
    bundle_source: Path,
    source: str,
    skip_verify: bool,
) -> dict[str, Any]:
    bundle_dir = _locate_bundle_dir(search_root)
    if bundle_dir is None:
        return {
            "status": "error",
            "error": f"No {MANIFEST_FILENAME} found in {bundle_source}",
        }

    try:
        summary = import_reason_bundle(
            bundle_dir=bundle_dir,
            project_root=project_root,
            source=source,
            skip_verify=skip_verify,
        )
    except Exception as exc:  # noqa: BLE001 -- surface as structured error, never crash the CLI
        return {"status": "error", "error": f"{type(exc).__name__}: {exc}"}

    return {
        "status": "ok",
        "bundle_source": str(bundle_source),
        **summary,
    }
