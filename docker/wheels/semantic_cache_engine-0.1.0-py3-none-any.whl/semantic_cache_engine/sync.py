from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
import os
from pathlib import Path
from typing import Any

from .cache import CacheEntry, create_central_cache_backend, create_operation_cache_backend
from .settings import EngineSettings, load_settings

SYNC_STATE_PATH = Path(os.environ.get("SEMANTIC_CACHE_BASE_DIR", ".reason")) / "runs/sync-state.json"
LOCAL_ONLY_ENTRY_TYPES = {"reasoning-card"}


@dataclass(frozen=True)
class SyncResult:
    started_utc: str
    completed_utc: str
    schedule_utc: str
    entry_type: str
    scanned_count: int
    synced_count: int
    skipped_count: int
    checkpoint_utc: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def sync_local_to_central(
    settings: EngineSettings | None = None,
    entry_type: str = "reasoning",
    max_entries: int | None = None,
    use_checkpoint: bool = True,
    state_path: Path = SYNC_STATE_PATH,
) -> SyncResult:
    normalized_entry_type = entry_type.strip().lower()
    if normalized_entry_type in LOCAL_ONLY_ENTRY_TYPES:
        blocked = ", ".join(sorted(LOCAL_ONLY_ENTRY_TYPES))
        raise ValueError(
            f"Entry type '{entry_type}' is local-only and cannot be synced to central storage. "
            f"Blocked types: {blocked}"
        )

    resolved = settings or load_settings()
    started_utc = _now_utc()

    local_backend = create_operation_cache_backend(resolved)
    central_backend = create_central_cache_backend(resolved)
    local_backend.ensure_schema()
    central_backend.ensure_schema()

    checkpoint = _read_checkpoint(state_path) if use_checkpoint else None
    entries = local_backend.list_cache_entries(entry_type=normalized_entry_type)

    if checkpoint is not None:
        entries = [entry for entry in entries if entry.timestamp_utc > checkpoint]

    if max_entries is not None:
        entries = entries[:max_entries]

    synced = 0
    skipped = 0
    for entry in entries:
        existing = central_backend.get_cache_entry(entry.chunk_id, entry.hash, entry_type=entry.type)
        if existing.hit:
            skipped += 1
            continue

        central_backend.upsert_cache_entry(
            CacheEntry(
                entry_id=entry.entry_id,
                type=entry.type,
                chunk_id=entry.chunk_id,
                hash=entry.hash,
                version=entry.version,
                timestamp_utc=entry.timestamp_utc,
                metadata=entry.metadata,
            )
        )
        synced += 1

    completed_utc = _now_utc()
    new_checkpoint = completed_utc
    _write_checkpoint(state_path, new_checkpoint)

    return SyncResult(
        started_utc=started_utc,
        completed_utc=completed_utc,
        schedule_utc=resolved.sync_schedule_utc,
        entry_type=normalized_entry_type,
        scanned_count=len(entries),
        synced_count=synced,
        skipped_count=skipped,
        checkpoint_utc=new_checkpoint,
    )


def sync_to_json(
    settings: EngineSettings | None = None,
    entry_type: str = "reasoning",
    max_entries: int | None = None,
    use_checkpoint: bool = True,
) -> str:
    result = sync_local_to_central(
        settings=settings,
        entry_type=entry_type,
        max_entries=max_entries,
        use_checkpoint=use_checkpoint,
    )
    return json.dumps(result.to_dict(), indent=2)


def _read_checkpoint(path: Path) -> str | None:
    if not path.exists():
        return None

    payload = json.loads(path.read_text(encoding="utf-8"))
    value = payload.get("checkpoint_utc")
    if isinstance(value, str) and value:
        return value
    return None


def _write_checkpoint(path: Path, checkpoint_utc: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "checkpoint_utc": checkpoint_utc,
    }
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()
