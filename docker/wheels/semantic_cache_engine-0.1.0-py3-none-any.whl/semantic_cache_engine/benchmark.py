from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
from pathlib import Path
from time import perf_counter
from typing import Any
from typing import Callable
import uuid

from .delta import DeltaRunReport, compute_delta_report
from .snapshot import latest_snapshot_id


@dataclass(frozen=True)
class BenchmarkResult:
    benchmark_id: str
    baseline_snapshot_id: str
    created_utc: str
    runs: dict[str, dict[str, Any]]
    savings_summary: dict[str, int | float | None]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def run_token_benchmark(
    project_path: Path,
    against_snapshot_id: str | None,
    live_provider: str | None = None,
    playbook: str | None = None,
    provider_hydration: str = "probe",
    include_changed_rerun: bool = False,
    progress: Callable[[str], None] | None = None,
) -> BenchmarkResult:
    started = perf_counter()

    def emit(message: str) -> None:
        if not progress:
            return
        elapsed = perf_counter() - started
        progress(f"+{elapsed:0.1f}s benchmark: {message}")

    snapshot_id = against_snapshot_id or latest_snapshot_id()
    resolved = project_path.resolve()
    emit(f"start against snapshot_id={snapshot_id}")

    emit("running baseline delta")
    baseline_run = compute_delta_report(
        resolved,
        snapshot_id,
        live_provider=live_provider,
        playbook=playbook,
        provider_hydration=provider_hydration,
        include_reasoning=include_changed_rerun,
        progress=lambda message: emit(f"baseline {message}"),
    )
    emit("running unchanged rerun delta")
    unchanged_rerun = compute_delta_report(
        resolved,
        snapshot_id,
        live_provider=live_provider,
        playbook=playbook,
        provider_hydration=provider_hydration,
        include_reasoning=include_changed_rerun,
        progress=lambda message: emit(f"unchanged {message}"),
    )

    changed_rerun: DeltaRunReport | None = None
    if include_changed_rerun:
        touch_path = resolved / f".phase9-benchmark-{uuid.uuid4().hex[:10]}.md"
        touch_path.write_text("# phase9 benchmark change\n\nThis file is generated for benchmark changed-rerun measurement.\n", encoding="utf-8")
        try:
            emit("running changed rerun delta")
            changed_rerun = compute_delta_report(
                resolved,
                snapshot_id,
                live_provider=live_provider,
                playbook=playbook,
                provider_hydration=provider_hydration,
                include_reasoning=True,
                progress=lambda message: emit(f"changed {message}"),
            )
        finally:
            if touch_path.exists():
                touch_path.unlink()
                emit("cleaned up temporary changed-rerun marker file")
    else:
        emit("skipping changed rerun delta (fast benchmark mode)")

    projected_baseline = _projected_tokens(baseline_run)
    projected_unchanged = _projected_tokens(unchanged_rerun)
    projected_changed = _projected_tokens(changed_rerun) if changed_rerun else None

    provider_baseline = _provider_tokens(baseline_run)
    provider_unchanged = _provider_tokens(unchanged_rerun)
    provider_changed = _provider_tokens(changed_rerun) if changed_rerun else None

    benchmark_id = f"benchmark-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"
    result = BenchmarkResult(
        benchmark_id=benchmark_id,
        baseline_snapshot_id=snapshot_id,
        created_utc=datetime.now(timezone.utc).isoformat(),
        runs={
            "baseline": _run_view(baseline_run),
            "unchanged_rerun": _run_view(unchanged_rerun),
            "changed_rerun": _run_view(changed_rerun) if changed_rerun else {
                "skipped": True,
            },
        },
        savings_summary={
            "projected_familiarization_tokens_saved": projected_baseline - projected_unchanged,
            "projected_change_penalty_tokens": _safe_diff(projected_changed, projected_unchanged),
            "provider_familiarization_tokens_saved": _safe_diff(provider_baseline, provider_unchanged),
            "provider_change_penalty_tokens": _safe_diff(provider_changed, provider_unchanged),
            "baseline_runtime_seconds": baseline_run.runtime_seconds,
            "unchanged_runtime_seconds": unchanged_rerun.runtime_seconds,
            "changed_runtime_seconds": changed_rerun.runtime_seconds if changed_rerun else None,
            "include_changed_rerun": int(include_changed_rerun),
        },
    )
    emit("complete")
    return result


def benchmark_to_json(
    project_path: Path,
    against_snapshot_id: str | None,
    live_provider: str | None = None,
    playbook: str | None = None,
    provider_hydration: str = "probe",
    include_changed_rerun: bool = False,
    progress: Callable[[str], None] | None = None,
) -> str:
    payload = run_token_benchmark(
        project_path,
        against_snapshot_id,
        live_provider=live_provider,
        playbook=playbook,
        provider_hydration=provider_hydration,
        include_changed_rerun=include_changed_rerun,
        progress=progress,
    )
    return json.dumps(payload.to_dict(), indent=2)


def _projected_tokens(report: DeltaRunReport) -> int:
    return int(report.cost_metrics.get("actual_tokens", 0))


def _provider_tokens(report: DeltaRunReport) -> int | None:
    value = report.provider_cost_metrics.get("actual_provider_tokens")
    if value is None:
        return None
    return int(value)


def _safe_diff(left: int | None, right: int | None) -> int | None:
    if left is None or right is None:
        return None
    return left - right


def _run_view(report: DeltaRunReport) -> dict[str, Any]:
    return {
        "run_id": report.run_id,
        "runtime_seconds": report.runtime_seconds,
        "cache_metrics": report.cache_metrics,
        "reasoning_metrics": report.reasoning_metrics,
        "projected_cost_metrics": report.cost_metrics,
        "provider_usage": report.provider_usage,
        "provider_cost_metrics": report.provider_cost_metrics,
    }
