from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Literal

EntitlementState = Literal["active", "grace", "revoked", "expired"]

REFRESH_INTERVAL_HOURS = 12
REFRESH_JITTER_PCT = 0.15
OFFLINE_GRACE_HOURS = 72


@dataclass(frozen=True)
class EntitlementPolicy:
    refresh_interval_hours: int = REFRESH_INTERVAL_HOURS
    refresh_jitter_pct: float = REFRESH_JITTER_PCT
    offline_grace_hours: int = OFFLINE_GRACE_HOURS


@dataclass(frozen=True)
class EntitlementSnapshot:
    status: Literal["active", "revoked", "expired"]
    issued_at_utc: datetime
    expires_at_utc: datetime
    last_verified_utc: datetime
    last_refresh_attempt_utc: datetime | None = None
    revoke_effective_utc: datetime | None = None


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def should_attempt_refresh(
    snapshot: EntitlementSnapshot,
    *,
    now_utc: datetime,
    policy: EntitlementPolicy = EntitlementPolicy(),
) -> bool:
    elapsed = now_utc - snapshot.last_verified_utc
    threshold = timedelta(hours=policy.refresh_interval_hours)
    return elapsed >= threshold


def evaluate_entitlement_state(
    snapshot: EntitlementSnapshot,
    *,
    now_utc: datetime,
    policy: EntitlementPolicy = EntitlementPolicy(),
) -> EntitlementState:
    if snapshot.status == "revoked":
        if snapshot.revoke_effective_utc and now_utc < snapshot.revoke_effective_utc:
            return "active"
        return "revoked"

    if snapshot.status == "expired" or now_utc >= snapshot.expires_at_utc:
        return "expired"

    grace_deadline = snapshot.last_verified_utc + timedelta(hours=policy.offline_grace_hours)
    if now_utc > grace_deadline:
        return "expired"

    refresh_due = should_attempt_refresh(snapshot, now_utc=now_utc, policy=policy)
    if refresh_due:
        return "grace"
    return "active"
