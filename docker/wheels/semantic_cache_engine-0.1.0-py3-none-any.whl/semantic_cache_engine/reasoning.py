from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
from typing import Any
from typing import Callable

from .cache import CacheBackend, build_cache_entry
from .snapshot import SnapshotManifest


@dataclass(frozen=True)
class ReasoningArtifact:
    reasoning_id: str
    artifact_type: str
    chunk_ids: list[str]
    explanation: str
    architectural_insights: list[str]
    rules_extracted: list[str]
    dependency_notes: list[str]
    hash_basis: list[str]
    version: str
    created_utc: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @staticmethod
    def from_dict(payload: dict[str, Any]) -> ReasoningArtifact:
        return ReasoningArtifact(
            reasoning_id=payload["reasoning_id"],
            artifact_type=payload["artifact_type"],
            chunk_ids=list(payload.get("chunk_ids", [])),
            explanation=payload.get("explanation", ""),
            architectural_insights=list(payload.get("architectural_insights", [])),
            rules_extracted=list(payload.get("rules_extracted", [])),
            dependency_notes=list(payload.get("dependency_notes", [])),
            hash_basis=list(payload.get("hash_basis", [])),
            version=payload.get("version", "phase-5"),
            created_utc=payload.get("created_utc", _utc_now()),
        )


@dataclass(frozen=True)
class ReasoningPipelineResult:
    artifact_ids_by_chunk_key: dict[str, str]
    generated_artifacts: list[str]
    reused_artifacts: list[str]


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _chunk_key(path: str, anchor: str) -> str:
    return f"{path}::{anchor}"


def _reasoning_id(chunk_id: str, chunk_hash: str) -> str:
    digest = hashlib.sha256(f"{chunk_id}:{chunk_hash}:phase-5".encode("utf-8")).hexdigest()
    return f"reasoning-{digest[:16]}"


def _build_reasoning_artifact(
    chunk_id: str,
    chunk_hash: str,
    chunk_path: str,
    chunk_anchor: str,
    dependency_keys: list[str],
) -> ReasoningArtifact:
    dependency_notes = [f"depends_on::{key}" for key in sorted(set(dependency_keys))]

    if dependency_notes:
        insights = [f"Chunk has {len(dependency_notes)} internal dependency link(s)."]
    else:
        insights = ["Chunk has no detected internal dependencies."]

    return ReasoningArtifact(
        reasoning_id=_reasoning_id(chunk_id, chunk_hash),
        artifact_type="summary",
        chunk_ids=[chunk_id],
        explanation=(
            f"Deterministic summary for {chunk_path}::{chunk_anchor}; "
            "regenerate only when chunk hash changes."
        ),
        architectural_insights=insights,
        rules_extracted=["Prefer incremental reuse when chunk hash is unchanged."],
        dependency_notes=dependency_notes,
        hash_basis=[chunk_hash],
        version="phase-5",
        created_utc=_utc_now(),
    )


def hydrate_reasoning_artifacts(
    snapshot: SnapshotManifest,
    dependency_adjacency: dict[str, list[str]],
    backend: CacheBackend,
    progress: Callable[[str], None] | None = None,
    heartbeat_every: int = 100,
) -> ReasoningPipelineResult:
    backend.ensure_schema()

    artifact_ids_by_chunk_key: dict[str, str] = {}
    generated: list[str] = []
    reused: list[str] = []

    records = sorted(snapshot.chunks, key=lambda item: (item.path, item.anchor, item.chunk_id))
    if progress:
        progress(f"reasoning: processing {len(records)} chunk artifact(s)")

    key_pairs = [(record.chunk_id, record.hash) for record in records]
    existing_entries = backend.get_cache_entries_map(key_pairs, entry_type="reasoning")

    for index, record in enumerate(records, start=1):
        key = _chunk_key(record.path, record.anchor)
        existing = existing_entries.get((record.chunk_id, record.hash))
        if existing is not None:
            artifact_payload = existing.metadata.get("artifact")
            if isinstance(artifact_payload, dict):
                artifact = ReasoningArtifact.from_dict(artifact_payload)
                artifact_ids_by_chunk_key[key] = artifact.reasoning_id
                reused.append(artifact.reasoning_id)
                continue

        artifact = _build_reasoning_artifact(
            chunk_id=record.chunk_id,
            chunk_hash=record.hash,
            chunk_path=record.path,
            chunk_anchor=record.anchor,
            dependency_keys=dependency_adjacency.get(key, []),
        )
        backend.upsert_cache_entry(
            build_cache_entry(
                chunk_id=record.chunk_id,
                chunk_hash=record.hash,
                entry_type="reasoning",
                version="phase-5",
                metadata={
                    "chunk_key": key,
                    "artifact": artifact.to_dict(),
                },
            )
        )
        artifact_ids_by_chunk_key[key] = artifact.reasoning_id
        generated.append(artifact.reasoning_id)

        if progress and heartbeat_every > 0 and index % heartbeat_every == 0:
            progress(
                f"reasoning: processed {index}/{len(records)} chunk artifact(s); "
                f"generated={len(generated)}, reused={len(reused)}"
            )

    result = ReasoningPipelineResult(
        artifact_ids_by_chunk_key=artifact_ids_by_chunk_key,
        generated_artifacts=sorted(set(generated)),
        reused_artifacts=sorted(set(reused)),
    )
    if progress:
        progress(
            f"reasoning: complete generated={len(result.generated_artifacts)}, "
            f"reused={len(result.reused_artifacts)}"
        )
    return result
