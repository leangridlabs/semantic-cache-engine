from __future__ import annotations

from dataclasses import dataclass


_BASELINE_TOKENS_PER_CHUNK = 120
_CACHE_HIT_TOKENS_PER_CHUNK = 8
_CACHE_MISS_TOKENS_PER_CHUNK = 32
_REGEN_TOKENS_PER_ARTIFACT = 90


@dataclass(frozen=True)
class UsageEvent:
    event_id: str
    stage: str
    token_type: str
    unit_count: int
    tokens: int

    def to_dict(self) -> dict[str, int | str]:
        return {
            "event_id": self.event_id,
            "stage": self.stage,
            "token_type": self.token_type,
            "unit_count": self.unit_count,
            "tokens": self.tokens,
        }


def build_usage_events(
    run_id: str,
    chunk_count: int,
    cache_hit_count: int,
    cache_miss_count: int,
    regenerated_artifact_count: int,
) -> list[UsageEvent]:
    baseline_tokens = chunk_count * _BASELINE_TOKENS_PER_CHUNK
    cache_hit_tokens = cache_hit_count * _CACHE_HIT_TOKENS_PER_CHUNK
    cache_miss_tokens = cache_miss_count * _CACHE_MISS_TOKENS_PER_CHUNK
    regeneration_tokens = regenerated_artifact_count * _REGEN_TOKENS_PER_ARTIFACT

    return [
        UsageEvent(
            event_id=f"{run_id}:baseline",
            stage="baseline_equivalent",
            token_type="baseline_projection",
            unit_count=chunk_count,
            tokens=baseline_tokens,
        ),
        UsageEvent(
            event_id=f"{run_id}:cache_hit",
            stage="retrieval",
            token_type="cache_hit",
            unit_count=cache_hit_count,
            tokens=cache_hit_tokens,
        ),
        UsageEvent(
            event_id=f"{run_id}:cache_miss",
            stage="retrieval",
            token_type="cache_miss",
            unit_count=cache_miss_count,
            tokens=cache_miss_tokens,
        ),
        UsageEvent(
            event_id=f"{run_id}:regeneration",
            stage="regeneration",
            token_type="artifact_regeneration",
            unit_count=regenerated_artifact_count,
            tokens=regeneration_tokens,
        ),
    ]


def compute_cost_metrics(usage_events: list[UsageEvent]) -> dict[str, int]:
    baseline_tokens = _sum_tokens(usage_events, stage="baseline_equivalent")
    retrieval_tokens = _sum_tokens(usage_events, stage="retrieval")
    regeneration_tokens = _sum_tokens(usage_events, stage="regeneration")
    actual_tokens = retrieval_tokens + regeneration_tokens
    saved_tokens = max(baseline_tokens - actual_tokens, 0)

    return {
        "baseline_equivalent_tokens": baseline_tokens,
        "actual_tokens": actual_tokens,
        "saved_tokens": saved_tokens,
    }


def _sum_tokens(events: list[UsageEvent], stage: str) -> int:
    return sum(event.tokens for event in events if event.stage == stage)
