from __future__ import annotations

from typing import Any

DIRECT_CHAT_CONTRACT_VERSION = "v1"
DIRECT_CHAT_HANDOFF_SCHEMA = "direct-chat-handoff/v1"


def build_handoff_packet(
    *,
    trace_id: str,
    question: str,
    resolver_confidence: float,
    confidence_threshold: float,
    resolver_result: dict[str, Any],
) -> dict[str, Any]:
    return {
        "contract_version": DIRECT_CHAT_CONTRACT_VERSION,
        "schema": DIRECT_CHAT_HANDOFF_SCHEMA,
        "trace_id": trace_id,
        "question": question,
        "resolver_confidence": round(float(resolver_confidence), 6),
        "confidence_threshold": round(float(confidence_threshold), 6),
        "route": resolver_result.get("route"),
        "classification": resolver_result.get("classification", {}),
        "scope_fingerprint": resolver_result.get("scope_fingerprint"),
        "decision_trace": resolver_result.get("decision_trace", []),
        "route_payload": resolver_result.get("route_payload", {}),
        "handoff_context": resolver_result.get("handoff_context", {}),
        "recall": resolver_result.get("recall", {}),
        "guidance": {
            "task": "Answer with resolver evidence first, then only fill missing context.",
            "preserve_format": True,
            "prefer_token_efficient_response": True,
        },
    }


def validate_handoff_packet(packet: dict[str, Any]) -> tuple[bool, list[str]]:
    errors: list[str] = []
    if not isinstance(packet, dict):
        return False, ["packet must be an object"]

    if packet.get("contract_version") != DIRECT_CHAT_CONTRACT_VERSION:
        errors.append("contract_version mismatch")
    if packet.get("schema") != DIRECT_CHAT_HANDOFF_SCHEMA:
        errors.append("schema mismatch")

    required_fields = (
        "trace_id",
        "question",
        "resolver_confidence",
        "confidence_threshold",
        "route",
        "classification",
        "scope_fingerprint",
        "decision_trace",
        "route_payload",
        "handoff_context",
        "recall",
        "guidance",
    )
    for field in required_fields:
        if field not in packet:
            errors.append(f"missing field: {field}")

    return len(errors) == 0, errors
