from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any


# ─── Mode enum ───────────────────────────────────────────────────────────────

class ChurnGuardMode(str, Enum):
    """Operating mode for a delta run.

    FULL      — reasoning hydration + provider/LLM call (normal operation).
    DRY_RUN   — reasoning hydration only; no provider/LLM call.  Cache keeps
                warming without spending tokens.
    PASSIVE   — no reasoning, no provider call.  Fully local dry run; used
                when cache is cold AND the codebase is in heavy flux so any
                artifacts generated would be immediately invalidated.
    """
    FULL = "full"
    DRY_RUN = "dry_run"
    PASSIVE = "passive"


def _mode_rank(mode: ChurnGuardMode) -> int:
    """Higher rank = more restrictive."""
    return {ChurnGuardMode.FULL: 0, ChurnGuardMode.DRY_RUN: 1, ChurnGuardMode.PASSIVE: 2}.get(mode, 0)


# ─── Policy ──────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class ChurnGuardPolicy:
    """Configuration that controls churn guard behaviour."""

    enabled: bool
    min_hit_rate: float
    """Retained for backward compat and manual review; not used in confidence logic."""
    max_churn_rate: float
    """Retained for backward compat and manual review; not used in confidence logic."""
    min_total_chunks: int
    """Guard does not activate below this project size (protects tiny/test projects)."""
    ema_alpha: float
    """EMA smoothing factor 0.0–1.0.  Higher = more reactive to recent runs.
    Effective window ≈ (2 / alpha) - 1 observations.  Default 0.3 ≈ 5-run window."""
    cooldown_seconds: int
    """Hysteresis: once in DRY_RUN/PASSIVE, hold for at least this many seconds
    before allowing improvement back toward FULL.  Escalation is always immediate."""
    full_confidence_threshold: float
    """confidence >= this → FULL mode."""
    passive_confidence_threshold: float
    """confidence < this → PASSIVE mode; between thresholds → DRY_RUN."""
    self_edit_ratio: float
    """If > this fraction of changed chunks are under engine paths → instant PASSIVE."""
    self_edit_paths: tuple
    """Path prefixes (forward-slash normalised) counted as engine self-edits."""

    def to_dict(self) -> dict[str, Any]:
        return {
            "enabled": self.enabled,
            "min_hit_rate": self.min_hit_rate,
            "max_churn_rate": self.max_churn_rate,
            "min_total_chunks": self.min_total_chunks,
            "ema_alpha": self.ema_alpha,
            "cooldown_seconds": self.cooldown_seconds,
            "full_confidence_threshold": self.full_confidence_threshold,
            "passive_confidence_threshold": self.passive_confidence_threshold,
            "self_edit_ratio": self.self_edit_ratio,
            "self_edit_paths": list(self.self_edit_paths),
        }


# ─── Persistent EMA state ────────────────────────────────────────────────────

_STATE_FILENAME = "churn-guard-state.json"


@dataclass
class ChurnGuardState:
    """EMA state persisted between delta runs to smooth hit/churn signals.

    Stored as a single JSON file under data/runs/.  Failures to read or write
    the file are silently swallowed — the guard degrades gracefully to using
    raw per-run values (cold-start bootstrap).
    """

    ema_hit_rate: float | None
    ema_churn_rate: float | None
    last_mode: str
    last_mode_change_utc: str | None
    last_updated_utc: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "ema_hit_rate": self.ema_hit_rate,
            "ema_churn_rate": self.ema_churn_rate,
            "last_mode": self.last_mode,
            "last_mode_change_utc": self.last_mode_change_utc,
            "last_updated_utc": self.last_updated_utc,
        }

    @staticmethod
    def from_dict(d: dict[str, Any]) -> ChurnGuardState:
        return ChurnGuardState(
            ema_hit_rate=_coerce_float_opt(d.get("ema_hit_rate")),
            ema_churn_rate=_coerce_float_opt(d.get("ema_churn_rate")),
            last_mode=str(d.get("last_mode", ChurnGuardMode.FULL.value)),
            last_mode_change_utc=d.get("last_mode_change_utc") or None,
            last_updated_utc=str(d.get("last_updated_utc", "")),
        )

    @staticmethod
    def default() -> ChurnGuardState:
        return ChurnGuardState(
            ema_hit_rate=None,
            ema_churn_rate=None,
            last_mode=ChurnGuardMode.FULL.value,
            last_mode_change_utc=None,
            last_updated_utc=_utc_now(),
        )


def load_guard_state(state_path: Path | None) -> ChurnGuardState:
    """Load persisted EMA state.  Returns a blank default on any failure."""
    if state_path is None:
        return ChurnGuardState.default()
    path = state_path if state_path.suffix == ".json" else state_path / _STATE_FILENAME
    if not path.exists():
        return ChurnGuardState.default()
    try:
        return ChurnGuardState.from_dict(json.loads(path.read_text(encoding="utf-8")))
    except Exception:
        return ChurnGuardState.default()


def save_guard_state(state: ChurnGuardState, state_path: Path | None) -> None:
    """Persist EMA state to disk.  Failures are silently swallowed (non-fatal)."""
    if state_path is None:
        return
    path = state_path if state_path.suffix == ".json" else state_path / _STATE_FILENAME
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(state.to_dict(), indent=2), encoding="utf-8")
    except Exception:
        pass


# ─── Decision ────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class ChurnGuardDecision:
    """Result of one churn-guard evaluation."""

    mode: ChurnGuardMode
    paused: bool
    """True when mode != FULL (backward-compatibility field)."""
    reason: str
    hit_rate: float
    """Raw hit rate this run."""
    churn_rate: float
    """Raw total churn rate this run (MODIFIED+NEW+DELETED / all; for reporting)."""
    smoothed_hit_rate: float
    """EMA-smoothed hit rate used for confidence scoring."""
    smoothed_churn_rate: float
    """EMA-smoothed active churn rate (MODIFIED+NEW only; used for confidence)."""
    confidence: float
    """(1 - smoothed_active_churn) * smoothed_hit.  Range 0.0–1.0."""
    self_edit_detected: bool
    cooldown_active: bool
    policy: ChurnGuardPolicy

    def to_dict(self) -> dict[str, Any]:
        return {
            "mode": self.mode.value,
            "paused": self.paused,
            "reason": self.reason,
            "hit_rate": self.hit_rate,
            "churn_rate": self.churn_rate,
            "smoothed_hit_rate": self.smoothed_hit_rate,
            "smoothed_churn_rate": self.smoothed_churn_rate,
            "confidence": self.confidence,
            "self_edit_detected": self.self_edit_detected,
            "cooldown_active": self.cooldown_active,
            "policy": self.policy.to_dict(),
        }


# ─── Helpers ─────────────────────────────────────────────────────────────────

def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _coerce_float_opt(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _parse_utc(value: str | None) -> datetime | None:
    if not value:
        return None
    text = value.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _seconds_since(utc_str: str | None) -> float | None:
    if not utc_str:
        return None
    ts = _parse_utc(utc_str)
    if ts is None:
        return None
    return (datetime.now(timezone.utc) - ts).total_seconds()


def _commit_state(
    prior: ChurnGuardState,
    new_mode: ChurnGuardMode,
    state_path: Path | None,
    ema_hit: float | None = None,
    ema_churn: float | None = None,
) -> None:
    try:
        current_mode = ChurnGuardMode(prior.last_mode)
    except ValueError:
        current_mode = ChurnGuardMode.FULL
    now = _utc_now()
    updated = ChurnGuardState(
        ema_hit_rate=ema_hit if ema_hit is not None else prior.ema_hit_rate,
        ema_churn_rate=ema_churn if ema_churn is not None else prior.ema_churn_rate,
        last_mode=new_mode.value,
        last_mode_change_utc=now if new_mode != current_mode else prior.last_mode_change_utc,
        last_updated_utc=now,
    )
    save_guard_state(updated, state_path)


# ─── Core algorithms ─────────────────────────────────────────────────────────

def compute_churn_rate(
    unchanged: int,
    modified: int,
    new: int,
    deleted: int,
) -> float:
    """Total churn fraction: all changes (including deletions) against full universe.

    Formula: (MODIFIED + NEW + DELETED) / (UNCHANGED + MODIFIED + NEW + DELETED)
    Returns 0.0 when the universe is empty.
    """
    total = unchanged + modified + new + deleted
    if total == 0:
        return 0.0
    return (modified + new + deleted) / total


def compute_active_churn_rate(
    unchanged: int,
    modified: int,
    new: int,
) -> float:
    """Active modification rate within the current codebase state.

    Formula: (MODIFIED + NEW) / (UNCHANGED + MODIFIED + NEW)

    Excludes deleted chunks because they no longer exist in the project and
    will not consume provider tokens.  This variant is used for confidence
    scoring so that a large number of stale baseline deletions does not
    incorrectly suppress a warm-cache, low-modification run.
    Returns 0.0 when current state is empty.
    """
    current_total = unchanged + modified + new
    if current_total == 0:
        return 0.0
    return (modified + new) / current_total


def compute_modified_only_rate(
    unchanged: int,
    modified: int,
    new: int,
) -> float:
    """True invalidation rate: only hash-mismatched chunks that existed in both snapshots.

    Formula: MODIFIED / (UNCHANGED + MODIFIED + NEW)

    Used when a token-budget playbook exhausted its budget and produced deletions
    that are selection artifacts rather than real removals.  In that scenario NEW
    chunks are also artifacts (files not selected this run) so including them in
    the numerator would inflate churn beyond what actually changed.  Only MODIFIED
    counts as a true invalidation because those keys existed in the baseline and
    their content hash changed.
    Returns 0.0 when current state is empty.
    """
    current_total = unchanged + modified + new
    if current_total == 0:
        return 0.0
    return modified / current_total


def _apply_ema(current: float, previous: float | None, alpha: float) -> float:
    """Exponential Moving Average.

    ema_new = alpha * current + (1 - alpha) * previous

    First published by Robert G. Brown (1956); standard signal-processing
    technique used universally in monitoring and control systems.
    On first observation (previous is None) returns current as-is (bootstrap).
    Alpha 0.0–1.0: higher = more reactive; effective window ≈ (2/alpha) - 1 runs.
    """
    if previous is None:
        return float(current)
    bounded = max(0.0, min(1.0, float(alpha)))
    return bounded * float(current) + (1.0 - bounded) * float(previous)


def compute_confidence(smoothed_hit_rate: float, smoothed_active_churn_rate: float) -> float:
    """Composite cache confidence score for one run.

    confidence = (1 - active_churn_rate) * hit_rate

    Range 0.0–1.0.  Represents the probability that the cache holds stable,
    reusable content worth spending provider tokens to hydrate.
    """
    return max(0.0, min(1.0, (1.0 - smoothed_active_churn_rate) * smoothed_hit_rate))


def _detect_self_edit(
    changed_chunk_keys: list[str],
    self_edit_paths: tuple,
    self_edit_ratio: float,
) -> bool:
    """Return True if the majority of changes are within engine source directories.

    When a developer is actively editing the engine itself, the cache is
    continuously invalidated.  Detecting this pattern allows the guard to drop
    to PASSIVE immediately rather than waiting for confidence to fall gradually.
    Path comparison is normalised to forward slashes for Windows compatibility.
    """
    if not changed_chunk_keys or not self_edit_paths:
        return False
    total = len(changed_chunk_keys)
    engine_count = sum(
        1 for key in changed_chunk_keys
        if any(key.replace("\\", "/").startswith(p) for p in self_edit_paths)
    )
    return (engine_count / total) > self_edit_ratio


# ─── Main evaluation entry point ─────────────────────────────────────────────

def evaluate_churn_guard(
    hit_rate: float,
    churn_rate: float,
    policy: ChurnGuardPolicy,
    total_chunks: int = 0,
    changed_chunk_keys: list[str] | None = None,
    state_path: Path | None = None,
    active_churn_rate: float | None = None,
    budget_limited: bool = False,
) -> ChurnGuardDecision:
    """Evaluate the churn guard with EMA smoothing, confidence tiers, and hysteresis.

    Three-tier operating modes
    --------------------------
    FULL      — reasoning + provider/LLM call (normal operation).
    DRY_RUN   — reasoning only, no provider call.  Cache warms without spending
                tokens; useful when churn is moderate.
    PASSIVE   — no reasoning, no provider call.  Fully local dry run for heavy
                churn or self-edit scenarios where artifacts would be invalidated
                immediately anyway.

    EMA smoothing (Robert G. Brown, 1956; public domain mathematics)
    -----------------------------------------------------------------
    Raw hit and active-churn rates are smoothed across runs via an exponential
    moving average, preventing individual outlier runs from causing rapid mode
    toggling.

    Confidence gradient
    -------------------
    confidence = (1 - smoothed_active_churn) * smoothed_hit_rate

    Maps to three tiers without arbitrary binary thresholds:
    · confidence >= full_confidence_threshold   → FULL
    · confidence >= passive_confidence_threshold → DRY_RUN
    · confidence < passive_confidence_threshold  → PASSIVE

    Active churn uses MODIFIED+NEW only (no deletions) so a large number of
    stale baseline deletions does not suppress a warm-cache, stable run.

    Budget-limited playbook handling
    ---------------------------------
    When the ingest token budget was exhausted AND the baseline had more chunks
    than the current ingest selected (budget_limited=True), NEW chunks are
    playbook-selection artifacts rather than real additions — they were simply not
    selected this run.  In that case ``modified_only_rate`` is used instead of
    ``active_churn_rate`` so only genuine hash-mismatch invalidations count.

    Hysteresis cooldown (standard control-systems technique)
    --------------------------------------------------------
    Once in DRY_RUN/PASSIVE, the engine holds that mode for cooldown_seconds
    before allowing improvement toward FULL.  Escalation is always immediate.

    Self-edit fast path
    -------------------
    If > self_edit_ratio of changed chunks are under a configured engine path
    prefix, the engine assumes the developer is debugging the tool itself and
    drops to PASSIVE instantly — no LLM calls while you rewrite the cached code.

    All algorithms used here are standard engineering techniques with no patent
    or licensing encumbrances.
    """
    state = load_guard_state(state_path)

    # Active churn for confidence.
    # When the ingest budget was exhausted, NEW chunks are playbook selection
    # artifacts (files not picked this run), not real additions.  Use the
    # modified-only rate so only actual hash-mismatch invalidations affect the
    # guard decision.  Otherwise prefer the explicit active_churn_rate, falling
    # back to the total churn_rate.
    if budget_limited and active_churn_rate is not None:
        # Recompute modified-only from active_churn_rate context is unavailable
        # here; caller must pass active_churn_rate.  We trust the caller already
        # set active_churn_rate to modified_only_rate when budget_limited=True.
        raw_active = active_churn_rate
    else:
        raw_active = active_churn_rate if active_churn_rate is not None else churn_rate

    # Always apply EMA so state is updated even when guard is disabled
    smoothed_hit = _apply_ema(hit_rate, state.ema_hit_rate, policy.ema_alpha)
    smoothed_churn = _apply_ema(raw_active, state.ema_churn_rate, policy.ema_alpha)
    confidence = compute_confidence(smoothed_hit, smoothed_churn)

    if not policy.enabled:
        _commit_state(state, ChurnGuardMode.FULL, state_path, smoothed_hit, smoothed_churn)
        return ChurnGuardDecision(
            mode=ChurnGuardMode.FULL,
            paused=False,
            reason="guard_disabled",
            hit_rate=round(hit_rate, 6),
            churn_rate=round(churn_rate, 6),
            smoothed_hit_rate=round(smoothed_hit, 6),
            smoothed_churn_rate=round(smoothed_churn, 6),
            confidence=round(confidence, 6),
            self_edit_detected=False,
            cooldown_active=False,
            policy=policy,
        )

    # ── Self-edit fast path ───────────────────────────────────────────────────
    self_edit = _detect_self_edit(
        changed_chunk_keys or [],
        policy.self_edit_paths,
        policy.self_edit_ratio,
    )
    if self_edit:
        reason = (
            f"self_edit_detected: >{policy.self_edit_ratio:.0%} of changes in engine paths; "
            f"confidence={confidence:.3f} — passive mode (no LLM calls while debugging engine)"
        )
        _commit_state(state, ChurnGuardMode.PASSIVE, state_path, smoothed_hit, smoothed_churn)
        return ChurnGuardDecision(
            mode=ChurnGuardMode.PASSIVE,
            paused=True,
            reason=reason,
            hit_rate=round(hit_rate, 6),
            churn_rate=round(churn_rate, 6),
            smoothed_hit_rate=round(smoothed_hit, 6),
            smoothed_churn_rate=round(smoothed_churn, 6),
            confidence=round(confidence, 6),
            self_edit_detected=True,
            cooldown_active=False,
            policy=policy,
        )

    # ── Below minimum project size → always FULL ──────────────────────────────
    if total_chunks < policy.min_total_chunks:
        _commit_state(state, ChurnGuardMode.FULL, state_path, smoothed_hit, smoothed_churn)
        return ChurnGuardDecision(
            mode=ChurnGuardMode.FULL,
            paused=False,
            reason=f"below_min_chunks: total={total_chunks} < min={policy.min_total_chunks}",
            hit_rate=round(hit_rate, 6),
            churn_rate=round(churn_rate, 6),
            smoothed_hit_rate=round(smoothed_hit, 6),
            smoothed_churn_rate=round(smoothed_churn, 6),
            confidence=round(confidence, 6),
            self_edit_detected=False,
            cooldown_active=False,
            policy=policy,
        )

    # ── Confidence → target mode ──────────────────────────────────────────────
    if confidence >= policy.full_confidence_threshold:
        target_mode = ChurnGuardMode.FULL
    elif confidence >= policy.passive_confidence_threshold:
        target_mode = ChurnGuardMode.DRY_RUN
    else:
        target_mode = ChurnGuardMode.PASSIVE

    # ── Hysteresis: gate improvement behind cooldown, escalate immediately ────
    try:
        current_mode = ChurnGuardMode(state.last_mode)
    except ValueError:
        current_mode = ChurnGuardMode.FULL

    cooldown_active = False
    final_mode = target_mode

    if _mode_rank(target_mode) < _mode_rank(current_mode):
        # Would improve (less restrictive) — check cooldown
        elapsed = _seconds_since(state.last_mode_change_utc)
        if elapsed is not None and elapsed < policy.cooldown_seconds:
            final_mode = current_mode
            cooldown_active = True

    # ── Build reason string ───────────────────────────────────────────────────
    stats = (
        f"confidence={confidence:.3f} "
        f"(smoothed_hit={smoothed_hit:.1%}, smoothed_churn={smoothed_churn:.1%})"
    )
    if final_mode == ChurnGuardMode.FULL:
        reason = f"conditions_nominal: {stats}"
    elif final_mode == ChurnGuardMode.DRY_RUN:
        reason = f"dry_run_mode: provider call skipped; {stats}"
        if cooldown_active:
            remaining = int(policy.cooldown_seconds - (_seconds_since(state.last_mode_change_utc) or 0))
            reason += f" [cooldown ~{max(0, remaining)}s remaining]"
    else:
        reason = f"passive_mode: reasoning+LLM skipped; {stats}"
        if cooldown_active:
            remaining = int(policy.cooldown_seconds - (_seconds_since(state.last_mode_change_utc) or 0))
            reason += f" [cooldown ~{max(0, remaining)}s remaining]"

    _commit_state(state, final_mode, state_path, smoothed_hit, smoothed_churn)
    return ChurnGuardDecision(
        mode=final_mode,
        paused=final_mode != ChurnGuardMode.FULL,
        reason=reason,
        hit_rate=round(hit_rate, 6),
        churn_rate=round(churn_rate, 6),
        smoothed_hit_rate=round(smoothed_hit, 6),
        smoothed_churn_rate=round(smoothed_churn, 6),
        confidence=round(confidence, 6),
        self_edit_detected=False,
        cooldown_active=cooldown_active,
        policy=policy,
    )
