from __future__ import annotations

from typing import Any

SIDECAR_CONTRACT_VERSION = "v1"
SIDECAR_HANDSHAKE_SCHEMA = "sidecar-handshake/v1"
SIDECAR_RESOLVE_REQUEST_SCHEMA = "sidecar-resolve-request/v1"
SIDECAR_RESOLVE_RESPONSE_SCHEMA = "sidecar-resolve-response/v1"


def build_handshake_request(
    *,
    client_name: str,
    client_version: str,
    requested_capabilities: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "contract_version": SIDECAR_CONTRACT_VERSION,
        "schema": SIDECAR_HANDSHAKE_SCHEMA,
        "client_name": client_name,
        "client_version": client_version,
        "requested_capabilities": requested_capabilities or ["resolve_question"],
    }


def build_resolve_request(
    *,
    trace_id: str,
    question: str,
    workspace_root: str,
    editor_context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "contract_version": SIDECAR_CONTRACT_VERSION,
        "schema": SIDECAR_RESOLVE_REQUEST_SCHEMA,
        "trace_id": trace_id,
        "question": question,
        "workspace_root": workspace_root,
        "editor_context": editor_context or {},
    }


def build_resolve_response(
    *,
    trace_id: str,
    route: str,
    confidence: float,
    decision_trace: list[dict[str, Any]] | None = None,
    route_payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "contract_version": SIDECAR_CONTRACT_VERSION,
        "schema": SIDECAR_RESOLVE_RESPONSE_SCHEMA,
        "trace_id": trace_id,
        "route": route,
        "confidence": round(float(confidence), 6),
        "decision_trace": decision_trace or [],
        "route_payload": route_payload or {},
    }


def validate_handshake_request(packet: dict[str, Any]) -> tuple[bool, list[str]]:
    errors: list[str] = []
    if not isinstance(packet, dict):
        return False, ["packet must be an object"]

    if packet.get("contract_version") != SIDECAR_CONTRACT_VERSION:
        errors.append("contract_version mismatch")
    if packet.get("schema") != SIDECAR_HANDSHAKE_SCHEMA:
        errors.append("schema mismatch")

    for field in ("client_name", "client_version", "requested_capabilities"):
        if field not in packet:
            errors.append(f"missing field: {field}")

    return len(errors) == 0, errors


def validate_resolve_request(packet: dict[str, Any]) -> tuple[bool, list[str]]:
    errors: list[str] = []
    if not isinstance(packet, dict):
        return False, ["packet must be an object"]

    if packet.get("contract_version") != SIDECAR_CONTRACT_VERSION:
        errors.append("contract_version mismatch")
    if packet.get("schema") != SIDECAR_RESOLVE_REQUEST_SCHEMA:
        errors.append("schema mismatch")

    for field in ("trace_id", "question", "workspace_root", "editor_context"):
        if field not in packet:
            errors.append(f"missing field: {field}")

    return len(errors) == 0, errors


def validate_resolve_response(packet: dict[str, Any]) -> tuple[bool, list[str]]:
    errors: list[str] = []
    if not isinstance(packet, dict):
        return False, ["packet must be an object"]

    if packet.get("contract_version") != SIDECAR_CONTRACT_VERSION:
        errors.append("contract_version mismatch")
    if packet.get("schema") != SIDECAR_RESOLVE_RESPONSE_SCHEMA:
        errors.append("schema mismatch")

    for field in ("trace_id", "route", "confidence", "decision_trace", "route_payload"):
        if field not in packet:
            errors.append(f"missing field: {field}")

    return len(errors) == 0, errors
