from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class PlaybookProfile:
    name: str
    description: str
    include_patterns: list[str]
    exclude_patterns: list[str]
    max_file_bytes: int | None
    token_budget: int | None
    use_embedding_cache: bool

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


_BUILTIN_PLAYBOOKS: dict[str, PlaybookProfile] = {
    "full-repo": PlaybookProfile(
        name="full-repo",
        description="Process all supported repository files (default behavior).",
        include_patterns=["**"],
        exclude_patterns=[],
        max_file_bytes=None,
        token_budget=None,
        use_embedding_cache=True,
    ),
    "integration-ready": PlaybookProfile(
        name="integration-ready",
        description=(
            "Scoped onboarding profile for mature repositories with source, docs, and "
            "configuration prioritized over generated, vendor, and test-heavy paths."
        ),
        include_patterns=[
            "src/**",
            "app/**",
            "lib/**",
            "docs/**",
            "README.md",
            "CHANGELOG.md",
            "*.md",
            "*.json",
            "*.yaml",
            "*.yml",
            "*.toml",
            "pyproject.toml",
            "package.json",
            "tsconfig.json",
        ],
        exclude_patterns=[
            "**/tests/**",
            "**/test/**",
            "**/node_modules/**",
            "**/.venv/**",
            "**/venv/**",
            "**/dist/**",
            "**/build/**",
            "**/coverage/**",
            "**/.next/**",
            "**/data/**",
            "**/*.lock",
            "**/*.min.js",
        ],
        max_file_bytes=262144,
        token_budget=30000,
        use_embedding_cache=True,
    ),
    "session-readiness": PlaybookProfile(
        name="session-readiness",
        description=(
            "Focus startup context on core source and architecture docs while excluding "
            "low-signal or expensive paths."
        ),
        include_patterns=[
            "src/**",
            "docs/**",
            "README.md",
            "CHANGELOG.md",
            "*.md",
            "*.json",
            "*.yaml",
            "*.yml",
            "*.toml",
        ],
        exclude_patterns=[
            "**/tests/**",
            "**/test/**",
            "**/node_modules/**",
            "**/.venv/**",
            "**/venv/**",
            "**/dist/**",
            "**/build/**",
            "**/data/**",
            "**/.next/**",
            "**/*.lock",
            "**/*.min.js",
        ],
        max_file_bytes=262144,
        token_budget=24000,
        use_embedding_cache=True,
    ),
}


def load_playbook(name: str | None) -> PlaybookProfile:
    key = (name or "full-repo").strip().lower()
    if key not in _BUILTIN_PLAYBOOKS:
        supported = ", ".join(sorted(_BUILTIN_PLAYBOOKS.keys()))
        raise ValueError(f"Unknown playbook '{key}'. Supported playbooks: {supported}")

    return _BUILTIN_PLAYBOOKS[key]


def list_playbooks() -> list[PlaybookProfile]:
    return [
        _BUILTIN_PLAYBOOKS[name]
        for name in sorted(_BUILTIN_PLAYBOOKS.keys())
    ]
