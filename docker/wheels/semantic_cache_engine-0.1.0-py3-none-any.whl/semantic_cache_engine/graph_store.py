"""
graph_store.py
==============
Persistent SQLite-backed store for the DRQS reasoning graph.

Owns ``reasoning_graph.sqlite`` — a sidecar file next to the main cache DB.
All writes are best-effort (never raise) so the graph is always optional
infrastructure — if it fails, the rest of the engine degrades gracefully.

Public API
----------
``GraphStore(project_root)``
    Open (and create if needed) the graph database.

``GraphStore.ensure_schema()``
    Create all 8 tables + indexes if they do not exist.  Safe to call
    repeatedly — fully idempotent.

``GraphStore.stats() -> dict``
    Return node/edge counts from ``reasoning_graph_metadata``.

``GraphStore.upsert_chunk(chunk_id, file_path, symbol_path, hash_)``
``GraphStore.upsert_artifact(artifact_id, chunk_id, summary, dependency_notes, validation_state)``
``GraphStore.upsert_card(card_id, scope_fingerprint, task_intent, dependency_fingerprint, validation_state, supersedes_card_id)``
``GraphStore.upsert_card_chunk_edge(from_card_id, to_chunk_id, edge_type, weight)``
``GraphStore.upsert_chunk_chunk_edge(from_chunk_id, to_chunk_id, edge_type, weight)``
``GraphStore.upsert_card_card_edge(from_card_id, to_card_id, edge_type, weight)``
``GraphStore.upsert_card_artifact_edge(from_card_id, to_artifact_id, edge_type, weight)``

``seed_graph_from_scout_pack(project_root, graph_store)``
    Phase 1b: zero-token structural seeding from the scout pack JSON.
    Populates ``chunks`` and ``chunk_chunk_edges`` from ``project_map`` and
    ``dependency_context`` fields.  Called automatically on first
    ``GraphStore`` access when the scout pack is newer than the last seed.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import sqlite3
import time
from pathlib import Path
from typing import Any

from .settings import load_settings

logger = logging.getLogger(__name__)

_BASE = Path(os.environ.get("SEMANTIC_CACHE_BASE_DIR", ".reason"))
SCOUT_PACK_PATH = _BASE / "runs/shadow/scout-pack-latest.json"

# Pattern that matches dependency_context entries:
#   depends_on::src/foo/bar.py::def-symbol-name:N
_DEP_CTX_RE = re.compile(
    r"depends_on::(?P<from_path>[^:]+)::(?P<symbol>[^:]+):(?P<count>\d+)"
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _graph_db_path(project_root: Path) -> Path:
    """Return path to reasoning_graph.sqlite, placed next to the main cache DB."""
    settings = load_settings(project_root.resolve())
    return settings.sqlite_path.with_name("reasoning_graph.sqlite")


def _graph_journal_mode(db_path: Path) -> str:
    """Use DELETE journal mode on cloud-synced paths to avoid OneDrive locking WAL files."""
    path_str = str(db_path).lower()
    if "onedrive" in path_str or "dropbox" in path_str or "google drive" in path_str:
        return "DELETE"
    return "WAL"


def _connect(db_path: Path) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path), timeout=30.0)
    conn.row_factory = sqlite3.Row
    # busy_timeout first — must be set before any locking operation.
    # Do NOT set PRAGMA journal_mode here: it requires an exclusive lock even when
    # the mode is already correct, which deadlocks on OneDrive paths when the MCP
    # server has the DB open.  Journal mode is a persistent DB-level setting; it is
    # set once in ensure_schema() when the database is first created.
    conn.execute("PRAGMA busy_timeout=30000")
    conn.execute("PRAGMA foreign_keys=OFF")
    return conn


def _stable_chunk_id_from_path(file_path: str) -> str:
    """Deterministic chunk ID for a file-level stub node seeded from scout pack."""
    return hashlib.sha256(f"scout-stub::{file_path}".encode()).hexdigest()[:32]


# ---------------------------------------------------------------------------
# GraphStore
# ---------------------------------------------------------------------------

class GraphStore:
    """Thin SQLite wrapper for the DRQS reasoning graph."""

    def __init__(self, project_root: Path) -> None:
        self._project_root = Path(project_root).resolve()
        self._db_path = _graph_db_path(self._project_root)
        self._auto_seed_if_needed()

    # ------------------------------------------------------------------
    # Schema
    # ------------------------------------------------------------------

    def ensure_schema(self) -> None:
        """Create all tables and indexes.  Fully idempotent."""
        try:
            with _connect(self._db_path) as conn:
                # Set journal mode once here — this is the only place it is set.
                # PRAGMA journal_mode requires an exclusive lock; doing it here (at
                # startup/init time) is safe because no concurrent traffic exists yet.
                # We intentionally do NOT set it in _connect() to avoid deadlocking
                # the MCP server when DRQS opens a second connection mid-request.
                jmode = _graph_journal_mode(self._db_path)
                try:
                    conn.execute(f"PRAGMA journal_mode={jmode}")
                    conn.commit()
                except Exception:
                    pass  # already set or can't change — safe to continue
                # Run additive migrations FIRST so any new columns exist before
                # the schema script tries to create indexes on them.
                _MIGRATIONS = [
                    "ALTER TABLE reasoning_cards ADD COLUMN chunk_id TEXT NOT NULL DEFAULT ''",
                ]
                for sql in _MIGRATIONS:
                    try:
                        conn.execute(sql)
                        conn.commit()
                    except Exception:
                        pass  # column already exists — ignore
                conn.executescript(_SCHEMA_SQL)
        except Exception:
            logger.debug("graph_store: ensure_schema failed — graph unavailable", exc_info=True)

    # ------------------------------------------------------------------
    # Auto-seed hook
    # ------------------------------------------------------------------

    def _auto_seed_if_needed(self) -> None:
        """Seed from scout pack on first access or when scout pack is newer."""
        try:
            self.ensure_schema()
            scout_path = self._project_root / SCOUT_PACK_PATH
            if not scout_path.exists():
                return
            scout_mtime = scout_path.stat().st_mtime
            last_seed = self._last_seed_timestamp()
            if scout_mtime > last_seed:
                seed_graph_from_scout_pack(self._project_root, self)
        except Exception:
            logger.debug("graph_store: auto-seed failed", exc_info=True)

    def _last_seed_timestamp(self) -> float:
        """Return the last seed timestamp stored in graph metadata, or 0.0."""
        try:
            with _connect(self._db_path) as conn:
                row = conn.execute(
                    "SELECT last_rebuild_at FROM reasoning_graph_metadata ORDER BY rowid DESC LIMIT 1"
                ).fetchone()
                return float(row["last_rebuild_at"]) if row else 0.0
        except Exception:
            return 0.0

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    def stats(self) -> dict[str, Any]:
        """Return live node/edge counts by querying tables directly."""
        try:
            with _connect(self._db_path) as conn:
                return self._compute_stats(conn)
        except Exception:
            return {
                "node_count_cards": 0,
                "node_count_chunks": 0,
                "edge_count_card_card": 0,
                "edge_count_card_chunk": 0,
                "edge_count_chunk_chunk": 0,
            }

    def _compute_stats(self, conn: sqlite3.Connection) -> dict[str, Any]:
        def count(table: str) -> int:
            try:
                return conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            except Exception:
                return 0

        return {
            "node_count_cards": count("reasoning_cards"),
            "node_count_chunks": count("chunks"),
            "edge_count_card_card": count("card_card_edges"),
            "edge_count_card_chunk": count("card_chunk_edges"),
            "edge_count_chunk_chunk": count("chunk_chunk_edges"),
        }

    def _refresh_metadata(self, conn: sqlite3.Connection) -> None:
        """Recount all nodes/edges and upsert the metadata row."""
        s = self._compute_stats(conn)
        conn.execute(
            """
            INSERT INTO reasoning_graph_metadata
                (graph_version, schema_version, last_rebuild_at,
                 node_count_cards, node_count_chunks,
                 edge_count_card_card, edge_count_card_chunk, edge_count_chunk_chunk)
            VALUES ('v1', 'drqs-v1', ?, ?, ?, ?, ?, ?)
            ON CONFLICT(graph_version) DO UPDATE SET
                last_rebuild_at=excluded.last_rebuild_at,
                node_count_cards=excluded.node_count_cards,
                node_count_chunks=excluded.node_count_chunks,
                edge_count_card_card=excluded.edge_count_card_card,
                edge_count_card_chunk=excluded.edge_count_card_chunk,
                edge_count_chunk_chunk=excluded.edge_count_chunk_chunk
            """,
            (
                time.time(),
                s["node_count_cards"],
                s["node_count_chunks"],
                s["edge_count_card_card"],
                s["edge_count_card_chunk"],
                s["edge_count_chunk_chunk"],
            ),
        )

    # ------------------------------------------------------------------
    # Upsert helpers
    # ------------------------------------------------------------------

    def upsert_chunk(
        self,
        chunk_id: str,
        file_path: str,
        symbol_path: str | None = None,
        hash_: str = "",
        importance_rank: int = 9999,
    ) -> None:
        try:
            with _connect(self._db_path) as conn:
                conn.execute(
                    """
                    INSERT INTO chunks (chunk_id, file_path, symbol_path, hash, importance_rank, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    ON CONFLICT(chunk_id) DO UPDATE SET
                        file_path=excluded.file_path,
                        symbol_path=excluded.symbol_path,
                        hash=excluded.hash,
                        importance_rank=excluded.importance_rank
                    """,
                    (chunk_id, file_path, symbol_path, hash_, importance_rank, int(time.time())),
                )
        except Exception:
            logger.debug("graph_store: upsert_chunk failed", exc_info=True)

    def upsert_artifact(
        self,
        artifact_id: str,
        chunk_id: str,
        summary: str,
        dependency_notes: str = "",
        validation_state: str = "preliminary",
    ) -> None:
        try:
            with _connect(self._db_path) as conn:
                conn.execute(
                    """
                    INSERT INTO reasoning_artifacts
                        (artifact_id, chunk_id, summary, dependency_notes, validation_state, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    ON CONFLICT(artifact_id) DO UPDATE SET
                        summary=excluded.summary,
                        dependency_notes=excluded.dependency_notes,
                        validation_state=excluded.validation_state
                    """,
                    (artifact_id, chunk_id, summary, dependency_notes, validation_state, int(time.time())),
                )
        except Exception:
            logger.debug("graph_store: upsert_artifact failed", exc_info=True)

    def upsert_card(
        self,
        card_id: str,
        scope_fingerprint: str,
        task_intent: str,
        dependency_fingerprint: str = "",
        validation_state: str = "preliminary",
        supersedes_card_id: str | None = None,
        chunk_id: str = "",
    ) -> None:
        try:
            with _connect(self._db_path) as conn:
                conn.execute(
                    """
                    INSERT INTO reasoning_cards
                        (card_id, scope_fingerprint, task_intent,
                         dependency_fingerprint, validation_state, supersedes_card_id,
                         chunk_id, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(card_id) DO UPDATE SET
                        scope_fingerprint=excluded.scope_fingerprint,
                        task_intent=excluded.task_intent,
                        dependency_fingerprint=excluded.dependency_fingerprint,
                        validation_state=excluded.validation_state,
                        supersedes_card_id=excluded.supersedes_card_id,
                        chunk_id=excluded.chunk_id,
                        updated_at=excluded.updated_at
                    """,
                    (
                        card_id, scope_fingerprint, task_intent,
                        dependency_fingerprint, validation_state, supersedes_card_id,
                        chunk_id, int(time.time()), int(time.time()),
                    ),
                )
        except Exception:
            logger.debug("graph_store: upsert_card failed", exc_info=True)

    def upsert_card_chunk_edge(
        self,
        from_card_id: str,
        to_chunk_id: str,
        edge_type: str = "evidence",
        weight: float = 1.0,
    ) -> None:
        try:
            with _connect(self._db_path) as conn:
                conn.execute(
                    """
                    INSERT INTO card_chunk_edges (from_card_id, to_chunk_id, edge_type, weight)
                    VALUES (?, ?, ?, ?)
                    ON CONFLICT(from_card_id, to_chunk_id, edge_type) DO UPDATE SET weight=excluded.weight
                    """,
                    (from_card_id, to_chunk_id, edge_type, weight),
                )
        except Exception:
            logger.debug("graph_store: upsert_card_chunk_edge failed", exc_info=True)

    def upsert_chunk_chunk_edge(
        self,
        from_chunk_id: str,
        to_chunk_id: str,
        edge_type: str = "imports",
        weight: float = 1.0,
    ) -> None:
        try:
            with _connect(self._db_path) as conn:
                conn.execute(
                    """
                    INSERT INTO chunk_chunk_edges (from_chunk_id, to_chunk_id, edge_type, weight)
                    VALUES (?, ?, ?, ?)
                    ON CONFLICT(from_chunk_id, to_chunk_id, edge_type) DO UPDATE SET weight=excluded.weight
                    """,
                    (from_chunk_id, to_chunk_id, edge_type, weight),
                )
        except Exception:
            logger.debug("graph_store: upsert_chunk_chunk_edge failed", exc_info=True)

    def upsert_card_card_edge(
        self,
        from_card_id: str,
        to_card_id: str,
        edge_type: str = "shared_scope",
        weight: float = 1.0,
    ) -> None:
        try:
            with _connect(self._db_path) as conn:
                conn.execute(
                    """
                    INSERT INTO card_card_edges (from_card_id, to_card_id, edge_type, weight)
                    VALUES (?, ?, ?, ?)
                    ON CONFLICT(from_card_id, to_card_id, edge_type) DO UPDATE SET weight=excluded.weight
                    """,
                    (from_card_id, to_card_id, edge_type, weight),
                )
        except Exception:
            logger.debug("graph_store: upsert_card_card_edge failed", exc_info=True)

    def upsert_card_artifact_edge(
        self,
        from_card_id: str,
        to_artifact_id: str,
        edge_type: str = "evidence",
        weight: float = 1.0,
    ) -> None:
        try:
            with _connect(self._db_path) as conn:
                conn.execute(
                    """
                    INSERT INTO card_artifact_edges (from_card_id, to_artifact_id, edge_type, weight)
                    VALUES (?, ?, ?, ?)
                    ON CONFLICT(from_card_id, to_artifact_id, edge_type) DO UPDATE SET weight=excluded.weight
                    """,
                    (from_card_id, to_artifact_id, edge_type, weight),
                )
        except Exception:
            logger.debug("graph_store: upsert_card_artifact_edge failed", exc_info=True)

    # ------------------------------------------------------------------
    # Batch edge helpers
    # ------------------------------------------------------------------

    def _build_card_edges_batch(self, card_id: str, scope_fingerprint: str, chunk_id: str = "") -> int:
        """Build card-card edges for *card_id* in a single transaction.

        Three edge types are considered in priority order:
        - ``contains``: this card's chunk_id is a prefix of another card's chunk_id
          (or vice versa), indicating a parent-child module relationship.
        - ``shared_scope``: another card shares the same scope_fingerprint.
        - ``semantic_neighbor``: another card's chunk_id equals this card's chunk_id
          (same file, different intent).

        Uses a single UNION ALL query so each branch hits its own index.
        Returns the number of edges upserted.
        """
        if not scope_fingerprint or scope_fingerprint == "repo":
            return 0
        try:
            with _connect(self._db_path) as conn:
                # Collect candidate edges via UNION ALL (each branch uses its index).
                rows = conn.execute(
                    """
                    SELECT card_id AS to_card_id, 'contains' AS edge_type, 2.0 AS weight
                    FROM reasoning_cards
                    WHERE card_id != ?
                      AND chunk_id != ''
                      AND (
                        (? != '' AND (chunk_id LIKE ? || '%' OR ? LIKE chunk_id || '%'))
                      )
                    UNION ALL
                    SELECT card_id AS to_card_id, 'shared_scope' AS edge_type, 1.0 AS weight
                    FROM reasoning_cards
                    WHERE card_id != ?
                      AND scope_fingerprint = ?
                    UNION ALL
                    SELECT card_id AS to_card_id, 'semantic_neighbor' AS edge_type, 0.5 AS weight
                    FROM reasoning_cards
                    WHERE card_id != ?
                      AND chunk_id != ''
                      AND chunk_id = ?
                      AND scope_fingerprint != ?
                    UNION ALL
                    SELECT card_id AS to_card_id, 'contains' AS edge_type, 1.5 AS weight
                    FROM reasoning_cards
                    WHERE card_id != ?
                      AND (
                        scope_fingerprint LIKE ? || '::%'
                        OR ? LIKE scope_fingerprint || '::%'
                      )
                    """,
                    (
                        card_id, chunk_id, chunk_id, chunk_id,        # contains (chunk_id) branch
                        card_id, scope_fingerprint,                    # shared_scope branch
                        card_id, chunk_id, scope_fingerprint,          # semantic_neighbor branch
                        card_id, scope_fingerprint, scope_fingerprint, # contains (scope prefix) branch
                    ),
                ).fetchall()

                if not rows:
                    return 0

                # Deduplicate: keep highest-weight edge type per to_card_id.
                best: dict[str, tuple[str, float]] = {}
                for row in rows:
                    to_id, etype, w = row[0], row[1], float(row[2])
                    if to_id not in best or w > best[to_id][1]:
                        best[to_id] = (etype, w)

                params = [
                    (card_id, to_id, etype, w)
                    for to_id, (etype, w) in best.items()
                ]
                conn.executemany(
                    """
                    INSERT INTO card_card_edges (from_card_id, to_card_id, edge_type, weight)
                    VALUES (?, ?, ?, ?)
                    ON CONFLICT(from_card_id, to_card_id, edge_type) DO UPDATE SET weight=excluded.weight
                    """,
                    params,
                )
                return len(params)
        except Exception:
            logger.debug("graph_store: _build_card_edges_batch failed", exc_info=True)
            return 0

    def _rebuild_parent_edges(self, card_id: str, scope_fingerprint: str) -> int:
        """Re-run edge building for all cards that are scope ancestors of *card_id*.

        When a child card (e.g. ``resolver::func``) is newly committed, any
        existing parent cards (e.g. ``resolver``) were built before the child
        existed and therefore have no edge pointing down to it.  This method
        finds those parents and rebuilds their edge sets so the graph is
        bidirectionally connected.

        Returns the total number of new edges upserted across all parents.
        """
        if not scope_fingerprint or scope_fingerprint == "repo" or "::" not in scope_fingerprint:
            return 0
        try:
            with _connect(self._db_path) as conn:
                parents = conn.execute(
                    """
                    SELECT card_id, scope_fingerprint, chunk_id
                    FROM reasoning_cards
                    WHERE card_id != ?
                      AND ? LIKE scope_fingerprint || '::%'
                    """,
                    (card_id, scope_fingerprint),
                ).fetchall()
            total = 0
            for row in parents:
                parent_card_id = row[0]
                parent_scope = row[1]
                parent_chunk_id = row[2] or ""
                total += self._build_card_edges_batch(parent_card_id, parent_scope, parent_chunk_id)
            return total
        except Exception:
            logger.debug("graph_store: _rebuild_parent_edges failed", exc_info=True)
            return 0

    # ------------------------------------------------------------------
    # Read helpers (used by GraphNavigator and DirectedQueryRouter)
    # ------------------------------------------------------------------

    def get_chunk(self, chunk_id: str) -> dict[str, Any] | None:
        try:
            with _connect(self._db_path) as conn:
                row = conn.execute(
                    "SELECT * FROM chunks WHERE chunk_id = ?", (chunk_id,)
                ).fetchone()
                return dict(row) if row else None
        except Exception:
            return None

    def get_artifact_for_chunk(self, chunk_id: str) -> dict[str, Any] | None:
        try:
            with _connect(self._db_path) as conn:
                row = conn.execute(
                    "SELECT * FROM reasoning_artifacts WHERE chunk_id = ? ORDER BY created_at DESC LIMIT 1",
                    (chunk_id,),
                ).fetchone()
                return dict(row) if row else None
        except Exception:
            return None

    def get_artifact(self, artifact_id: str) -> dict[str, Any] | None:
        try:
            with _connect(self._db_path) as conn:
                row = conn.execute(
                    "SELECT * FROM reasoning_artifacts WHERE artifact_id = ?", (artifact_id,)
                ).fetchone()
                return dict(row) if row else None
        except Exception:
            return None

    def get_card(self, card_id: str) -> dict[str, Any] | None:
        try:
            with _connect(self._db_path) as conn:
                row = conn.execute(
                    "SELECT * FROM reasoning_cards WHERE card_id = ?", (card_id,)
                ).fetchone()
                return dict(row) if row else None
        except Exception:
            return None

    def get_cards_for_scope(self, scope_fingerprint: str) -> list[dict[str, Any]]:
        try:
            with _connect(self._db_path) as conn:
                rows = conn.execute(
                    "SELECT * FROM reasoning_cards WHERE scope_fingerprint = ? ORDER BY updated_at DESC",
                    (scope_fingerprint,),
                ).fetchall()
                return [dict(r) for r in rows]
        except Exception:
            return []

    def get_card_chunk_edges(self, card_id: str) -> list[dict[str, Any]]:
        try:
            with _connect(self._db_path) as conn:
                rows = conn.execute(
                    "SELECT * FROM card_chunk_edges WHERE from_card_id = ?", (card_id,)
                ).fetchall()
                return [dict(r) for r in rows]
        except Exception:
            return []

    def get_cards_for_chunk(self, chunk_id: str) -> list[dict[str, Any]]:
        try:
            with _connect(self._db_path) as conn:
                rows = conn.execute(
                    """
                    SELECT rc.* FROM reasoning_cards rc
                    JOIN card_chunk_edges cce ON rc.card_id = cce.from_card_id
                    WHERE cce.to_chunk_id = ?
                    ORDER BY rc.updated_at DESC
                    """,
                    (chunk_id,),
                ).fetchall()
                return [dict(r) for r in rows]
        except Exception:
            return []

    def get_chunk_chunk_edges(self, chunk_id: str) -> list[dict[str, Any]]:
        try:
            with _connect(self._db_path) as conn:
                rows = conn.execute(
                    "SELECT * FROM chunk_chunk_edges WHERE from_chunk_id = ? OR to_chunk_id = ?",
                    (chunk_id, chunk_id),
                ).fetchall()
                return [dict(r) for r in rows]
        except Exception:
            return []

    def get_card_card_edges(self, card_id: str, min_weight: float = 0.0) -> list[dict[str, Any]]:
        try:
            with _connect(self._db_path) as conn:
                rows = conn.execute(
                    """
                    SELECT * FROM card_card_edges
                    WHERE (from_card_id = ? OR to_card_id = ?) AND weight >= ?
                    ORDER BY weight DESC
                    """,
                    (card_id, card_id, min_weight),
                ).fetchall()
                return [dict(r) for r in rows]
        except Exception:
            return []

    def get_supersession_chain(self, card_id: str, max_hops: int = 20) -> list[dict[str, Any]]:
        """Walk supersedes_card_id links backward to build the full lineage chain."""
        chain: list[dict[str, Any]] = []
        visited: set[str] = set()
        current_id: str | None = card_id
        while current_id and len(chain) < max_hops and current_id not in visited:
            visited.add(current_id)
            card = self.get_card(current_id)
            if not card:
                break
            chain.append(card)
            current_id = card.get("supersedes_card_id")
        return chain


# ---------------------------------------------------------------------------
# Phase 1b — Scout Pack Seeding
# ---------------------------------------------------------------------------

def seed_graph_from_scout_pack(
    project_root: Path,
    graph_store: GraphStore,
) -> dict[str, int]:
    """Seed the graph from scout-pack-latest.json.

    Reads ``project_map`` (file nodes) and ``dependency_context`` (edges).
    Importance ranks are derived from position in ``suggested_read_order``.

    Returns counts: {chunks_written, edges_written}.
    Never raises — all errors are logged at DEBUG level.
    """
    project_root = Path(project_root).resolve()
    scout_path = project_root / SCOUT_PACK_PATH
    counts = {"chunks_written": 0, "edges_written": 0}

    if not scout_path.exists():
        logger.debug("graph_store: scout pack not found at %s — skipping seed", scout_path)
        return counts

    try:
        data = json.loads(scout_path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        logger.debug("graph_store: failed to read scout pack", exc_info=True)
        return counts

    # Build importance rank lookup from suggested_read_order
    read_order: list[str] = data.get("suggested_read_order", []) or []
    importance_rank_by_path: dict[str, int] = {
        path: idx for idx, path in enumerate(read_order)
    }

    # Write chunk stub nodes from project_map
    project_map: list[str] = data.get("project_map", []) or []
    for file_path in project_map:
        if not isinstance(file_path, str) or not file_path.strip():
            continue
        chunk_id = _stable_chunk_id_from_path(file_path)
        importance_rank = importance_rank_by_path.get(file_path, 9999)
        graph_store.upsert_chunk(
            chunk_id=chunk_id,
            file_path=file_path,
            symbol_path=None,
            hash_="",
            importance_rank=importance_rank,
        )
        counts["chunks_written"] += 1

    # Build path → chunk_id lookup for edge writing
    path_to_chunk_id: dict[str, str] = {
        fp: _stable_chunk_id_from_path(fp)
        for fp in project_map
        if isinstance(fp, str) and fp.strip()
    }

    # Write chunk_chunk_edges from dependency_context
    dep_ctx: list[str] = data.get("dependency_context", []) or []
    for entry in dep_ctx:
        if not isinstance(entry, str):
            continue
        m = _DEP_CTX_RE.match(entry)
        if not m:
            continue
        from_path = m.group("from_path").strip()
        # The entry describes a dependency: from_path depends_on target
        # We need the target path — it comes from the entry itself as the
        # depended-upon file. The format is:
        #   depends_on::src/file.py::def-symbol:N
        # meaning some other file imports from src/file.py::symbol.
        # We create a stub for that target too if it's not in project_map.
        target_path = from_path
        if target_path not in path_to_chunk_id:
            target_chunk_id = _stable_chunk_id_from_path(target_path)
            graph_store.upsert_chunk(
                chunk_id=target_chunk_id,
                file_path=target_path,
                symbol_path=m.group("symbol"),
                hash_="",
                importance_rank=9999,
            )
            path_to_chunk_id[target_path] = target_chunk_id
            counts["chunks_written"] += 1

        # Edges will be built when we have both sides of the dependency.
        # For now emit a self-referencing metadata marker via upsert_artifact
        # so gap detection can find symbol-level entry points.
        artifact_id = f"scout-dep::{_stable_chunk_id_from_path(target_path)}::{m.group('symbol')}"
        graph_store.upsert_artifact(
            artifact_id=artifact_id,
            chunk_id=path_to_chunk_id[target_path],
            summary=f"Scout-identified symbol: {m.group('symbol')} in {target_path}",
            dependency_notes=entry,
            validation_state="scout",
        )
        counts["edges_written"] += 1

    # Refresh metadata row with final counts
    try:
        with _connect(graph_store._db_path) as conn:
            graph_store._refresh_metadata(conn)
    except Exception:
        logger.debug("graph_store: failed to refresh metadata after seed", exc_info=True)

    logger.debug(
        "graph_store: scout seed complete — %d chunks, %d edges",
        counts["chunks_written"],
        counts["edges_written"],
    )
    return counts


# ---------------------------------------------------------------------------
# Schema SQL
# ---------------------------------------------------------------------------

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS reasoning_cards (
    card_id             TEXT PRIMARY KEY,
    scope_fingerprint   TEXT NOT NULL DEFAULT '',
    task_intent         TEXT NOT NULL DEFAULT '',
    dependency_fingerprint TEXT NOT NULL DEFAULT '',
    validation_state    TEXT NOT NULL DEFAULT 'preliminary',
    supersedes_card_id  TEXT,
    chunk_id            TEXT NOT NULL DEFAULT '',
    created_at          INTEGER NOT NULL DEFAULT 0,
    updated_at          INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_cards_chunk_id
    ON reasoning_cards(chunk_id);
CREATE INDEX IF NOT EXISTS idx_cards_scope_fingerprint
    ON reasoning_cards(scope_fingerprint);
CREATE INDEX IF NOT EXISTS idx_cards_dependency_fingerprint
    ON reasoning_cards(dependency_fingerprint);
CREATE INDEX IF NOT EXISTS idx_cards_supersedes_card_id
    ON reasoning_cards(supersedes_card_id);

CREATE TABLE IF NOT EXISTS reasoning_artifacts (
    artifact_id         TEXT PRIMARY KEY,
    chunk_id            TEXT NOT NULL DEFAULT '',
    summary             TEXT NOT NULL DEFAULT '',
    dependency_notes    TEXT,
    validation_state    TEXT NOT NULL DEFAULT 'preliminary',
    created_at          INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_artifacts_chunk_id
    ON reasoning_artifacts(chunk_id);

CREATE TABLE IF NOT EXISTS chunks (
    chunk_id        TEXT PRIMARY KEY,
    file_path       TEXT NOT NULL DEFAULT '',
    symbol_path     TEXT,
    hash            TEXT NOT NULL DEFAULT '',
    importance_rank INTEGER NOT NULL DEFAULT 9999,
    created_at      INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_chunks_file_path
    ON chunks(file_path);
CREATE INDEX IF NOT EXISTS idx_chunks_symbol_path
    ON chunks(symbol_path);

CREATE TABLE IF NOT EXISTS card_chunk_edges (
    from_card_id    TEXT NOT NULL,
    to_chunk_id     TEXT NOT NULL,
    edge_type       TEXT NOT NULL DEFAULT 'evidence',
    weight          REAL NOT NULL DEFAULT 1.0,
    PRIMARY KEY (from_card_id, to_chunk_id, edge_type)
);
CREATE INDEX IF NOT EXISTS idx_card_chunk_from_card_id
    ON card_chunk_edges(from_card_id);
CREATE INDEX IF NOT EXISTS idx_card_chunk_to_chunk_id
    ON card_chunk_edges(to_chunk_id);

CREATE TABLE IF NOT EXISTS chunk_chunk_edges (
    from_chunk_id   TEXT NOT NULL,
    to_chunk_id     TEXT NOT NULL,
    edge_type       TEXT NOT NULL DEFAULT 'imports',
    weight          REAL NOT NULL DEFAULT 1.0,
    PRIMARY KEY (from_chunk_id, to_chunk_id, edge_type)
);
CREATE INDEX IF NOT EXISTS idx_chunk_chunk_from_chunk_id
    ON chunk_chunk_edges(from_chunk_id);
CREATE INDEX IF NOT EXISTS idx_chunk_chunk_to_chunk_id
    ON chunk_chunk_edges(to_chunk_id);

CREATE TABLE IF NOT EXISTS card_card_edges (
    from_card_id    TEXT NOT NULL,
    to_card_id      TEXT NOT NULL,
    edge_type       TEXT NOT NULL DEFAULT 'shared_scope',
    weight          REAL NOT NULL DEFAULT 1.0,
    PRIMARY KEY (from_card_id, to_card_id, edge_type)
);
CREATE INDEX IF NOT EXISTS idx_card_card_from_card_id
    ON card_card_edges(from_card_id);
CREATE INDEX IF NOT EXISTS idx_card_card_to_card_id
    ON card_card_edges(to_card_id);

CREATE TABLE IF NOT EXISTS card_artifact_edges (
    from_card_id    TEXT NOT NULL,
    to_artifact_id  TEXT NOT NULL,
    edge_type       TEXT NOT NULL DEFAULT 'evidence',
    weight          REAL NOT NULL DEFAULT 1.0,
    PRIMARY KEY (from_card_id, to_artifact_id, edge_type)
);
CREATE INDEX IF NOT EXISTS idx_card_artifact_from_card_id
    ON card_artifact_edges(from_card_id);
CREATE INDEX IF NOT EXISTS idx_card_artifact_to_artifact_id
    ON card_artifact_edges(to_artifact_id);

CREATE TABLE IF NOT EXISTS reasoning_graph_metadata (
    graph_version           TEXT PRIMARY KEY,
    schema_version          TEXT NOT NULL DEFAULT 'drqs-v1',
    last_rebuild_at         REAL NOT NULL DEFAULT 0,
    node_count_cards        INTEGER NOT NULL DEFAULT 0,
    node_count_chunks       INTEGER NOT NULL DEFAULT 0,
    edge_count_card_card    INTEGER NOT NULL DEFAULT 0,
    edge_count_card_chunk   INTEGER NOT NULL DEFAULT 0,
    edge_count_chunk_chunk  INTEGER NOT NULL DEFAULT 0
);
"""
