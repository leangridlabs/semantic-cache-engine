# Mask SIGINT during startup so Windows console-host CTRL events that arrive
# while Python probes the mcp package tree (find_spec / _path_join inside the
# frozen import bootstrap) cannot fire a KeyboardInterrupt in uncatchable code.
# The signal is restored to the default handler just before main() runs so that
# normal Ctrl-C behaviour is preserved for interactive use.
import signal as _signal
_signal.signal(_signal.SIGINT, _signal.SIG_IGN)

from .cli import main  # noqa: E402 — intentional: import after signal mask

_signal.signal(_signal.SIGINT, _signal.default_int_handler)

if __name__ == "__main__":
    raise SystemExit(main())
