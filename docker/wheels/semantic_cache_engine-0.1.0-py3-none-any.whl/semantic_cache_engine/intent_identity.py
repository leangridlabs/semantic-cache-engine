"""intent_identity.py — Deterministic, phrasing-invariant verb-class taxonomy.

Single source of truth for the *query-side* intent identity used as a routing
and reuse key across the engine:

  - WRITE:   build_reasoning_card in reasoning_memory.py (stores canonical_intent)
  - QUERY:   derive_canonical_intent in resolver.py routing cascade
  - COMPARE: canonical_intent equality boost in recall scoring

The intent identity is ``module::verb_class`` (the module comes from the
scope_fingerprint; the verb_class comes from this module).  Together with the
canonical scope identity it forms the structural routing key:

  exact module::verb_class match    -> direct artifact reuse (fast-lane / recall)
  same module, different verb_class -> graph-assisted expansion (DRQS)
  no module overlap                 -> agent handoff

Determinism goal
----------------
The verb class is a *pure, phrasing-invariant* function of the task intent: two
paraphrases of the same operation-class question collapse to the same verb
class regardless of surface wording.  This is achieved with a bounded synonym
lexicon (exact words + stem prefixes) evaluated in a fixed priority order, so
the result depends only on which lexical class is present — not on regex
ordering accidents or phrasing variants.

Taxonomy (aligned with the patent Flag 1 verb-class table)
----------------------------------------------------------
  explain   "what does X do?", "what is X?", "what does X return/produce/output?"
  build     "how is X created?", "what initializes X?"
  traverse  "how do you walk X?", "what iterates X?"
  configure "what settings affect X?"
  debug     "why is X failing?", "what causes X error?"
  test      "how is X tested?", "what covers X?"
  integrate "how does X connect to Y?", "what calls X?"

NOTE: output-querying verbs (return / produce / output / yield) deliberately map
to ``explain`` — they ask what a unit *does*, not how it is *constructed*.  The
patent's ``build`` class is reserved for construction/initialization questions.
"""

from __future__ import annotations

import re


# Ordered verb classes.  ``explain`` is the implicit fallback and is therefore
# not present in the rules list below.
VERB_CLASSES: tuple[str, ...] = (
    "explain",
    "build",
    "traverse",
    "configure",
    "debug",
    "test",
    "integrate",
)

_FALLBACK_VERB_CLASS = "explain"

# Each rule is (verb_class, exact_words, stem_prefixes).
#   - exact_words:   matched against whole tokens only (used for short or
#                    ambiguous words like "is", "use", "set", "read" where a
#                    prefix match would over-trigger).
#   - stem_prefixes: matched with str.startswith against each token (used for
#                    clear verb stems where inflections share a prefix, e.g.
#                    "creat" -> create/creates/created/creating).
#
# Priority order matters: more-specific operation classes (debug, test,
# configure) are evaluated before the broad construction/traversal classes so a
# question like "how is X tested" routes to ``test`` rather than ``explain``.
_VERB_RULES: list[tuple[str, frozenset[str], tuple[str, ...]]] = [
    (
        "debug",
        frozenset({"why", "wrong", "broken", "bug", "bugs", "stuck", "fix", "fixes", "fixed", "fixing"}),
        ("debug", "fail", "error", "except", "crash", "incorrect", "caus", "breakage"),
    ),
    (
        "test",
        frozenset({"mock", "mocks", "fixture", "fixtures"}),
        ("test", "spec", "coverage", "cover", "assert"),
    ),
    (
        "configure",
        frozenset({"set", "env", "flag", "flags", "option", "options", "toggle", "knob", "knobs"}),
        ("config", "setting", "setup", "environment", "parameter", "customis", "customiz", "tune", "tuning"),
    ),
    (
        "integrate",
        frozenset(
            {"use", "uses", "used", "call", "calls", "wire", "wires", "hook", "hooks", "plug", "plugs"}
        ),
        # NOTE: deliberately excludes "depend"/"import" — those stems collide with
        # common code identifiers (e.g. the `dependency_graph` module, the
        # `import_reason_bundle` file) and would misclassify explain-style
        # questions about those modules as integrate.
        ("connect", "invoke", "invok", "trigger", "integrat", "referenc"),
    ),
    (
        "build",
        frozenset({"make", "makes", "made", "built", "init", "inits", "commit", "commits"}),
        ("creat", "build", "construct", "initial", "instantiat", "allocat", "populat", "generat", "assembl", "compos"),
    ),
    (
        "traverse",
        frozenset({"read", "reads", "reading"}),
        ("travers", "iterat", "consum", "stream", "enumerat", "walk", "scan", "loop", "visit", "crawl"),
    ),
]

_TOKEN_RE = re.compile(r"[a-z0-9]+")


def _tokens(task_intent: str) -> list[str]:
    """Lowercase the intent and split into ``[a-z0-9]+`` tokens."""
    return _TOKEN_RE.findall(task_intent.lower())


def derive_verb_class(task_intent: str) -> str:
    """Map *task_intent* to a canonical verb class.

    Pure and phrasing-invariant: the result depends only on which lexical class
    is present, evaluated in a fixed priority order.  Always returns a non-empty
    verb class; defaults to ``explain`` when no rule matches.
    """
    tokens = _tokens(task_intent)
    if not tokens:
        return _FALLBACK_VERB_CLASS
    token_set = set(tokens)
    for verb_class, exact, prefixes in _VERB_RULES:
        if token_set & exact:
            return verb_class
        for tok in tokens:
            if tok.startswith(prefixes):
                return verb_class
    return _FALLBACK_VERB_CLASS


def _module_of(scope_fingerprint: str) -> str | None:
    """Return the module component of a scope fingerprint, or None for generic scopes."""
    sf = (scope_fingerprint or "").strip()
    if not sf or sf == "repo":
        return None
    module = sf.split("::", 1)[0].strip()
    if not module or module == "repo":
        return None
    return module


def canonical_intent(
    task_intent: str,
    scope_fingerprint: str,
    *,
    symbol: str | None = None,
) -> str | None:
    """Return the canonical intent identity for the given intent + scope.

    Returns ``module::verb_class`` by default, or None when *scope_fingerprint*
    is generic (``repo`` or empty) — a repo-level scope has no meaningful module
    prefix, so forming a cluster key would only introduce noise.

    Symbol-aware (optional): when *symbol* is provided, returns the three-part
    ``module::symbol::verb_class`` identity for finer-grained reuse eligibility.
    The stored card format remains two-part unless a symbol is explicitly
    supplied, so existing recall keys are unaffected by default.
    """
    module = _module_of(scope_fingerprint)
    if module is None:
        return None
    verb_class = derive_verb_class(task_intent)
    sym = (symbol or "").strip()
    if sym:
        return f"{module}::{sym}::{verb_class}"
    return f"{module}::{verb_class}"
