"""
ast_edge_seeder.py — Deterministic chunk-chunk edge seeder using Python AST.

Parses ``import`` / ``from X import Y`` statements from every Python file in a
project and writes ``chunk_chunk_edges`` to the reasoning graph.  Zero LLM
token cost — only Python stdlib ``ast`` is used.

Both source and target chunk nodes are identified with the same
``_stable_chunk_id_from_path`` formula used by the scout-pack seeder, so edges
resolve against existing stub nodes without any additional bookkeeping.

Integration points
------------------
- Called via the ``seed-edges`` CLI command after snapshot + scout-pack seeding.
- Can also be called programmatically from tests or the snapshot pipeline.

Example (CLI)::

    python -m src.semantic_cache_engine seed-edges --path /path/to/repo

Example (Python)::

    from semantic_cache_engine.ast_edge_seeder import seed_edges_from_ast
    from semantic_cache_engine.graph_store import GraphStore

    gs = GraphStore(project_root)
    result = seed_edges_from_ast(project_root, gs)
    # {"files_scanned": 12, "edges_written": 34, "parse_errors": 0}
"""
from __future__ import annotations

import ast
import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .graph_store import GraphStore

from .graph_store import _stable_chunk_id_from_path

logger = logging.getLogger(__name__)

# Same set as ingest.py so we don't walk into dirs that have no tracked chunks.
_IGNORED_DIRS: frozenset[str] = frozenset({
    ".git",
    "__pycache__",
    ".venv",
    "venv",
    "node_modules",
    ".pytest_cache",
    "baselines",
    "cache",
    "deltas",
    "runs",
    "dist",
    "build",
    "runtime",
})


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _collect_py_files(project_root: Path) -> list[Path]:
    """Return all .py files under *project_root*, skipping _IGNORED_DIRS."""
    result: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(project_root):
        dirnames[:] = [d for d in dirnames if d not in _IGNORED_DIRS]
        dp = Path(dirpath)
        for fname in filenames:
            if fname.endswith(".py"):
                result.append(dp / fname)
    result.sort(key=lambda p: str(p).lower())
    return result


def _build_module_map(project_root: Path, py_files: list[Path]) -> dict[str, str]:
    """
    Build a lookup: *importable name* → *project-relative posix path*.

    For ``src/email_router.py`` this registers:
      - ``"email_router"``       → ``"src/email_router.py"``
      - ``"src.email_router"``   → ``"src/email_router.py"``

    For ``src/pkg/__init__.py`` this registers:
      - ``"pkg"``                → ``"src/pkg/__init__.py"``
      - ``"src.pkg"``            → ``"src/pkg/__init__.py"``

    Later keys win on collision (deeper paths are more specific).
    """
    module_map: dict[str, str] = {}

    for f in py_files:
        rel = f.relative_to(project_root).as_posix()
        parts = Path(rel).with_suffix("").parts  # e.g. ("src", "email_router")
        is_init = parts[-1] == "__init__"

        # --- stem key (shortest, least specific) ---
        stem = parts[-2] if is_init and len(parts) >= 2 else parts[-1]
        if stem not in module_map:
            module_map[stem] = rel

        # --- full dotted key ---
        dotted_parts = parts[:-1] if is_init else parts
        dotted = ".".join(dotted_parts)
        module_map[dotted] = rel  # full path always wins

        # --- tail-2 dotted key for disambiguation (e.g. "engine.resolver") ---
        if len(dotted_parts) >= 2:
            tail2 = ".".join(dotted_parts[-2:])
            if tail2 not in module_map:
                module_map[tail2] = rel

    return module_map


def _resolve_relative_import(
    current_file: Path,
    project_root: Path,
    module: str,
    level: int,
    py_files_set: set[Path],
) -> str | None:
    """
    Resolve a relative import (``level >= 1``) to a project-relative posix
    path, or ``None`` if the target is not a tracked Python file.

    ``level=1`` means ``from .sibling import …`` (current package).
    ``level=2`` means ``from ..parent import …`` (one level up).
    """
    # Walk up (level - 1) directories from the current file's directory.
    package_dir = current_file.parent
    for _ in range(level - 1):
        package_dir = package_dir.parent
        if package_dir < project_root:
            return None  # escaped project root — ignore

    if not module:
        return None

    rel_module_path = module.replace(".", os.sep)
    candidates = [
        package_dir / f"{rel_module_path}.py",
        package_dir / rel_module_path / "__init__.py",
    ]
    for candidate in candidates:
        if candidate.resolve() in py_files_set:
            try:
                return candidate.relative_to(project_root).as_posix()
            except ValueError:
                return None
    return None


def _extract_imports(source_path: Path, source: str) -> list[tuple[str, int]] | None:
    """
    Parse *source* with ``ast`` and return a list of ``(module_name, level)``.

    - ``level == 0`` for absolute imports.
    - ``level >= 1`` for relative imports.

    Returns ``None`` on ``SyntaxError`` so the caller can count parse errors.
    """
    try:
        tree = ast.parse(source, filename=str(source_path))
    except SyntaxError:
        return None

    imports: list[tuple[str, int]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.append((alias.name, 0))
        elif isinstance(node, ast.ImportFrom):
            level = node.level or 0
            module = node.module or ""
            imports.append((module, level))

    return imports


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def seed_edges_from_ast(
    project_root: Path,
    graph_store: "GraphStore",
) -> dict[str, int]:
    """
    Walk all Python files under *project_root*, parse their imports with
    ``ast``, and write ``chunk_chunk_edges`` rows to *graph_store*.

    Chunk IDs on both ends of each edge are derived with
    ``_stable_chunk_id_from_path`` so they resolve against the stub nodes
    already written by the scout-pack seeder.

    Self-imports and imports to files outside the project are silently skipped.
    Duplicate edges within a single file are deduplicated before writing.

    Parameters
    ----------
    project_root:
        Absolute path to the repository root.
    graph_store:
        An already-initialised :class:`GraphStore` instance.

    Returns
    -------
    dict with keys:
        - ``files_scanned`` — number of ``.py`` files visited
        - ``edges_written`` — number of ``chunk_chunk_edges`` rows written
        - ``parse_errors``  — number of files that failed ``ast.parse``
    """
    project_root = Path(project_root).resolve()
    counts: dict[str, int] = {
        "files_scanned": 0,
        "edges_written": 0,
        "parse_errors": 0,
    }

    py_files = _collect_py_files(project_root)
    if not py_files:
        logger.debug("ast_edge_seeder: no .py files found under %s", project_root)
        return counts

    # Resolve all paths once so set-membership checks are O(1).
    py_files_resolved = [f.resolve() for f in py_files]
    py_files_set: set[Path] = set(py_files_resolved)

    module_map = _build_module_map(project_root, py_files)

    logger.debug(
        "ast_edge_seeder: scanning %d Python files in %s",
        len(py_files), project_root,
    )

    for source_file, source_file_resolved in zip(py_files, py_files_resolved):
        counts["files_scanned"] += 1
        rel_source = source_file.relative_to(project_root).as_posix()
        from_chunk_id = _stable_chunk_id_from_path(rel_source)

        # Ensure the source chunk node exists (idempotent — safe if scout already wrote it).
        graph_store.upsert_chunk(
            chunk_id=from_chunk_id,
            file_path=rel_source,
        )

        try:
            source_text = source_file.read_text(encoding="utf-8", errors="ignore")
        except OSError as exc:
            logger.debug("ast_edge_seeder: cannot read %s — %s", source_file, exc)
            counts["parse_errors"] += 1
            continue

        imports = _extract_imports(source_file, source_text)
        if imports is None:
            logger.debug("ast_edge_seeder: SyntaxError in %s — skipping", source_file)
            counts["parse_errors"] += 1
            continue

        seen_targets: set[str] = set()

        for module_name, level in imports:
            # --- Resolve target path ---
            if level > 0:
                target_path = _resolve_relative_import(
                    source_file_resolved,
                    project_root,
                    module_name,
                    level,
                    py_files_set,
                )
            else:
                target_path = module_map.get(module_name)
                if target_path is None and "." in module_name:
                    # Try the top-level package only.
                    # e.g. "email.mime.text" → try "email" — likely external,
                    # but also handles "src.resolver" → "resolver" fallback.
                    top = module_name.split(".")[0]
                    target_path = module_map.get(top)

            if target_path is None:
                continue  # external library, stdlib, or unresolved — skip
            if target_path == rel_source:
                continue  # self-import guard
            if target_path in seen_targets:
                continue  # deduplicate within this file

            to_chunk_id = _stable_chunk_id_from_path(target_path)
            # Ensure target chunk node exists before writing the edge.
            graph_store.upsert_chunk(
                chunk_id=to_chunk_id,
                file_path=target_path,
            )
            graph_store.upsert_chunk_chunk_edge(
                from_chunk_id=from_chunk_id,
                to_chunk_id=to_chunk_id,
                edge_type="imports",
                weight=1.0,
            )
            seen_targets.add(target_path)
            counts["edges_written"] += 1

    logger.info(
        "ast_edge_seeder: done — %d files, %d edges written, %d parse errors",
        counts["files_scanned"],
        counts["edges_written"],
        counts["parse_errors"],
    )
    return counts
